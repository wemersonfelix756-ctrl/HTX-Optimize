package com.htx.optimize;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.htx.optimize.adb.HtxAdbManager;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TerminalActivity extends Activity {
    private EditText host, pairPort, pairCode, connectPort, command;
    private TextView output, status;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private HtxAdbManager adb;
    private int pad(int dp) { return (int)(dp * getResources().getDisplayMetrics().density + .5f); }
    private TextView label(String text) { TextView t = new TextView(this); t.setText(text); t.setTextColor(Color.rgb(195,170,255)); t.setTextSize(13); t.setPadding(0,pad(10),0,pad(4)); return t; }
    private EditText field(String hint, int type) { EditText e = new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextColor(Color.WHITE); e.setHintTextColor(0xff8d829e); e.setInputType(type); e.setPadding(pad(12),pad(10),pad(12),pad(10)); e.setBackgroundColor(0xff191326); return e; }
    private Button button(String text) { Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff713bd1)); return b; }
    @Override public void onCreate(Bundle state) { super.onCreate(state); getWindow().setStatusBarColor(0xff08060d); getWindow().setNavigationBarColor(0xff08060d);
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(0xff08060d);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(pad(18),pad(12),pad(18),pad(24)); scroll.addView(root); setContentView(scroll);
        TextView title=label("HTX // TERMINAL SH"); title.setTextColor(Color.WHITE); title.setTextSize(22); title.setGravity(Gravity.CENTER_VERTICAL); root.addView(title);
        TextView info=label("ADB WI-FI • Android 11 ou superior • mesma rede Wi-Fi"); root.addView(info);
        status=label("● DESconectado — aguardando pareamento"); status.setTextColor(0xffffc857); root.addView(status);
        root.addView(label("IP DO DISPOSITIVO")); host=field("Ex.: 192.168.1.10", android.text.InputType.TYPE_CLASS_TEXT); root.addView(host);
        root.addView(label("PORTA DE PAREAMENTO (tela 'Parear com código')")); pairPort=field("Ex.: 37123", android.text.InputType.TYPE_CLASS_NUMBER); root.addView(pairPort);
        root.addView(label("CÓDIGO DE PAREAMENTO (6 dígitos)")); pairCode=field("000000", android.text.InputType.TYPE_CLASS_NUMBER); root.addView(pairCode);
        root.addView(label("PORTA DE DEPURAÇÃO (tela principal Wireless debugging)")); connectPort=field("Ex.: 41235", android.text.InputType.TYPE_CLASS_NUMBER); root.addView(connectPort);
        Button pair=button("1 • PAREAR DISPOSITIVO"); root.addView(pair); pair.setOnClickListener(v -> pair());
        Button connect=button("2 • CONECTAR ADB"); root.addView(connect); connect.setOnClickListener(v -> connect());
        root.addView(label("COMANDO SHELL")); command=field("Digite um comando ADB shell", android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE); command.setSingleLine(false); root.addView(command);
        Button run=button("EXECUTAR COMANDO"); root.addView(run); run.setOnClickListener(v -> runCommand());
        Button optimize=button("OTIMIZAÇÃO SEGURA • DEXOPT"); root.addView(optimize); optimize.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Executar manutenção do Android?").setMessage("O comando solicita ao Package Manager a tarefa de otimização de código em segundo plano. Pode demorar e não libera RAM instantaneamente.").setNegativeButton("Cancelar",null).setPositiveButton("Executar",(d,w)->execute("cmd package bg-dexopt-job")).show());
        root.addView(label("SAÍDA DO TERMINAL")); output=new TextView(this); output.setTextColor(0xffd9d0e8); output.setTextSize(12); output.setTextIsSelectable(true); output.setPadding(pad(12),pad(12),pad(12),pad(12)); output.setBackgroundColor(0xff130f1c); root.addView(output);
        Button back=button("VOLTAR"); root.addView(back); back.setOnClickListener(v->finish());
        root.addView(label("Use apenas comandos que você entende. Comandos ADB podem alterar configurações, encerrar processos ou apagar dados. Desconecte a Depuração sem fio quando terminar."));
    }
    private void pair() { final String h=host.getText().toString().trim(), p=pairPort.getText().toString().trim(), c=pairCode.getText().toString().trim(); if(h.isEmpty()||p.isEmpty()||c.length()!=6){toast("Informe IP, porta de pareamento e código de 6 dígitos.");return;} work("Pareando…",()->{ adb=HtxAdbManager.get(); adb.pairDevice(h,Integer.parseInt(p),c); return "Pareamento concluído. Agora informe a porta da tela principal de Depuração sem fio e toque em CONECTAR ADB."; }); }
    private void connect() { final String h=host.getText().toString().trim(), p=connectPort.getText().toString().trim(); if(h.isEmpty()||p.isEmpty()){toast("Informe IP e porta de depuração.");return;} work("Conectando…",()->{ if(adb==null) adb=HtxAdbManager.get(); adb.connectDevice(h,Integer.parseInt(p)); return "ADB conectado. Terminal pronto."; }); }
    private void runCommand() { String c=command.getText().toString().trim(); if(c.isEmpty()){toast("Digite um comando.");return;} new AlertDialog.Builder(this).setTitle("Confirmar execução").setMessage("Executar no shell ADB?\n\n"+c).setNegativeButton("Cancelar",null).setPositiveButton("Executar",(d,w)->execute(c)).show(); }
    private interface Job { String run() throws Exception; }
    private void execute(String c) { work("Executando comando…",()->{ if(adb==null) throw new IllegalStateException("Conecte o ADB primeiro."); return adb.execute(c); }); }
    private void work(String message, Job job) { status.setText("● "+message); worker.execute(()->{ try { String result=job.run(); runOnUiThread(()->{status.setText("● ADB OPERACIONAL"); status.setTextColor(0xff54e6a0); output.setText(result.isEmpty()?"Comando enviado. O shell não retornou texto.":result);}); } catch(Exception e){ runOnUiThread(()->{status.setText("● FALHA NA OPERAÇÃO"); status.setTextColor(0xffff6b78); output.setText(e.getClass().getSimpleName()+": "+e.getMessage()+"\nConfira IP, portas, código, mesma rede e se a Depuração sem fio continua ativa.");}); } }); }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){ super.onDestroy(); worker.shutdownNow(); }
}
