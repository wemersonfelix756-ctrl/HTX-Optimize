package com.htx.optimize.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.htx.optimize.R;
import com.htx.optimize.monitor.SystemMonitor;
import com.htx.optimize.util.FormatUtils;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RamBoosterFragment extends Fragment {
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView tvStatus, tvReport;
    private ProgressBar progressBar;
    private Button btnRun;
    private boolean scanRunning;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_ram_booster, container, false);
    }

    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvStatus = view.findViewById(R.id.tv_booster_status);
        tvReport = view.findViewById(R.id.tv_booster_report);
        progressBar = view.findViewById(R.id.progress_booster_scan);
        btnRun = view.findViewById(R.id.btn_run_booster);
        if (btnRun != null) btnRun.setOnClickListener(v -> runSafeBoosterScan());
        View apps = view.findViewById(R.id.btn_booster_apps);
        if (apps != null) apps.setOnClickListener(v ->
                FormatUtils.safeStartActivity(requireContext(), new Intent(Settings.ACTION_APPLICATION_SETTINGS)));
        refreshCurrentState();
    }

    @Override public void onResume() {
        super.onResume();
        refreshCurrentState();
    }

    private void refreshCurrentState() {
        if (!isAdded() || getContext() == null || worker.isShutdown()) return;
        final android.content.Context appContext = requireContext().getApplicationContext();
        worker.execute(() -> {
            final SystemMonitor.RamSnapshot ram = SystemMonitor.readRam(appContext);
            mainHandler.post(() -> {
                if (!isAdded() || getView() == null || tvStatus == null) return;
                String diagnosis = ram.lowMemory || ram.usedPercent >= 82
                        ? "Diagnóstico: Pouca memória disponível. Recomenda-se fechar apps pesados abertos recentemente."
                        : "Diagnóstico: Disponibilidade de memória dentro da faixa normal.";
                tvStatus.setText(String.format(Locale.US,
                        "RAM disponível atual: %s de %s (%d%% usada)\n%s",
                        FormatUtils.formatBytes(ram.availBytes), FormatUtils.formatBytes(ram.totalBytes),
                        ram.usedPercent, diagnosis));
            });
        });
    }

    private void runSafeBoosterScan() {
        if (!isAdded() || getContext() == null || scanRunning || worker.isShutdown()) return;
        scanRunning = true;
        if (btnRun != null) btnRun.setEnabled(false);
        if (progressBar != null) {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setIndeterminate(true);
        }
        final android.content.Context appContext = requireContext().getApplicationContext();
        worker.execute(() -> {
            SystemMonitor.RamSnapshot before = SystemMonitor.readRam(appContext);
            // This request affects only the HTX process; Android manages other apps' processes.
            System.gc();
            SystemMonitor.RamSnapshot after = SystemMonitor.readRam(appContext);
            long delta = after.availBytes - before.availBytes;
            String deltaText = delta >= 0 ? "+" + FormatUtils.formatBytes(delta)
                    : "-" + FormatUtils.formatBytes(delta == Long.MIN_VALUE ? Long.MAX_VALUE : Math.abs(delta));
            mainHandler.post(() -> {
                scanRunning = false;
                if (!isAdded() || getView() == null) return;
                if (tvReport != null) tvReport.setText(String.format(Locale.US,
                        "Ações executadas:\n" +
                        "1. Leitura da telemetria de memória do sistema.\n" +
                        "2. Verificação de pressão de memória (lowMemory=%s).\n" +
                        "3. Solicitação de coleta de lixo (GC) apenas no processo do HTX Optimize.\n" +
                        "4. Variação observada na RAM disponível: %s (antes: %s | depois: %s).\n" +
                        "Nota: o Android gerencia os processos de outros aplicativos e não permite encerrá-los à força por um app comum.",
                        after.lowMemory, deltaText, FormatUtils.formatBytes(before.availBytes),
                        FormatUtils.formatBytes(after.availBytes)));
                if (progressBar != null) {
                    progressBar.setIndeterminate(false);
                    progressBar.setVisibility(View.GONE);
                }
                if (btnRun != null) btnRun.setEnabled(true);
                refreshCurrentState();
            });
        });
    }

    @Override public void onDestroyView() {
        scanRunning = false;
        if (progressBar != null) progressBar.setIndeterminate(false);
        tvStatus = null; tvReport = null; progressBar = null; btnRun = null;
        super.onDestroyView();
    }

    @Override public void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        worker.shutdownNow();
        super.onDestroy();
    }
}
