package com.htx.optimize;

import android.os.Bundle;
import android.view.View;
import androidx.annotation.IdRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.htx.optimize.fragments.HomeFragment;
import com.htx.optimize.fragments.RamBoosterFragment;
import com.htx.optimize.fragments.RamCleanerFragment;
import com.htx.optimize.fragments.StorageFragment;
import com.htx.optimize.fragments.ToolsFragment;

public class MainActivity extends AppCompatActivity {

    private static final String STATE_SELECTED_TAB = "htx.selected_tab";
    private BottomNavigationView bottomNavigation;
    private int selectedTabId = R.id.nav_home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View root = findViewById(R.id.root_layout);
        if (root != null) {
            final int left = root.getPaddingLeft();
            final int top = root.getPaddingTop();
            final int right = root.getPaddingRight();
            final int bottom = root.getPaddingBottom();
            ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
                Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                view.setPadding(left + bars.left, top + bars.top,
                        right + bars.right, bottom + bars.bottom);
                return insets;
            });
        }

        bottomNavigation = findViewById(R.id.bottom_navigation);
        if (savedInstanceState != null) {
            selectedTabId = savedInstanceState.getInt(STATE_SELECTED_TAB, R.id.nav_home);
        }

        if (bottomNavigation != null) {
            bottomNavigation.setOnItemSelectedListener(item -> {
                selectedTabId = item.getItemId();
                return showTab(selectedTabId);
            });

            if (savedInstanceState == null) {
                bottomNavigation.setSelectedItemId(R.id.nav_home);
            } else {
                bottomNavigation.setSelectedItemId(selectedTabId);
            }
        } else if (savedInstanceState == null) {
            showTab(R.id.nav_home);
        }
    }

    public void selectTab(@IdRes int menuItemId) {
        if (bottomNavigation != null && !isFinishing() && !isDestroyed()) {
            bottomNavigation.setSelectedItemId(menuItemId);
        }
    }

    private boolean showTab(@IdRes int id) {
        Fragment target;
        if (id == R.id.nav_ram_cleaner) {
            target = new RamCleanerFragment();
        } else if (id == R.id.nav_ram_booster) {
            target = new RamBoosterFragment();
        } else if (id == R.id.nav_storage) {
            target = new StorageFragment();
        } else if (id == R.id.nav_tools) {
            target = new ToolsFragment();
        } else {
            target = new HomeFragment();
            selectedTabId = R.id.nav_home;
        }

        FragmentManager manager = getSupportFragmentManager();
        if (isFinishing() || isDestroyed() || manager.isStateSaved()) {
            return false;
        }
        manager.beginTransaction()
                .setReorderingAllowed(true)
                .replace(R.id.fragment_container, target)
                .commit();
        return true;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putInt(STATE_SELECTED_TAB, selectedTabId);
        super.onSaveInstanceState(outState);
    }
}
