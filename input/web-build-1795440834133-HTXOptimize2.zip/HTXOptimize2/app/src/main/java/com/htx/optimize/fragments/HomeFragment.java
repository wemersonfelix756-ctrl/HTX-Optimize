package com.htx.optimize.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.htx.optimize.MainActivity;
import com.htx.optimize.R;
import com.htx.optimize.monitor.SystemMonitor;
import com.htx.optimize.ui.ArcGaugeView;
import com.htx.optimize.util.FormatUtils;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class HomeFragment extends Fragment {
    private static final long REFRESH_INTERVAL_MS = 5000L;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicBoolean refreshPending = new AtomicBoolean(false);
    private final Runnable refreshRunnable = new Runnable() {
        @Override public void run() {
            if (!isAdded() || !isResumed()) return;
            refreshAll();
            mainHandler.postDelayed(this, REFRESH_INTERVAL_MS);
        }
    };

    private TextView tvDeviceModel, tvAndroidVersion, tvRamDetails;
    private ArcGaugeView gaugeRam;
    private ProgressBar progressStorage, progressBattery;
    private TextView tvStoragePercent, tvStorageDetails, tvBatterySummary;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvDeviceModel = view.findViewById(R.id.tv_device_model);
        tvAndroidVersion = view.findViewById(R.id.tv_android_version);
        gaugeRam = view.findViewById(R.id.gauge_ram);
        tvRamDetails = view.findViewById(R.id.tv_ram_details);
        progressStorage = view.findViewById(R.id.progress_storage);
        tvStoragePercent = view.findViewById(R.id.tv_storage_percent);
        tvStorageDetails = view.findViewById(R.id.tv_storage_details);
        tvBatterySummary = view.findViewById(R.id.tv_battery_summary);
        progressBattery = view.findViewById(R.id.progress_battery);

        Button refresh = view.findViewById(R.id.btn_refresh_dashboard);
        if (refresh != null) refresh.setOnClickListener(v -> refreshAll());
        setQuickAction(view, R.id.btn_quick_cleaner, R.id.nav_ram_cleaner);
        setQuickAction(view, R.id.btn_quick_booster, R.id.nav_ram_booster);
        setQuickAction(view, R.id.btn_quick_storage, R.id.nav_storage);
        setQuickAction(view, R.id.btn_quick_tools, R.id.nav_tools);
        refreshAll();
    }

    private void setQuickAction(View root, int viewId, int tabId) {
        View action = root.findViewById(viewId);
        if (action != null) action.setOnClickListener(v -> openTab(tabId));
    }

    @Override public void onResume() {
        super.onResume();
        mainHandler.removeCallbacks(refreshRunnable);
        refreshAll();
        mainHandler.postDelayed(refreshRunnable, REFRESH_INTERVAL_MS);
    }

    @Override public void onPause() {
        mainHandler.removeCallbacks(refreshRunnable);
        super.onPause();
    }

    @Override public void onDestroyView() {
        mainHandler.removeCallbacks(refreshRunnable);
        tvDeviceModel = null; tvAndroidVersion = null; gaugeRam = null; tvRamDetails = null;
        progressStorage = null; tvStoragePercent = null; tvStorageDetails = null;
        tvBatterySummary = null; progressBattery = null;
        super.onDestroyView();
    }

    @Override public void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        worker.shutdownNow();
        super.onDestroy();
    }

    private void openTab(int menuId) {
        if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).selectTab(menuId);
    }

    private void refreshAll() {
        if (!isAdded() || getContext() == null || worker.isShutdown()
                || !refreshPending.compareAndSet(false, true)) return;
        final android.content.Context appContext = requireContext().getApplicationContext();
        worker.execute(() -> {
            final String model = SystemMonitor.getDeviceModel();
            final String android = SystemMonitor.getAndroidVersionSummary();
            final SystemMonitor.RamSnapshot ram = SystemMonitor.readRam(appContext);
            final SystemMonitor.StorageSnapshot storage = SystemMonitor.readInternalStorage();
            final SystemMonitor.BatterySnapshot battery = SystemMonitor.readBattery(appContext);
            mainHandler.post(() -> {
                refreshPending.set(false);
                if (!isAdded() || getView() == null) return;
                if (tvDeviceModel != null) tvDeviceModel.setText(model);
                if (tvAndroidVersion != null) tvAndroidVersion.setText(android);
                if (gaugeRam != null) gaugeRam.setProgressAnimated(ram.usedPercent, "RAM USADA");
                if (tvRamDetails != null) tvRamDetails.setText(String.format(Locale.US,
                        "Total: %s • Utilizada: %s • Disponível: %s",
                        FormatUtils.formatBytes(ram.totalBytes), FormatUtils.formatBytes(ram.usedBytes),
                        FormatUtils.formatBytes(ram.availBytes)));
                if (progressStorage != null) progressStorage.setProgress(storage.usedPercent);
                if (tvStoragePercent != null) tvStoragePercent.setText(storage.usedPercent + "% utilizado");
                if (tvStorageDetails != null) tvStorageDetails.setText(String.format(Locale.US,
                        "Total: %s • Usado: %s • Livre: %s", FormatUtils.formatBytes(storage.totalBytes),
                        FormatUtils.formatBytes(storage.usedBytes), FormatUtils.formatBytes(storage.freeBytes)));
                String temp = battery.temperatureCelsius != null
                        ? String.format(Locale.US, "%.1f °C", battery.temperatureCelsius) : "Temp. indisponível";
                if (tvBatterySummary != null) tvBatterySummary.setText(
                        (battery.levelPercent >= 0 ? battery.levelPercent + "%" : "N/D")
                                + " • " + temp + " • " + battery.statusText);
                if (progressBattery != null) progressBattery.setProgress(
                        battery.levelPercent >= 0 ? battery.levelPercent : 0);
            });
        });
    }
}
