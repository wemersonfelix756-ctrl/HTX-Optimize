package com.htx.optimize.adb;

import android.os.Build;
import androidx.annotation.NonNull;
import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import io.github.muntashirakon.adb.AdbStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.util.Date;
import java.util.Random;
import sun.security.x509.AlgorithmId;
import sun.security.x509.CertificateAlgorithmId;
import sun.security.x509.CertificateExtensions;
import sun.security.x509.CertificateIssuerName;
import sun.security.x509.CertificateSerialNumber;
import sun.security.x509.CertificateSubjectName;
import sun.security.x509.CertificateValidity;
import sun.security.x509.CertificateVersion;
import sun.security.x509.CertificateX509Key;
import sun.security.x509.KeyIdentifier;
import sun.security.x509.PrivateKeyUsageExtension;
import sun.security.x509.SubjectKeyIdentifierExtension;
import sun.security.x509.X500Name;
import sun.security.x509.X509CertImpl;
import sun.security.x509.X509CertInfo;

/** ADB transport for the device explicitly paired by the user. */
public final class HtxAdbManager extends AbsAdbConnectionManager {
    private static HtxAdbManager instance;
    private final PrivateKey privateKey;
    private final Certificate certificate;

    private HtxAdbManager() throws Exception {
        setApi(Build.VERSION.SDK_INT);
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(2048, new SecureRandom());
        KeyPair pair = generator.generateKeyPair();
        privateKey = pair.getPrivate();
        PublicKey publicKey = pair.getPublic();
        String algorithm = "SHA256withRSA";
        Date from = new Date();
        Date to = new Date(System.currentTimeMillis() + 365L * 24 * 60 * 60 * 1000);
        CertificateExtensions extensions = new CertificateExtensions();
        extensions.set("SubjectKeyIdentifier", new SubjectKeyIdentifierExtension(new KeyIdentifier(publicKey).getIdentifier()));
        X500Name name = new X500Name("CN=HTX Optimize ADB");
        X509CertInfo info = new X509CertInfo();
        info.set("version", new CertificateVersion(CertificateVersion.V3));
        info.set("serialNumber", new CertificateSerialNumber(new Random().nextInt() & 0x7fffffff));
        info.set("algorithmID", new CertificateAlgorithmId(AlgorithmId.get(algorithm)));
        info.set("subject", new CertificateSubjectName(name));
        info.set("key", new CertificateX509Key(publicKey));
        info.set("validity", new CertificateValidity(from, to));
        info.set("issuer", new CertificateIssuerName(name));
        info.set("extensions", extensions);
        X509CertImpl cert = new X509CertImpl(info);
        cert.sign(privateKey, algorithm);
        certificate = cert;
    }

    public static synchronized HtxAdbManager get() throws Exception {
        if (instance == null) instance = new HtxAdbManager();
        return instance;
    }

    @NonNull @Override protected PrivateKey getPrivateKey() { return privateKey; }
    @NonNull @Override protected Certificate getCertificate() { return certificate; }
    @NonNull @Override protected String getDeviceName() { return "HTX Optimize"; }

    public void pairDevice(String host, int port, String code) throws Exception {
        pair(host, port, code);
    }

    public void connectDevice(String host, int port) throws Exception {
        connect(host, port);
    }

    public String execute(String command) throws Exception {
        AdbStream stream = openStream("shell:");
        try {
            OutputStream out = stream.openOutputStream();
            InputStream in = stream.openInputStream();
            out.write((command + "\nexit\n").getBytes("UTF-8"));
            out.flush();
            ByteArrayOutputStream result = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            long deadline = System.currentTimeMillis() + 12000;
            while (System.currentTimeMillis() < deadline) {
                if (in.available() > 0) {
                    int count = in.read(buffer);
                    if (count < 0) break;
                    result.write(buffer, 0, count);
                } else {
                    Thread.sleep(80);
                }
            }
            return result.toString("UTF-8").trim();
        } finally {
            try { stream.close(); } catch (Exception ignored) { }
        }
    }
}
