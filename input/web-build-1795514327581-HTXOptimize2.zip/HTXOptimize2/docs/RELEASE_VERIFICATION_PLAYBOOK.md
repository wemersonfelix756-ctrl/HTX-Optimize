# HTX Optimize — release verification playbook

Use this playbook for each candidate release. Record the device, Android version,
build number, tester, date, and evidence for every result. A larger source archive
is not a substitute for passing these checks or producing a tested APK.

## Test record template

| Field | Value |
|---|---|
| App version | |
| Git commit | |
| Device / model | |
| Android version / API | |
| Build variant | |
| Tester / date | |
| Result and evidence location | |

## Startup and recovery

- [ ] **01.** Install over the previous version without clearing app data; confirm preferences and user-selected state behave as designed.
- [ ] **02.** Cold start after force-stopping HTX Optimize; confirm the launcher opens the home destination and no stale callback runs.
- [ ] **03.** Background the app during a screen refresh, return after several minutes, and confirm displayed values refresh without duplicate observers.
- [ ] **04.** Enable 'Don't keep activities' in developer options for a test session and navigate away and back; confirm state restoration is safe.
- [ ] **05.** Reboot the device and launch the app; confirm no assumption is made that a background process remained alive.

Record PASS, FAIL, BLOCKED, or NOT APPLICABLE and include a short note for every item.

## Navigation and rendering

- [ ] **01.** Visit each bottom navigation destination repeatedly and rapidly; verify only the selected destination is displayed.
- [ ] **02.** Rotate the device if the Activity supports rotation; verify selected destination and view state are restored without fragment transaction errors.
- [ ] **03.** Use Android font scaling at 1.0x, 1.3x, and the largest practical setting; verify labels remain readable and controls remain reachable.
- [ ] **04.** Test narrow and large displays, gesture navigation, and three-button navigation; confirm system bars do not cover controls.
- [ ] **05.** Use TalkBack to traverse headings, buttons, status values, and destructive controls; verify meaningful accessible labels.

Record PASS, FAIL, BLOCKED, or NOT APPLICABLE and include a short note for every item.

## RAM and process information

- [ ] **01.** Compare displayed device-wide RAM values with Android system settings and record any expected vendor-specific difference.
- [ ] **02.** Test a device with low available memory; confirm the app reports the system state without promising to kill other applications.
- [ ] **03.** Test a device or emulator that reports incomplete memory values; confirm zero/unknown values do not trigger divide-by-zero or misleading percentages.
- [ ] **04.** Keep the dashboard open while other applications are launched; verify monitoring refreshes do not block scrolling or touch input.
- [ ] **05.** Confirm the app never attempts hidden APIs or privileged process-killing operations.

Record PASS, FAIL, BLOCKED, or NOT APPLICABLE and include a short note for every item.

## Storage and document providers

- [ ] **01.** Select a small local file using the system picker; verify the displayed name and size are correct where provider metadata is available.
- [ ] **02.** Select a cloud-backed document; verify provider latency and temporary unavailability are handled without freezing the main thread.
- [ ] **03.** Revoke or remove access to a previously selected document; verify the app reports access loss and does not crash.
- [ ] **04.** Delete a user-selected file only after explicit confirmation; verify a failed provider delete is not shown as successful.
- [ ] **05.** Test filenames containing accents, emoji, spaces, and punctuation; ensure display and logging remain safe.
- [ ] **06.** Test a provider that returns a null display name, unknown MIME type, or unknown size; show safe fallback text.
- [ ] **07.** Test an empty folder and a folder with many entries; ensure empty state is clear and enumeration is not performed on the UI thread.
- [ ] **08.** Test duplicate display names from different providers; use URI identity rather than display name as the unique key.

Record PASS, FAIL, BLOCKED, or NOT APPLICABLE and include a short note for every item.

## Battery and device telemetry

- [ ] **01.** Test while charging, discharging, full, and with the battery intent unavailable; verify each state maps to a truthful label.
- [ ] **02.** Test devices where temperature or voltage is not exposed; show unavailable rather than fabricated telemetry.
- [ ] **03.** Compare reported temperature units with the platform intent and confirm tenths-of-a-degree conversion is correct.
- [ ] **04.** Confirm telemetry collection is local and no data is transmitted without a separately disclosed, consented feature.

Record PASS, FAIL, BLOCKED, or NOT APPLICABLE and include a short note for every item.

## Permissions, privacy, and security

- [ ] **01.** Fresh install: deny each requested permission and confirm core screens remain stable.
- [ ] **02.** Grant a permission, use the feature, revoke permission in Settings, and retry; the app must re-check access at point of use.
- [ ] **03.** Inspect Logcat during file browsing and deletion; ensure document contents, credentials, and sensitive paths are not logged.
- [ ] **04.** Inspect the manifest and request only permissions that correspond to implemented features.
- [ ] **05.** Verify release builds do not contain debug secrets, test credentials, private keystores, or verbose diagnostic endpoints.
- [ ] **06.** Review dependencies and licenses before publishing; record the dependency versions used for the release.

Record PASS, FAIL, BLOCKED, or NOT APPLICABLE and include a short note for every item.

## Build and release

- [ ] **01.** Run the Gradle wrapper from a clean checkout and record the JDK, Gradle, Android Gradle Plugin, and SDK versions.
- [ ] **02.** Run JVM unit tests and confirm failures stop the release pipeline.
- [ ] **03.** Run Android lint and review new warnings rather than suppressing them blindly.
- [ ] **04.** Build debug and release variants; install each on a physical device and smoke-test all primary destinations.
- [ ] **05.** Sign the release with a private key held outside the repository; verify the signing certificate before distribution.
- [ ] **06.** Calculate and publish the APK SHA-256 checksum alongside the release notes.
- [ ] **07.** Keep the previous known-good APK and source revision available for rollback.

Record PASS, FAIL, BLOCKED, or NOT APPLICABLE and include a short note for every item.

## Release decision

Do not publish if startup, navigation, data deletion, permission handling, or release signing
has an unresolved failure. Document known limitations in the release notes. A debug APK
is not a substitute for a signed release APK.
