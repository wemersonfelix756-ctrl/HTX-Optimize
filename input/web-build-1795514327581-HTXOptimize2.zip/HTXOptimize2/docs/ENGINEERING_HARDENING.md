# HTX Optimize 2.3 — Engineering and hardening notes

## Scope of this release

This release intentionally preserves the existing Android layouts, colors, drawables,
navigation appearance, and branding. Work is limited to application behavior,
defensive programming, maintainability, and regression coverage.

## Runtime safety

- System readings are treated as snapshots, not promises that Android will grant
  the app control over system-wide resources.
- RAM and storage values are clamped to valid ranges before percentages are derived.
- Arithmetic that combines filesystem block counts and block sizes is guarded
  against overflow.
- Battery data can be absent on emulators, restricted devices, and vendor builds;
  callers receive an explicit unavailable snapshot rather than a crash.
- Activity launches should be resolved and guarded because settings screens vary
  across Android versions and manufacturers.
- Fragment transactions are not committed after the Activity has saved state.

## Android platform boundaries

Android deliberately restricts applications from force-stopping other apps,
clearing another app's private cache, changing hidden process priorities, or
promising a universal "RAM boost". HTX Optimize must not claim those operations
were completed unless the operating system exposes a supported API and confirms
the result. The app should guide users to the relevant system settings when an
operation requires privileged access.

Storage browsing should use the Storage Access Framework and user-granted URI
permissions. A selected document must be revalidated before deletion because it
may have been moved, removed, or become inaccessible after the list was loaded.
Never recursively delete directories without explicit user selection and a clear
confirmation step.

## Lifecycle rules

- Stop Handler callbacks, polling loops, and observers when their owner is no
  longer active.
- Do not retain an Activity or View in a static field.
- Re-check Activity state before showing dialogs or committing Fragment changes.
- Keep expensive file enumeration off the main thread.
- Return to the main thread only for UI updates.
- Cancel work when the screen is destroyed or the user leaves the operation.

## Input and file handling

- Treat display names and MIME types from document providers as untrusted.
- Handle null names, null MIME types, unknown sizes, and provider exceptions.
- Use content URIs rather than converting arbitrary URI strings into filesystem
  paths.
- Do not assume that a URI remains readable after process recreation unless the
  persistable permission was actually granted.
- Avoid logging private file names, document contents, or personally identifying
  information.

## Monitoring accuracy

RAM usage reported by ActivityManager is device-wide system information and is
not equivalent to the amount of memory the app can reclaim. Android's memory
manager owns process reclamation. A high RAM percentage alone is not evidence
that the phone needs cleaning.

Storage statistics for the app data partition do not represent all user-visible
storage on every device. Label the source clearly in the UI and avoid presenting
an estimate as an exact whole-device total.

Battery temperature and voltage are optional hardware telemetry. Values may be
missing or vendor-specific. Do not infer battery health from temperature alone.

## Regression test strategy

The JVM tests cover deterministic logic that does not require an Android device:
- RAM snapshot clamping and percentage calculation.
- Storage snapshot clamping and percentage calculation.
- Byte formatting at byte, KiB, and MiB boundaries.

Device-level verification is still required for:
- Runtime permission and Storage Access Framework flows.
- Navigation across all five bottom-navigation destinations.
- Activity recreation and process death restoration.
- Battery broadcasts and OEM-specific telemetry.
- File-provider behavior for cloud and local document providers.
- Accessibility, screen sizes, and Android API levels supported by the project.

## Release checklist

1. Run `./gradlew testDebugUnitTest`.
2. Run `./gradlew lint`.
3. Run `./gradlew assembleDebug`.
4. Install the debug APK on a physical device.
5. Exercise every navigation destination and every destructive action.
6. Verify that denied permissions produce an explanation, not a crash.
7. Inspect Logcat for uncaught exceptions and leaked callbacks.
8. Build a signed release APK using a private signing key stored outside source
   control.
9. Test the signed APK after installation, not only the debug build.

## Security and privacy checklist

- Keep signing keys, passwords, tokens, and keystore properties out of Git.
- Request only permissions that correspond to a visible feature.
- Explain why a permission is needed before opening the system permission flow.
- Do not upload device telemetry without explicit user consent.
- Do not silently delete user content.
- Avoid analytics that collect file names, document paths, or content.
- Keep third-party dependencies current and review their licenses.

## Known limitations

This archive contains source code and project configuration. It is not proof that
a release APK has been built or tested. Build and device validation must be
performed in an Android SDK environment. Features dependent on OEM APIs may behave
differently between devices and must degrade gracefully.
