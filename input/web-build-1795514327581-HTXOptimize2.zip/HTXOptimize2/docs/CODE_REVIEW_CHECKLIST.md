# HTX Optimize — code review checklist

This checklist is intended for every pull request that changes application logic.
Mark an item not applicable only when the reviewer records why it does not apply.

## Correctness
- [ ] The change solves the reported behavior and does not merely hide the error.
- [ ] Empty, null, unavailable, and malformed platform values are handled.
- [ ] Boundary values are tested, including zero, negative input, and maximum values.
- [ ] Units are explicit and conversions are checked.
- [ ] Integer arithmetic cannot overflow for supported device values.
- [ ] Partial failure is represented honestly; success is not reported for failed work.
- [ ] The user can cancel long-running work where cancellation is meaningful.

## Android lifecycle
- [ ] No Activity, Fragment, View, or Context is retained in a static field.
- [ ] Callbacks are removed when their owner is detached or destroyed.
- [ ] Background work does not update a destroyed View.
- [ ] Fragment transactions are not committed after state has been saved.
- [ ] Configuration changes do not create duplicate observers or polling loops.
- [ ] Work that must survive process death uses an appropriate persistent work API.
- [ ] Main-thread work is limited to short operations and UI rendering.

## Threading and performance
- [ ] Directory enumeration, provider queries, and file operations run off the UI thread.
- [ ] UI updates are marshalled to the main thread.
- [ ] Repeated refreshes do not queue unbounded work.
- [ ] Lists have stable identity and do not rely on display names as unique keys.
- [ ] Large result sets are paged or otherwise bounded where practical.
- [ ] Animations and periodic updates stop when not visible.
- [ ] Errors are surfaced without blocking the main thread.

## Storage safety
- [ ] User files are accessed through supported document APIs.
- [ ] URI permissions are checked at the time of use.
- [ ] Destructive operations require a clear user action and confirmation.
- [ ] A failed provider operation is never reported as success.
- [ ] Recursive deletion is not performed implicitly.
- [ ] Cloud-provider delays and provider process failures are handled.
- [ ] Unknown metadata is not represented as a fabricated exact value.

## Privacy and security
- [ ] Only necessary permissions are requested.
- [ ] Permission rationale is clear and tied to a visible feature.
- [ ] Sensitive content is not written to logs.
- [ ] Secrets and signing material are absent from source control.
- [ ] External input is validated before use.
- [ ] Dependencies are pinned and reviewed.
- [ ] Network features, if introduced, use TLS and disclose data collection.
- [ ] No hidden, privileged, or undocumented API is required for core functionality.

## UI preservation
- [ ] Existing layout XML is unchanged unless the task explicitly authorizes a visual change.
- [ ] Existing colors, dimensions, icons, typography, and navigation presentation are preserved.
- [ ] New errors use the existing visual language.
- [ ] Accessibility labels and touch targets remain usable.
- [ ] Text scaling and localization do not break critical controls.

## Build and delivery
- [ ] Gradle wrapper and plugin versions are reproducible.
- [ ] Unit tests pass.
- [ ] Lint results are reviewed.
- [ ] Debug APK installs and launches.
- [ ] Release APK is signed with the intended certificate.
- [ ] Upgrade installation is tested.
- [ ] Release notes describe limitations and behavior changes.
- [ ] SHA-256 checksum is generated for the distributed artifact.

## Reviewer notes

**Risk introduced:**

**Tests executed:**

**Devices / API levels verified:**

**Known limitations:**

**Approval:**
