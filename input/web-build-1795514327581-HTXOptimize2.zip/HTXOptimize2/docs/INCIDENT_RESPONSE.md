# HTX Optimize — incident response and diagnostics

## When startup fails

1. Capture the complete Logcat exception, including the first `Caused by` entry.
2. Record the Android version, device manufacturer, app version, and build variant.
3. Identify whether the failure occurs before or after `setContentView`.
4. For an XML inflation error, inspect the exact layout line and the deepest nested cause.
5. Verify every custom View has the required constructors and every referenced resource exists.
6. Check Material component theme requirements and dependency compatibility.
7. Reproduce on a clean install and on an upgrade install before declaring the issue fixed.

Do not treat the top-level `InflateException` as the root cause. The deepest nested
exception usually identifies the unsupported attribute, missing class, constructor
failure, or invalid resource.

## When monitoring looks incorrect

- Compare raw platform values before formatting.
- Confirm bytes and percentages are not mixed.
- Verify unknown values remain unknown instead of being converted to zero where zero
  would imply a real measurement.
- Record the device/API combination because OEM implementations can differ.
- Avoid claiming performance improvements from a single before/after RAM sample.

## When a file action fails

- Keep the original URI and provider authority available for diagnosis, but do not
  log private document names or contents.
- Re-check whether the URI permission is still granted.
- Query provider metadata again; cached metadata may be stale.
- Report partial results accurately if a batch operation contains both successes
  and failures.
- Never silently retry a destructive operation without user awareness.

## Diagnostic information to collect

Collect only information needed to reproduce the fault:
- app version and build variant;
- Android API level and device model;
- exception class and stack trace;
- screen or action that triggered the fault;
- whether the issue reproduces after a clean install.

Do not collect account passwords, document contents, personal photos, contact lists,
or unrelated device identifiers. Remove tokens and private paths before sharing logs.

## Severity guidance

- Critical: app cannot launch, user data is lost, or private data is exposed.
- High: core navigation or a destructive action fails for a broad device range.
- Medium: a major feature is unavailable but the rest of the app remains usable.
- Low: cosmetic or isolated issue with a safe workaround.

## Fix verification

A fix is not complete merely because the exception disappears on one emulator.
Re-run the original reproduction steps, test at least one supported physical device,
run the regression suite, and confirm that neighboring flows still work.
