#!/usr/bin/env python3
"""Fast structural checks for HTX Optimize resources before Android compilation."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "app" / "src" / "main" / "res"
JAVA = ROOT / "app" / "src" / "main" / "java"
errors = []
xml_files = list(RES.rglob("*.xml"))
for path in xml_files:
    try:
        ET.parse(path)
    except ET.ParseError as exc:
        errors.append(f"XML inválido: {path.relative_to(ROOT)}: {exc}")

known_ids = set()
for path in xml_files:
    content = path.read_text(encoding="utf-8")
    known_ids.update(re.findall(r"@\+id/([A-Za-z0-9_]+)", content))
    known_ids.update(re.findall(r"@id/([A-Za-z0-9_]+)", content))

for path in JAVA.rglob("*.java"):
    content = path.read_text(encoding="utf-8")
    for resource_id in re.findall(r"R\.id\.([A-Za-z0-9_]+)", content):
        if resource_id not in known_ids:
            errors.append(f"ID não encontrado: {resource_id} em {path.relative_to(ROOT)}")

menu = RES / "menu" / "bottom_nav_menu.xml"
if menu.exists():
    try:
        tree = ET.parse(menu)
        items = tree.getroot().findall("item")
        if len(items) > 5:
            errors.append(f"BottomNavigationView tem {len(items)} itens; o limite recomendado é 5.")
    except ET.ParseError:
        pass

if errors:
    print("\n".join(errors), file=sys.stderr)
    sys.exit(1)
print(f"Verificação estrutural concluída: {len(xml_files)} XMLs válidos; IDs Java resolvidos.")
