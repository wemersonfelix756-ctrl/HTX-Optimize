package com.htx.optimize.monitor;

import org.junit.Test;
import static org.junit.Assert.*;

public class SystemMonitorSnapshotTest {
    @Test public void ramSnapshotClampsInvalidInputs() {
        SystemMonitor.RamSnapshot snapshot =
                new SystemMonitor.RamSnapshot(1000L, 1200L, true, -10L);
        assertEquals(1000L, snapshot.totalBytes);
        assertEquals(1000L, snapshot.availBytes);
        assertEquals(0L, snapshot.usedBytes);
        assertEquals(0, snapshot.usedPercent);
        assertEquals(0L, snapshot.thresholdBytes);
        assertTrue(snapshot.lowMemory);
    }

    @Test public void ramSnapshotCalculatesUsage() {
        SystemMonitor.RamSnapshot snapshot =
                new SystemMonitor.RamSnapshot(8000L, 2000L, false, 500L);
        assertEquals(6000L, snapshot.usedBytes);
        assertEquals(75, snapshot.usedPercent);
    }

    @Test public void zeroTotalRamDoesNotDivideByZero() {
        SystemMonitor.RamSnapshot snapshot =
                new SystemMonitor.RamSnapshot(0L, 0L, false, 0L);
        assertEquals(0, snapshot.usedPercent);
    }

    @Test public void storageSnapshotClampsFreeSpace() {
        SystemMonitor.StorageSnapshot snapshot =
                new SystemMonitor.StorageSnapshot(500L, 900L);
        assertEquals(500L, snapshot.freeBytes);
        assertEquals(0L, snapshot.usedBytes);
        assertEquals(0, snapshot.usedPercent);
    }

    @Test public void storageSnapshotCalculatesUsedSpace() {
        SystemMonitor.StorageSnapshot snapshot =
                new SystemMonitor.StorageSnapshot(10000L, 2500L);
        assertEquals(7500L, snapshot.usedBytes);
        assertEquals(75, snapshot.usedPercent);
    }
}
