package com.htx.optimize.util;

import org.junit.Test;
import static org.junit.Assert.*;

public class FormatUtilsTest {
    @Test public void formatsNegativeBytesAsUnavailable() {
        assertEquals("Indisponível", FormatUtils.formatBytes(-1L));
    }
    @Test public void formatsBytesBelowOneKilobyte() {
        assertEquals("0 B", FormatUtils.formatBytes(0L));
        assertEquals("512 B", FormatUtils.formatBytes(512L));
    }
    @Test public void formatsKilobytes() {
        assertEquals("1.00 KB", FormatUtils.formatBytes(1024L));
    }
    @Test public void formatsMegabytes() {
        assertEquals("1.00 MB", FormatUtils.formatBytes(1024L * 1024L));
    }
}
