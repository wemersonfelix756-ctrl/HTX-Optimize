package com.htx.optimize.monitor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Interpretação pura (sem Android) das saídas de dumpsys usadas para medir o FPS real. */
public final class FpsParser {

    public static final class Result {
        public final float fps;
        public final long maxTs;
        public final boolean valid;
        public final long[] intervalsNs; // tempos entre quadros novos (para 1% low etc.)

        Result(float fps, long maxTs, boolean valid, long[] intervalsNs) {
            this.fps = fps;
            this.maxTs = maxTs;
            this.valid = valid;
            this.intervalsNs = intervalsNs;
        }
    }

    private static final long PENDING_TS = Long.MAX_VALUE / 2;
    private static final long[] NO_INTERVALS = new long[0];
    private static final Pattern FOCUS_PKG = Pattern.compile("\\bu\\d+\\s+([A-Za-z0-9_.]+)/");
    private static final String PROFILE_MARK = "---PROFILEDATA---";

    private FpsParser() { }

    /**
     * Saída de "dumpsys SurfaceFlinger --latency <layer>": 1ª linha = período; depois 3 colunas
     * (desired, actual present, frame ready). Usa a 2ª coluna e cai para a 3ª/1ª se vier vazia.
     */
    public static Result compute(String output, long prevMaxTs) {
        if (output == null) return new Result(0f, 0L, false, NO_INTERVALS);
        String[] lines = output.split("\n");
        int[] order = {1, 2, 0};
        Result best = null;
        for (int column : order) {
            List<Long> stamps = new ArrayList<>();
            for (int i = 1; i < lines.length; i++) {
                String[] parts = lines[i].trim().split("\\s+");
                if (parts.length < 3) continue;
                try {
                    long value = Long.parseLong(parts[column]);
                    if (value > 0L && value < PENDING_TS) stamps.add(value);
                } catch (NumberFormatException ignored) {
                    // linha inválida
                }
            }
            if (stamps.size() >= 2) return fromStamps(stamps, prevMaxTs);
            if (best == null && !stamps.isEmpty()) best = fromStamps(stamps, prevMaxTs);
        }
        return best != null ? best : new Result(0f, 0L, false, NO_INTERVALS);
    }

    /** Saída de "dumpsys gfxinfo <pkg> framestats" (apps com UI padrão). */
    public static Result computeFramestats(String output, long prevMaxTs) {
        if (output == null) return new Result(0f, 0L, false, NO_INTERVALS);
        int start = output.indexOf(PROFILE_MARK);
        if (start < 0) return new Result(0f, 0L, false, NO_INTERVALS);
        String after = output.substring(start + PROFILE_MARK.length());
        int end = after.indexOf(PROFILE_MARK);
        String block = (end >= 0 ? after.substring(0, end) : after).trim();
        String[] lines = block.split("\n");
        if (lines.length < 2) return new Result(0f, 0L, false, NO_INTERVALS);

        String[] header = lines[0].split(",");
        int column = -1;
        for (int i = 0; i < header.length; i++) {
            if (header[i].trim().equals("FrameCompleted")) { column = i; break; }
        }
        if (column < 0) return new Result(0f, 0L, false, NO_INTERVALS);

        List<Long> stamps = new ArrayList<>();
        for (int i = 1; i < lines.length; i++) {
            String[] cols = lines[i].trim().split(",");
            if (column >= cols.length) continue;
            try {
                long value = Long.parseLong(cols[column].trim());
                if (value > 0L && value < PENDING_TS) stamps.add(value);
            } catch (NumberFormatException ignored) {
                // linha inválida
            }
        }
        return stamps.isEmpty() ? new Result(0f, 0L, false, NO_INTERVALS) : fromStamps(stamps, prevMaxTs);
    }

    private static Result fromStamps(List<Long> stamps, long prevMaxTs) {
        Collections.sort(stamps);
        long max = stamps.get(stamps.size() - 1);
        if (max == prevMaxTs) return new Result(0f, max, true, NO_INTERVALS); // nenhum quadro novo

        List<Long> fresh = new ArrayList<>();
        for (int i = 1; i < stamps.size(); i++) {
            long gap = stamps.get(i) - stamps.get(i - 1);
            if (stamps.get(i) > prevMaxTs && gap > 0L && gap <= 1_000_000_000L) fresh.add(gap);
        }
        long[] intervals = new long[fresh.size()];
        for (int i = 0; i < intervals.length; i++) intervals[i] = fresh.get(i);

        long windowStart = max - 1_000_000_000L;
        long first = max;
        int count = 0;
        for (long ts : stamps) {
            if (ts >= windowStart) {
                count++;
                if (ts < first) first = ts;
            }
        }
        long span = max - first;
        if (count < 2 || span <= 0L) return new Result(1f, max, true, intervals);
        float fps = (count - 1) * 1_000_000_000f / span;
        return new Result(Math.min(fps, 240f), max, true, intervals);
    }

    /**
     * Saída de "dumpsys SurfaceFlinger --timestats -dump": contador totalFrames por camada.
     * Devolve camada -> totalFrames só das camadas do pacote (por nome ou por packageName).
     */
    public static Map<String, Long> parseTimeStats(String dump, String pkg) {
        Map<String, Long> result = new LinkedHashMap<>();
        if (dump == null || pkg == null) return result;
        String name = null;
        String pkgLine = null;
        long total = -1L;
        for (String raw : dump.split("\n")) {
            String line = raw.trim();
            if (line.startsWith("layerName = ")) {
                flushLayer(result, pkg, name, pkgLine, total);
                name = line.substring("layerName = ".length()).trim();
                pkgLine = null;
                total = -1L;
            } else if (name != null && line.startsWith("packageName = ")) {
                pkgLine = line.substring("packageName = ".length()).trim();
            } else if (name != null && line.startsWith("totalFrames = ") && total < 0L) {
                try {
                    total = Long.parseLong(line.substring("totalFrames = ".length()).trim());
                } catch (NumberFormatException ignored) {
                    total = -1L;
                }
            }
        }
        flushLayer(result, pkg, name, pkgLine, total);
        return result;
    }

    private static void flushLayer(Map<String, Long> out, String pkg, String name, String pkgLine, long total) {
        if (name == null || total < 0L) return;
        if (name.contains(pkg) || pkg.equals(pkgLine)) out.put(name, total);
    }

    /** Pacote em foco a partir das linhas mCurrentFocus / mFocusedApp do "dumpsys window". */
    public static String parseFocusedPackage(String text) {
        if (text == null) return null;
        String fallback = null;
        for (String line : text.split("\n")) {
            boolean current = line.contains("mCurrentFocus") && !line.contains("=null");
            boolean app = line.contains("mFocusedApp") && !line.contains("=null");
            if (!current && !app) continue;
            Matcher m = FOCUS_PKG.matcher(line);
            if (!m.find()) continue;
            if (current) return m.group(1);
            if (fallback == null) fallback = m.group(1);
        }
        return fallback;
    }

    /** Camadas candidatas (SurfaceView primeiro) do "dumpsys SurfaceFlinger --list". */
    public static List<String> pickLayers(String list, String pkg, int max) {
        List<String> found = new ArrayList<>();
        if (list == null || pkg == null) return found;
        for (String raw : list.split("\n")) {
            String line = raw.trim();
            if (line.isEmpty() || !line.contains(pkg)) continue;
            if (line.startsWith("Background for") || line.startsWith("Bounds for")
                    || line.startsWith("Letterbox") || line.startsWith("Dim layer")
                    || line.startsWith("ActivityRecord") || line.startsWith("WindowToken")) continue;
            if (!found.contains(line)) found.add(line);
        }
        Collections.sort(found, new Comparator<String>() {
            @Override public int compare(String a, String b) {
                return Integer.compare(rank(a), rank(b));
            }
        });
        return found.size() > max ? new ArrayList<>(found.subList(0, max)) : found;
    }

    private static int rank(String layer) {
        if (layer.startsWith("SurfaceView")) return 0;
        if (layer.contains("/") && layer.contains("#")) return 1;
        return 2;
    }

    public static String quote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    public static String buildLatencyCommand(List<String> layers) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < layers.size(); i++) {
            sb.append("echo '@@L").append(i).append("'; dumpsys SurfaceFlinger --latency ")
                    .append(quote(layers.get(i))).append("; ");
        }
        return sb.toString();
    }

    public static List<String> splitSections(String output, int count) {
        List<StringBuilder> builders = new ArrayList<>();
        for (int i = 0; i < count; i++) builders.add(new StringBuilder());
        int current = -1;
        if (output != null) {
            for (String line : output.split("\n")) {
                String t = line.trim();
                if (t.startsWith("@@L")) {
                    try {
                        current = Integer.parseInt(t.substring(3));
                    } catch (NumberFormatException e) {
                        current = -1;
                    }
                } else if (current >= 0 && current < count) {
                    builders.get(current).append(line).append('\n');
                }
            }
        }
        List<String> result = new ArrayList<>();
        for (StringBuilder b : builders) result.add(b.toString());
        return result;
    }
}
