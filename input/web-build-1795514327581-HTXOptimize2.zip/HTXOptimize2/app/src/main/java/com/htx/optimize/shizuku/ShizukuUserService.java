package com.htx.optimize.shizuku;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/** Roda no processo shell do Shizuku (uid 2000): executa comandos pedidos pelo app. */
public class ShizukuUserService extends IUserService.Stub {

    private static final int MAX_OUTPUT = 300_000;

    public ShizukuUserService() { }

    @Override public void destroy() {
        System.exit(0);
    }

    @Override public String exec(String command) {
        StringBuilder out = new StringBuilder();
        try {
            ProcessBuilder builder = new ProcessBuilder("sh", "-c", command);
            builder.redirectErrorStream(true);
            Process process = builder.start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (out.length() < MAX_OUTPUT) out.append(line).append('\n');
                }
            }
            process.waitFor();
        } catch (Exception exception) {
            out.append("ERRO: ").append(exception.getMessage());
        }
        return out.toString();
    }
}
