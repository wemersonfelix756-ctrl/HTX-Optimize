package com.htx.optimize.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.htx.optimize.MainActivity;
import com.htx.optimize.R;
import com.htx.optimize.monitor.SystemMonitor;
import com.htx.optimize.monitor.ThermalReader;
import com.htx.optimize.optimizer.RamOptimizer;
import com.htx.optimize.shizuku.ShizukuBridge;
import com.htx.optimize.util.AppPrefs;
import com.htx.optimize.overlay.OverlayService;
import com.htx.optimize.util.PermissionHelper;
import androidx.core.content.ContextCompat;
import com.htx.optimize.ui.ArcGaugeView;
import com.htx.optimize.util.FormatUtils;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class HomeFragment extends Fragment {
    private static final long REFRESH_INTERVAL_MS = 5000L;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicBoolean refreshPending = new AtomicBoolean(false);
    private final Runnable refreshRunnable = new Runnable() {
        @Override public void run() {
            if (!isAdded() || !isResumed()) return;
            refreshAll();
            mainHandler.postDelayed(this, REFRESH_INTERVAL_MS);
        }
    };

    private TextView tvDeviceModel, tvAndroidVersion, tvRamDetails;
    private ArcGaugeView gaugeRam;
    private ProgressBar progressStorage, progressBattery;
    private TextView tvStoragePercent, tvStorageDetails, tvBatterySummary;
    private TextView tvOverlayStatus, tvPermStatus, tvGameStatus;
    private Button btnGameMode;
    private boolean gameRunning;
    private Button btnToggleOverlay;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvDeviceModel = view.findViewById(R.id.tv_device_model);
        tvAndroidVersion = view.findViewById(R.id.tv_android_version);
        gaugeRam = view.findViewById(R.id.gauge_ram);
        tvRamDetails = view.findViewById(R.id.tv_ram_details);
        progressStorage = view.findViewById(R.id.progress_storage);
        tvStoragePercent = view.findViewById(R.id.tv_storage_percent);
        tvStorageDetails = view.findViewById(R.id.tv_storage_details);
        tvBatterySummary = view.findViewById(R.id.tv_battery_summary);
        progressBattery = view.findViewById(R.id.progress_battery);

        tvGameStatus = view.findViewById(R.id.tv_game_status);
        btnGameMode = view.findViewById(R.id.btn_game_mode);
        if (btnGameMode != null) btnGameMode.setOnClickListener(v -> startGameMode());
        tvOverlayStatus = view.findViewById(R.id.tv_overlay_status);
        tvPermStatus = view.findViewById(R.id.tv_perm_status);
        btnToggleOverlay = view.findViewById(R.id.btn_toggle_overlay);
        if (btnToggleOverlay != null) btnToggleOverlay.setOnClickListener(v -> toggleOverlay());
        View grant = view.findViewById(R.id.btn_grant_permissions);
        if (grant != null) grant.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).startPermissionFlow();
        });
        updateOverlayUi();

        Button refresh = view.findViewById(R.id.btn_refresh_dashboard);
        if (refresh != null) refresh.setOnClickListener(v -> refreshAll());
        setQuickAction(view, R.id.btn_quick_cleaner, R.id.nav_ram_cleaner);
        setQuickAction(view, R.id.btn_quick_booster, R.id.nav_ram_booster);
        setQuickAction(view, R.id.btn_quick_storage, R.id.nav_storage);
        setQuickAction(view, R.id.btn_quick_tools, R.id.nav_tools);
        refreshAll();
    }

    private void setQuickAction(View root, int viewId, int tabId) {
        View action = root.findViewById(viewId);
        if (action != null) action.setOnClickListener(v -> openTab(tabId));
    }

    @Override public void onResume() {
        super.onResume();
        mainHandler.removeCallbacks(refreshRunnable);
        refreshAll();
        updateOverlayUi();
        mainHandler.postDelayed(refreshRunnable, REFRESH_INTERVAL_MS);
    }

    @Override public void onPause() {
        mainHandler.removeCallbacks(refreshRunnable);
        super.onPause();
    }

    @Override public void onDestroyView() {
        mainHandler.removeCallbacks(refreshRunnable);
        tvDeviceModel = null; tvAndroidVersion = null; gaugeRam = null; tvRamDetails = null;
        progressStorage = null; tvStoragePercent = null; tvStorageDetails = null;
        tvBatterySummary = null; progressBattery = null;
        tvOverlayStatus = null; tvPermStatus = null; btnToggleOverlay = null;
        tvGameStatus = null; btnGameMode = null;
        super.onDestroyView();
    }

    @Override public void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        worker.shutdownNow();
        super.onDestroy();
    }

    private void startGameMode() {
        if (!isAdded() || getContext() == null || gameRunning || worker.isShutdown()) return;
        gameRunning = true;
        if (btnGameMode != null) btnGameMode.setEnabled(false);
        if (tvGameStatus != null) tvGameStatus.setText("Preparando o modo jogo...");
        final android.content.Context appContext = requireContext().getApplicationContext();
        worker.execute(() -> {
            boolean deep = AppPrefs.deepBoost(appContext)
                    && ShizukuBridge.awaitConnected(appContext, 2500L);
            final RamOptimizer.Result r = RamOptimizer.run(appContext, deep ? ShizukuBridge::exec : null);
            final boolean deepUsed = deep;
            mainHandler.post(() -> {
                gameRunning = false;
                if (!isAdded() || getView() == null) return;
                if (btnGameMode != null) btnGameMode.setEnabled(true);
                boolean overlayOk = PermissionHelper.hasOverlay(appContext);
                if (overlayOk && !OverlayService.isRunning()) {
                    ContextCompat.startForegroundService(appContext,
                            new Intent(appContext, OverlayService.class).setAction(OverlayService.ACTION_START));
                }
                long delta = r.deltaBytes();
                String ram = delta > 0 ? "+" + com.htx.optimize.util.FormatUtils.formatBytes(delta)
                        + " de RAM livre" : "RAM já estava otimizada";
                if (tvGameStatus != null) tvGameStatus.setText(
                        "✔ Modo jogo ativo • " + ram + " • " + r.requested + " app(s) encerrado(s)"
                                + (deepUsed ? " (profundo)" : "")
                                + (overlayOk ? " • monitor ligado" : "\nConceda 'Sobrepor apps' para ligar a janelinha."));
                if (!overlayOk && getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).startPermissionFlow();
                }
                mainHandler.postDelayed(this::updateOverlayUi, 600L);
            });
        });
    }

    private void toggleOverlay() {
        if (!isAdded() || getContext() == null) return;
        final android.content.Context ctx = requireContext();
        if (OverlayService.isRunning()) {
            ctx.startService(new Intent(ctx, OverlayService.class).setAction(OverlayService.ACTION_STOP));
        } else if (!PermissionHelper.hasOverlay(ctx)) {
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).startPermissionFlow();
            return;
        } else {
            ContextCompat.startForegroundService(ctx,
                    new Intent(ctx, OverlayService.class).setAction(OverlayService.ACTION_START));
        }
        mainHandler.postDelayed(this::updateOverlayUi, 500L);
    }

    private void updateOverlayUi() {
        if (!isAdded() || getContext() == null) return;
        android.content.Context ctx = requireContext();
        boolean on = OverlayService.isRunning();
        if (tvOverlayStatus != null) tvOverlayStatus.setText(on
                ? "● Janelinha ATIVA — arraste para mover" : "○ Janelinha desativada");
        if (btnToggleOverlay != null) btnToggleOverlay.setText(on
                ? "Desativar monitor flutuante" : "Ativar monitor flutuante");
        if (tvPermStatus != null) tvPermStatus.setText(
                (PermissionHelper.hasOverlay(ctx) ? "✔" : "✖") + " Sobrepor apps   "
                + (PermissionHelper.hasStorage(ctx) ? "✔" : "✖") + " Armazenamento   "
                + (PermissionHelper.hasNotifications(ctx) ? "✔" : "✖") + " Notificações");
    }

    private void openTab(int menuId) {
        if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).selectTab(menuId);
    }

    private void refreshAll() {
        if (!isAdded() || getContext() == null || worker.isShutdown()
                || !refreshPending.compareAndSet(false, true)) return;
        final android.content.Context appContext = requireContext().getApplicationContext();
        worker.execute(() -> {
            final String model = SystemMonitor.getDeviceModel();
            final String android = SystemMonitor.getAndroidVersionSummary();
            final SystemMonitor.RamSnapshot ram = SystemMonitor.readRam(appContext);
            final SystemMonitor.StorageSnapshot storage = SystemMonitor.readInternalStorage();
            final SystemMonitor.BatterySnapshot battery = SystemMonitor.readBattery(appContext);
            final ThermalReader.Reading cpuTemp = ThermalReader.read(appContext);
            mainHandler.post(() -> {
                refreshPending.set(false);
                if (!isAdded() || getView() == null) return;
                if (tvDeviceModel != null) tvDeviceModel.setText(model);
                if (tvAndroidVersion != null) tvAndroidVersion.setText(android);
                if (gaugeRam != null) gaugeRam.setProgressAnimated(ram.usedPercent, "RAM USADA");
                if (tvRamDetails != null) tvRamDetails.setText(String.format(Locale.US,
                        "Total: %s • Utilizada: %s • Disponível: %s",
                        FormatUtils.formatBytes(ram.totalBytes), FormatUtils.formatBytes(ram.usedBytes),
                        FormatUtils.formatBytes(ram.availBytes)));
                if (progressStorage != null) progressStorage.setProgress(storage.usedPercent);
                if (tvStoragePercent != null) tvStoragePercent.setText(storage.usedPercent + "% utilizado");
                if (tvStorageDetails != null) tvStorageDetails.setText(String.format(Locale.US,
                        "Total: %s • Usado: %s • Livre: %s", FormatUtils.formatBytes(storage.totalBytes),
                        FormatUtils.formatBytes(storage.usedBytes), FormatUtils.formatBytes(storage.freeBytes)));
                String temp = battery.temperatureCelsius != null
                        ? String.format(Locale.US, "%.1f °C", battery.temperatureCelsius) : "Temp. indisponível";
                if (tvBatterySummary != null) tvBatterySummary.setText(
                        (battery.levelPercent >= 0 ? battery.levelPercent + "%" : "N/D")
                                + " • " + temp + " • " + battery.statusText
                                + " • CPU " + ThermalReader.format(cpuTemp));
                if (progressBattery != null) progressBattery.setProgress(
                        battery.levelPercent >= 0 ? battery.levelPercent : 0);
            });
        });
    }
}
