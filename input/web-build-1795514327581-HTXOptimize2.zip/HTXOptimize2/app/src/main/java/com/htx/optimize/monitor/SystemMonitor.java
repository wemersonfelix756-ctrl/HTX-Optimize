package com.htx.optimize.monitor;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import java.io.File;
import java.util.Locale;

public final class SystemMonitor {

    public static final class RamSnapshot {
        public final long totalBytes, availBytes, usedBytes, thresholdBytes;
        public final int usedPercent;
        public final boolean lowMemory;

        public RamSnapshot(long totalBytes, long availBytes, boolean lowMemory, long thresholdBytes) {
            this.totalBytes = Math.max(0L, totalBytes);
            this.availBytes = Math.max(0L, Math.min(this.totalBytes, availBytes));
            this.usedBytes = Math.max(0L, this.totalBytes - this.availBytes);
            this.usedPercent = percentage(this.usedBytes, this.totalBytes);
            this.lowMemory = lowMemory;
            this.thresholdBytes = Math.max(0L, thresholdBytes);
        }
    }

    public static final class StorageSnapshot {
        public final long totalBytes, freeBytes, usedBytes;
        public final int usedPercent;

        public StorageSnapshot(long totalBytes, long freeBytes) {
            this.totalBytes = Math.max(0L, totalBytes);
            this.freeBytes = Math.max(0L, Math.min(this.totalBytes, freeBytes));
            this.usedBytes = Math.max(0L, this.totalBytes - this.freeBytes);
            this.usedPercent = percentage(this.usedBytes, this.totalBytes);
        }
    }

    public static final class BatterySnapshot {
        public final int levelPercent, voltageMv;
        public final Float temperatureCelsius;
        public final String statusText, healthText, technology;

        public BatterySnapshot(int levelPercent, Float temperatureCelsius, int voltageMv,
                               String statusText, String healthText, String technology) {
            this.levelPercent = levelPercent;
            this.temperatureCelsius = temperatureCelsius;
            this.voltageMv = voltageMv;
            this.statusText = statusText;
            this.healthText = healthText;
            this.technology = technology;
        }
    }

    private SystemMonitor() { }

    private static int percentage(long value, long total) {
        if (total <= 0L) return 0;
        return (int) Math.max(0L, Math.min(100L, Math.round(((double) value / (double) total) * 100.0d)));
    }

    private static long safeMultiply(long a, long b) {
        if (a <= 0L || b <= 0L) return 0L;
        if (a > Long.MAX_VALUE / b) return Long.MAX_VALUE;
        return a * b;
    }

    public static String getDeviceModel() {
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.trim();
        String model = Build.MODEL == null ? "Dispositivo Android" : Build.MODEL.trim();
        if (manufacturer.isEmpty()) return model;
        return model.toLowerCase(Locale.ROOT).startsWith(manufacturer.toLowerCase(Locale.ROOT))
                ? model : manufacturer.toUpperCase(Locale.ROOT) + " " + model;
    }

    public static String getAndroidVersionSummary() {
        String release = Build.VERSION.RELEASE == null ? "Desconhecida" : Build.VERSION.RELEASE;
        return "Android " + release + " (API " + Build.VERSION.SDK_INT + ")";
    }

    public static RamSnapshot readRam(Context context) {
        if (context == null) return new RamSnapshot(0L, 0L, false, 0L);
        try {
            ActivityManager manager = (ActivityManager) context.getApplicationContext()
                    .getSystemService(Context.ACTIVITY_SERVICE);
            if (manager == null) return new RamSnapshot(0L, 0L, false, 0L);
            ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
            manager.getMemoryInfo(info);
            return new RamSnapshot(info.totalMem, info.availMem, info.lowMemory, info.threshold);
        } catch (RuntimeException exception) {
            return new RamSnapshot(0L, 0L, false, 0L);
        }
    }

    public static StorageSnapshot readInternalStorage() {
        try {
            StatFs stats = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            long blockSize = stats.getBlockSizeLong();
            long total = safeMultiply(stats.getBlockCountLong(), blockSize);
            long free = safeMultiply(stats.getAvailableBlocksLong(), blockSize);
            return new StorageSnapshot(total, free);
        } catch (RuntimeException exception) {
            return new StorageSnapshot(0L, 0L);
        }
    }

    public static BatterySnapshot readBattery(Context context) {
        if (context == null) return unavailableBattery();
        try {
            Intent battery = context.getApplicationContext().registerReceiver(
                    null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (battery == null) return unavailableBattery();

            int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int percent = level >= 0 && scale > 0
                    ? (int) Math.max(0L, Math.min(100L, (level * 100L) / scale)) : -1;

            int rawTemp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            Float temperature = rawTemp != Integer.MIN_VALUE ? rawTemp / 10.0f : null;
            int voltage = battery.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
            int status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN);
            int health = battery.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN);
            String tech = battery.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
            if (tech == null || tech.trim().isEmpty()) tech = "N/D";

            return new BatterySnapshot(percent, temperature, voltage,
                    mapBatteryStatus(status), mapBatteryHealth(health), tech);
        } catch (RuntimeException exception) {
            return unavailableBattery();
        }
    }

    private static BatterySnapshot unavailableBattery() {
        return new BatterySnapshot(-1, null, -1, "Indisponível", "Desconhecida", "N/D");
    }

    private static String mapBatteryStatus(int status) {
        switch (status) {
            case BatteryManager.BATTERY_STATUS_CHARGING: return "Carregando";
            case BatteryManager.BATTERY_STATUS_DISCHARGING: return "Descarregando";
            case BatteryManager.BATTERY_STATUS_NOT_CHARGING: return "Sem carregar";
            case BatteryManager.BATTERY_STATUS_FULL: return "Completa";
            default: return "Desconhecido";
        }
    }

    private static String mapBatteryHealth(int health) {
        switch (health) {
            case BatteryManager.BATTERY_HEALTH_GOOD: return "Boa";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT: return "Superaquecimento";
            case BatteryManager.BATTERY_HEALTH_DEAD: return "Esgotada";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: return "Sobretensão";
            case BatteryManager.BATTERY_HEALTH_COLD: return "Fria";
            default: return "Desconhecida";
        }
    }
}
