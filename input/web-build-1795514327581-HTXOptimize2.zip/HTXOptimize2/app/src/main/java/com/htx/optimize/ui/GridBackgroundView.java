package com.htx.optimize.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;
import androidx.annotation.Nullable;

/** Fundo futurista: grade neon, brilhos nos cantos e linha de varredura animada. */
public class GridBackgroundView extends View {

    private final Paint gridPaint = new Paint();
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint scanPaint = new Paint();
    private ValueAnimator animator;
    private float scanFraction;
    private float cell;

    public GridBackgroundView(Context context) { super(context); init(); }

    public GridBackgroundView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        cell = 34f * getResources().getDisplayMetrics().density;
        gridPaint.setColor(0x1422E5FF);
        gridPaint.setStrokeWidth(1f);
        setWillNotDraw(false);
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(7000L);
        animator.setInterpolator(new LinearInterpolator());
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.addUpdateListener(a -> {
            scanFraction = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override protected void onDetachedFromWindow() {
        if (animator != null) animator.cancel();
        super.onDetachedFromWindow();
    }

    @Override protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        glowPaint.setShader(new RadialGradient(w * 0.15f, 0f, w * 0.9f,
                0x3322E5FF, 0x00000000, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, glowPaint);
        glowPaint.setShader(new RadialGradient(w, h, w * 0.95f,
                0x33A855F7, 0x00000000, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, glowPaint);

        for (float x = 0; x < w; x += cell) canvas.drawLine(x, 0, x, h, gridPaint);
        for (float y = 0; y < h; y += cell) canvas.drawLine(0, y, w, y, gridPaint);

        float y = scanFraction * (h + 120f) - 60f;
        scanPaint.setShader(new LinearGradient(0, y - 60f, 0, y + 60f,
                new int[]{0x0022E5FF, 0x3022E5FF, 0x0022E5FF}, null, Shader.TileMode.CLAMP));
        canvas.drawRect(0, y - 60f, w, y + 60f, scanPaint);
    }
}
