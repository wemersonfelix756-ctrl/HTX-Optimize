package com.htx.optimize.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import com.htx.optimize.R;
import java.util.Locale;

public class ArcGaugeView extends View {

    private static final int TICKS = 36;

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint subTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arcRect = new RectF();
    private final Matrix gradientMatrix = new Matrix();
    private final Handler animHandler = new Handler(Looper.getMainLooper());

    private float currentPercent = 0f;
    private float targetPercent = 0f;
    private String centerLabel = "RAM";
    private int tickLit, tickOff;

    private final Runnable stepRunnable = new Runnable() {
        @Override public void run() {
            float diff = targetPercent - currentPercent;
            if (Math.abs(diff) < 0.8f) {
                currentPercent = targetPercent;
                invalidate();
                return;
            }
            currentPercent += diff * 0.25f;
            invalidate();
            animHandler.postDelayed(this, 16L);
        }
    };

    public ArcGaugeView(Context context) { super(context); init(context); }

    public ArcGaugeView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        setLayerType(LAYER_TYPE_SOFTWARE, null); // necessário para o brilho (shadow layer)
        float stroke = dp(11f);
        int cyan = ContextCompat.getColor(context, R.color.htx_neon_cyan);
        tickLit = cyan;
        tickOff = 0x3322E5FF;

        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setStrokeWidth(stroke);
        trackPaint.setStrokeCap(Paint.Cap.ROUND);
        trackPaint.setColor(ContextCompat.getColor(context, R.color.htx_glow_soft));

        progressPaint.setStyle(Paint.Style.STROKE);
        progressPaint.setStrokeWidth(stroke);
        progressPaint.setStrokeCap(Paint.Cap.ROUND);
        progressPaint.setColor(cyan);
        progressPaint.setShadowLayer(dp(9f), 0f, 0f, 0xAA22E5FF);

        tickPaint.setStrokeWidth(dp(2f));
        tickPaint.setStrokeCap(Paint.Cap.ROUND);

        textPaint.setColor(ContextCompat.getColor(context, R.color.htx_text_primary));
        textPaint.setTextSize(sp(30f));
        textPaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setShadowLayer(dp(8f), 0f, 0f, 0x8822E5FF);

        subTextPaint.setColor(cyan);
        subTextPaint.setTextSize(sp(10f));
        subTextPaint.setLetterSpacing(0.2f);
        subTextPaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        subTextPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setProgressAnimated(int percent, String label) {
        if (label != null) centerLabel = label;
        targetPercent = Math.max(0f, Math.min(100f, percent));
        animHandler.removeCallbacks(stepRunnable);
        animHandler.post(stepRunnable);
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        SweepGradient gradient = new SweepGradient(w / 2f, h / 2f,
                new int[]{0xFF22E5FF, 0xFF7C3AED, 0xFFE879F9, 0xFFE879F9},
                new float[]{0f, 0.40f, 0.75f, 1f});
        gradientMatrix.setRotate(135f, w / 2f, h / 2f);
        gradient.setLocalMatrix(gradientMatrix);
        progressPaint.setShader(gradient);
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        animHandler.removeCallbacksAndMessages(null);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float pad = dp(22f);
        float size = Math.max(10f, Math.min(w, h) - pad * 2f);
        float left = (w - size) / 2f;
        float top = (h - size) / 2f;
        arcRect.set(left, top, left + size, top + size);
        float cx = w / 2f;
        float cy = h / 2f;

        // Marcas externas (estilo painel HUD)
        float outer = size / 2f + dp(13f);
        float inner = outer - dp(6f);
        for (int i = 0; i <= TICKS; i++) {
            float fraction = i / (float) TICKS;
            double angle = Math.toRadians(135.0 + 270.0 * fraction);
            tickPaint.setColor(fraction * 100f <= currentPercent ? tickLit : tickOff);
            canvas.drawLine(
                    cx + (float) Math.cos(angle) * inner, cy + (float) Math.sin(angle) * inner,
                    cx + (float) Math.cos(angle) * outer, cy + (float) Math.sin(angle) * outer,
                    tickPaint);
        }

        canvas.drawArc(arcRect, 135f, 270f, false, trackPaint);
        float sweep = 270f * (currentPercent / 100f);
        if (sweep > 0.5f) canvas.drawArc(arcRect, 135f, sweep, false, progressPaint);

        canvas.drawText(String.format(Locale.US, "%.0f%%", currentPercent), cx, cy + dp(6f), textPaint);
        canvas.drawText(centerLabel, cx, cy + dp(26f), subTextPaint);
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    private float sp(float v) { return v * getResources().getDisplayMetrics().scaledDensity; }
}
