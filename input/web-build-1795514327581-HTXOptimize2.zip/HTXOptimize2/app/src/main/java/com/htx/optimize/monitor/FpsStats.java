package com.htx.optimize.monitor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Estatísticas da sessão de FPS real (média, 1% low, 0,1% low, travadas). Puro Java. */
public final class FpsStats {

    public static final FpsStats GLOBAL = new FpsStats();

    public static final class Summary {
        public final String pkg;
        public final int frames;
        public final double seconds, avgFps, low1Fps, low01Fps, worstFrameMs;
        public final int stutters;

        Summary(String pkg, int frames, double seconds, double avgFps, double low1Fps,
                double low01Fps, double worstFrameMs, int stutters) {
            this.pkg = pkg;
            this.frames = frames;
            this.seconds = seconds;
            this.avgFps = avgFps;
            this.low1Fps = low1Fps;
            this.low01Fps = low01Fps;
            this.worstFrameMs = worstFrameMs;
            this.stutters = stutters;
        }

        public String toText() {
            return String.format(Locale.US,
                    "Sessão de FPS real\nApp: %s\nTempo medido: %.0f s (%d quadros)\n"
                            + "FPS médio: %.1f\n1%% low: %.1f FPS\n0,1%% low: %.1f FPS\n"
                            + "Pior quadro: %.1f ms\nTravadas (quadro > 2x a mediana): %d\n\n"
                            + "Dica: segure este botão para zerar a sessão.",
                    pkg == null ? "—" : pkg, seconds, frames, avgFps, low1Fps, low01Fps,
                    worstFrameMs, stutters);
        }
    }

    private static final int MAX_FRAMES = 60000;

    private final List<Float> frameMs = new ArrayList<>();
    private String pkg;

    public synchronized void reset() {
        frameMs.clear();
        pkg = null;
    }

    public synchronized void addIntervals(String newPkg, long[] intervalsNs) {
        if (intervalsNs == null || intervalsNs.length == 0) return;
        if (newPkg != null && !newPkg.equals(pkg)) {
            frameMs.clear();
            pkg = newPkg;
        }
        for (long ns : intervalsNs) {
            if (ns > 0L) frameMs.add(ns / 1_000_000f);
        }
        if (frameMs.size() > MAX_FRAMES) frameMs.subList(0, 5000).clear();
    }

    public synchronized Summary summary() {
        if (frameMs.size() < 10) return null;
        List<Float> sorted = new ArrayList<>(frameMs);
        Collections.sort(sorted);
        int n = sorted.size();
        double total = 0.0;
        for (float v : sorted) total += v;
        double seconds = total / 1000.0;
        double avg = n / seconds;
        double p99 = sorted.get(Math.max(0, (int) Math.ceil(n * 0.99) - 1));
        double p999 = sorted.get(Math.max(0, (int) Math.ceil(n * 0.999) - 1));
        double worst = sorted.get(n - 1);
        float median = sorted.get(n / 2);
        int stutters = 0;
        for (float v : sorted) if (v > median * 2f) stutters++;
        return new Summary(pkg, n, seconds, avg, 1000.0 / p99, 1000.0 / p999, worst, stutters);
    }
}
