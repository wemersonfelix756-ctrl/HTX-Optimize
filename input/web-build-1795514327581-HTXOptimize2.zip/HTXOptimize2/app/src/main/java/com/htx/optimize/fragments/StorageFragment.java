package com.htx.optimize.fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.htx.optimize.R;
import com.htx.optimize.storage.FileAdapter;
import com.htx.optimize.storage.FileItem;
import com.htx.optimize.util.FormatUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class StorageFragment extends Fragment {
    private static final String STATE_TREE_URI = "htx.tree_uri";
    private static final String STATE_SCANNED = "htx.scanned_bytes";
    private static final String STATE_FREED = "htx.freed_bytes";
    private static final int MAX_SCAN_FILES = 5000;
    private static final int MAX_SCAN_DEPTH = 32;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicInteger operationId = new AtomicInteger(0);
    private TextView tvFolderInfo, tvReport;
    private Button btnDeleteSelected;
    private FileAdapter adapter;
    private Uri currentTreeUri;
    private long lastScannedBytes, lastFreedBytes;

    private final ActivityResultLauncher<Uri> folderPickerLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocumentTree(), uri -> {
                if (uri == null || !isAdded() || getContext() == null) return;
                try {
                    int flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
                    requireContext().getContentResolver().takePersistableUriPermission(uri, flags);
                } catch (RuntimeException ignored) {
                    // Some providers issue transient grants or reject persistence.
                }
                currentTreeUri = uri;
                scanFolder(uri);
            });

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_storage, container, false);
    }

    @Override public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            String uri = savedInstanceState.getString(STATE_TREE_URI);
            if (uri != null) currentTreeUri = Uri.parse(uri);
            lastScannedBytes = Math.max(0L, savedInstanceState.getLong(STATE_SCANNED, 0L));
            lastFreedBytes = Math.max(0L, savedInstanceState.getLong(STATE_FREED, 0L));
        }
    }

    @Override public void onSaveInstanceState(@NonNull Bundle outState) {
        if (currentTreeUri != null) outState.putString(STATE_TREE_URI, currentTreeUri.toString());
        outState.putLong(STATE_SCANNED, lastScannedBytes);
        outState.putLong(STATE_FREED, lastFreedBytes);
        super.onSaveInstanceState(outState);
    }

    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvFolderInfo = view.findViewById(R.id.tv_storage_folder_info);
        tvReport = view.findViewById(R.id.tv_storage_report);
        btnDeleteSelected = view.findViewById(R.id.btn_delete_selected);
        RecyclerView recycler = view.findViewById(R.id.rv_files);

        adapter = new FileAdapter((count, bytes) -> {
            if (btnDeleteSelected != null) {
                btnDeleteSelected.setEnabled(count > 0);
                btnDeleteSelected.setText(String.format(java.util.Locale.US, "Excluir (%d)", count));
            }
        });
        recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        recycler.setHasFixedSize(false);
        recycler.setAdapter(adapter);

        View pick = view.findViewById(R.id.btn_pick_folder);
        if (pick != null) pick.setOnClickListener(v -> folderPickerLauncher.launch(currentTreeUri));
        if (btnDeleteSelected != null) btnDeleteSelected.setOnClickListener(v -> confirmDeleteSelected());
        updateReportText();
        if (currentTreeUri != null) scanFolder(currentTreeUri);
    }

    private void scanFolder(Uri treeUri) {
        if (treeUri == null || !isAdded() || getContext() == null || worker.isShutdown()) return;
        final int requestId = operationId.incrementAndGet();
        final Context appContext = requireContext().getApplicationContext();
        if (tvFolderInfo != null) tvFolderInfo.setText("Analisando pasta selecionada...");
        worker.execute(() -> {
            DocumentFile root = DocumentFile.fromTreeUri(appContext, treeUri);
            List<FileItem> found = new ArrayList<>();
            String error = null;
            if (root == null) {
                error = "Não foi possível abrir a pasta selecionada.";
            } else if (!root.canRead()) {
                error = "Sem permissão de leitura para esta pasta.";
            } else {
                try {
                    collectFilesRecursive(root, found, 0);
                } catch (SecurityException | IllegalStateException exception) {
                    error = "A leitura foi interrompida. Verifique as permissões da pasta.";
                } catch (RuntimeException exception) {
                    error = "O provedor de arquivos retornou um erro durante a leitura.";
                }
            }

            long total = 0L;
            for (FileItem item : found) total = safeAdd(total, item.getSizeBytes());
            Collections.sort(found, (a, b) -> Long.compare(b.getSizeBytes(), a.getSizeBytes()));
            final long scanned = total;
            final String scanError = error;
            final String folderName = root != null && root.getName() != null
                    ? root.getName() : "Pasta selecionada";
            mainHandler.post(() -> {
                if (requestId != operationId.get() || !isAdded() || getView() == null || adapter == null) return;
                lastScannedBytes = scanned;
                String limit = found.size() >= MAX_SCAN_FILES ? " • limite de segurança atingido" : "";
                if (tvFolderInfo != null) tvFolderInfo.setText(
                        (scanError != null ? scanError + "\n" : "") + "Pasta: " + folderName
                                + " • " + found.size() + " arquivo(s)" + limit);
                updateReportText();
                adapter.setItems(found);
            });
        });
    }

    private void collectFilesRecursive(DocumentFile directory, List<FileItem> output, int depth) {
        if (directory == null || depth >= MAX_SCAN_DEPTH || output.size() >= MAX_SCAN_FILES) return;
        DocumentFile[] children = directory.listFiles();
        if (children == null) return;
        for (DocumentFile child : children) {
            if (output.size() >= MAX_SCAN_FILES) return;
            if (child == null) continue;
            try {
                if (child.isDirectory()) {
                    collectFilesRecursive(child, output, depth + 1);
                } else if (child.isFile()) {
                    String name = child.getName();
                    String type = child.getType();
                    long length = Math.max(0L, child.length());
                    output.add(new FileItem(child.getUri(), name, type, length));
                }
            } catch (SecurityException | IllegalStateException ignored) {
                // A single inaccessible entry must not abort the rest of the scan.
            }
        }
    }

    private void confirmDeleteSelected() {
        if (adapter == null || getContext() == null) return;
        List<FileItem> selected = new ArrayList<>(adapter.getSelectedItems());
        if (selected.isEmpty()) return;
        long bytes = 0L;
        for (FileItem item : selected) bytes = safeAdd(bytes, item.getSizeBytes());
        new AlertDialog.Builder(requireContext())
                .setTitle("Confirmar exclusão")
                .setMessage(String.format(java.util.Locale.US,
                        "Deseja excluir permanentemente %d arquivo(s) selecionado(s) (%s)?",
                        selected.size(), FormatUtils.formatBytes(bytes)))
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (dialog, which) -> deleteFilesAsync(selected))
                .show();
    }

    private void deleteFilesAsync(List<FileItem> selected) {
        if (!isAdded() || getContext() == null || worker.isShutdown()) return;
        operationId.incrementAndGet();
        final Context appContext = requireContext().getApplicationContext();
        if (btnDeleteSelected != null) btnDeleteSelected.setEnabled(false);
        worker.execute(() -> {
            long freed = 0L;
            int deleted = 0;
            int failed = 0;
            for (FileItem item : selected) {
                try {
                    DocumentFile document = item.toDocumentFile(appContext);
                    if (document != null && document.exists() && document.delete()) {
                        freed = safeAdd(freed, item.getSizeBytes());
                        deleted++;
                    } else {
                        failed++;
                    }
                } catch (RuntimeException exception) {
                    failed++;
                }
            }
            final long freedBytes = freed;
            final int deletedCount = deleted;
            final int failedCount = failed;
            mainHandler.post(() -> {
                if (!isAdded() || getView() == null) return;
                lastFreedBytes = safeAdd(lastFreedBytes, freedBytes);
                updateReportText();
                if (getContext() != null) Toast.makeText(getContext(),
                        deletedCount + " arquivo(s) excluído(s); " + failedCount + " falha(s) ("
                                + FormatUtils.formatBytes(freedBytes) + ")", Toast.LENGTH_LONG).show();
                if (currentTreeUri != null) scanFolder(currentTreeUri);
            });
        });
    }

    private static long safeAdd(long a, long b) {
        if (b > 0L && a > Long.MAX_VALUE - b) return Long.MAX_VALUE;
        return Math.max(0L, a + Math.max(0L, b));
    }

    private void updateReportText() {
        if (tvReport != null) tvReport.setText(String.format(java.util.Locale.US,
                "Espaço analisado: %s • Espaço liberado: %s",
                FormatUtils.formatBytes(lastScannedBytes), FormatUtils.formatBytes(lastFreedBytes)));
    }

    @Override public void onDestroyView() {
        operationId.incrementAndGet();
        tvFolderInfo = null; tvReport = null; btnDeleteSelected = null; adapter = null;
        super.onDestroyView();
    }

    @Override public void onDestroy() {
        operationId.incrementAndGet();
        worker.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
