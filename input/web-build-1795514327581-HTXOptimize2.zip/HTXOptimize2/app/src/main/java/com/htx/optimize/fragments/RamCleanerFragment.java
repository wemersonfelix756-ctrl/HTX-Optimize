package com.htx.optimize.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import com.htx.optimize.R;
import com.htx.optimize.monitor.SystemMonitor;
import com.htx.optimize.ui.RamHistoryGraphView;
import com.htx.optimize.util.FormatUtils;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RamCleanerFragment extends Fragment {
    private static final long POLL_INTERVAL_MS = 3000L;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView tvMetrics, tvState;
    private RamHistoryGraphView graphView;
    private boolean autoEnabled = true;

    private final Runnable pollRunnable = new Runnable() {
        @Override public void run() {
            if (!isAdded() || !isResumed() || !autoEnabled) return;
            updateRamTelemetry();
            mainHandler.postDelayed(this, POLL_INTERVAL_MS);
        }
    };

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_ram_cleaner, container, false);
    }

    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvMetrics = view.findViewById(R.id.tv_cleaner_metrics);
        tvState = view.findViewById(R.id.tv_cleaner_state);
        graphView = view.findViewById(R.id.ram_history_graph);
        SwitchCompat autoSwitch = view.findViewById(R.id.switch_auto_refresh);
        if (autoSwitch != null) {
            autoSwitch.setChecked(autoEnabled);
            autoSwitch.setOnCheckedChangeListener((button, checked) -> {
                autoEnabled = checked;
                mainHandler.removeCallbacks(pollRunnable);
                if (checked && isResumed()) mainHandler.post(pollRunnable);
            });
        }
        Button apps = view.findViewById(R.id.btn_open_app_settings);
        if (apps != null) apps.setOnClickListener(v ->
                FormatUtils.safeStartActivity(requireContext(), new Intent(Settings.ACTION_APPLICATION_SETTINGS)));
        updateRamTelemetry();
    }

    @Override public void onResume() {
        super.onResume();
        if (autoEnabled) {
            mainHandler.removeCallbacks(pollRunnable);
            mainHandler.post(pollRunnable);
        }
    }

    @Override public void onPause() {
        mainHandler.removeCallbacks(pollRunnable);
        super.onPause();
    }

    private void updateRamTelemetry() {
        if (!isAdded() || getContext() == null || worker.isShutdown()) return;
        final android.content.Context appContext = requireContext().getApplicationContext();
        worker.execute(() -> {
            final SystemMonitor.RamSnapshot ram = SystemMonitor.readRam(appContext);
            mainHandler.post(() -> {
                if (!isAdded() || getView() == null) return;
                if (graphView != null) graphView.addSample(ram.usedPercent);
                if (tvMetrics != null) tvMetrics.setText(String.format(Locale.US,
                        "Utilização: %d%%\nTotal: %s\nUtilizada: %s\nDisponível: %s\nLimiar do sistema: %s",
                        ram.usedPercent, FormatUtils.formatBytes(ram.totalBytes),
                        FormatUtils.formatBytes(ram.usedBytes), FormatUtils.formatBytes(ram.availBytes),
                        FormatUtils.formatBytes(ram.thresholdBytes)));
                if (tvState != null) tvState.setText(ram.lowMemory || ram.usedPercent >= 85
                        ? "Estado: Pressão de memória elevada (lowMemory=" + ram.lowMemory + ")"
                        : "Estado: Memória estável (lowMemory=false)");
            });
        });
    }

    @Override public void onDestroyView() {
        mainHandler.removeCallbacks(pollRunnable);
        tvMetrics = null; tvState = null; graphView = null;
        super.onDestroyView();
    }

    @Override public void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        worker.shutdownNow();
        super.onDestroy();
    }
}
