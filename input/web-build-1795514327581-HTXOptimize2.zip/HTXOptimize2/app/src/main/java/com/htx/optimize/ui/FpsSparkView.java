package com.htx.optimize.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.View;

/** Mini gráfico de FPS usado dentro da janelinha flutuante. */
public class FpsSparkView extends View {

    private static final int MAX = 40;

    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[] data = new float[MAX];
    private int count;
    private float ceiling = 60f;

    public FpsSparkView(Context context) {
        super(context);
        float d = context.getResources().getDisplayMetrics().density;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(1.6f * d);
        line.setColor(0xFF22E5FF);
        fill.setStyle(Paint.Style.FILL);
    }

    public void setCeiling(float value) { ceiling = Math.max(30f, value); }

    public void addSample(float fps) {
        if (count == MAX) {
            System.arraycopy(data, 1, data, 0, MAX - 1);
            count--;
        }
        data[count++] = fps;
        invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        fill.setShader(new LinearGradient(0f, 0f, 0f, h, 0x5522E5FF, 0x00E879F9, Shader.TileMode.CLAMP));
    }

    @Override protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0 || count < 2) return;
        float max = ceiling;
        for (int i = 0; i < count; i++) if (data[i] * 1.05f > max) max = data[i] * 1.05f;
        float step = (float) w / (MAX - 1);
        float startX = w - (count - 1) * step;
        Path path = new Path();
        Path area = new Path();
        for (int i = 0; i < count; i++) {
            float x = startX + i * step;
            float y = h - Math.min(1f, data[i] / max) * (h - 2f) - 1f;
            if (i == 0) {
                path.moveTo(x, y);
                area.moveTo(x, h);
                area.lineTo(x, y);
            } else {
                path.lineTo(x, y);
                area.lineTo(x, y);
            }
        }
        area.lineTo(w, h);
        area.close();
        canvas.drawPath(area, fill);
        canvas.drawPath(path, line);
    }
}
