package com.htx.optimize.monitor;

import com.htx.optimize.util.Shell;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Mede o FPS real do app em foco (precisa de um Shell privilegiado). Métodos, em ordem:
 * 1) SurfaceFlinger --latency (também fornece os tempos de quadro para o 1% low)
 * 2) SurfaceFlinger --timestats (contador de quadros do sistema; não depende de horários)
 * 3) gfxinfo framestats (apps com UI padrão)
 */
public final class FpsSampler {

    public static final class Sample {
        public final float fps;          // NaN = indisponível
        public final String pkg;         // app em foco (pode ser null)
        public final String source;      // "SF", "TS", "GFX" ou null
        public final String status;      // motivo quando indisponível / parado
        public final long[] intervalsNs; // tempos de quadro novos

        Sample(float fps, String pkg, String source, String status, long[] intervalsNs) {
            this.fps = fps;
            this.pkg = pkg;
            this.source = source;
            this.status = status;
            this.intervalsNs = intervalsNs;
        }
    }

    private static final long RESOLVE_INTERVAL_MS = 4000L;
    private static final long[] NO_INTERVALS = new long[0];
    private static final String RESOLVE_CMD =
            "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'; echo '@@LIST'; "
                    + "dumpsys SurfaceFlinger --list";
    private static final String TS_ENABLE_CMD = "dumpsys SurfaceFlinger --timestats -enable";
    private static final String TS_DUMP_CMD = "dumpsys SurfaceFlinger --timestats -dump -maxlayers 80";

    private final Shell shell;
    private final Map<String, Long> previousMax = new HashMap<>();
    private Map<String, Long> previousTs = new HashMap<>();
    private long previousTsNanos;
    private long previousGfxMax;
    private List<String> layers = new ArrayList<>();
    private String pkg;
    private long lastResolve = -1L;
    private boolean tsEnabled;
    private int tsEmptyStreak;
    private int zeroStreak;
    private float lastFps;
    private String debug = "";

    public FpsSampler(Shell shell) {
        this.shell = shell;
    }

    public String debugReport() { return debug; }

    public Sample sample(long nowMs) {
        StringBuilder dbg = new StringBuilder();
        try {
            if (layers.isEmpty() || lastResolve < 0L || nowMs - lastResolve > RESOLVE_INTERVAL_MS) {
                resolve(nowMs, dbg);
            }
            if (pkg == null) {
                dbg.append("Nenhum app em foco encontrado (mCurrentFocus vazio).\n");
                debug = dbg.toString();
                return new Sample(Float.NaN, null, null, "Sem app em foco", NO_INTERVALS);
            }

            // 1) SurfaceFlinger --latency
            boolean anyValid = false;
            FpsParser.Result chosen = null;
            if (!layers.isEmpty()) {
                String output = shell.run(FpsParser.buildLatencyCommand(layers));
                List<String> sections = FpsParser.splitSections(output, layers.size());
                for (int i = 0; i < layers.size(); i++) {
                    String layer = layers.get(i);
                    Long prev = previousMax.get(layer);
                    FpsParser.Result r = FpsParser.compute(sections.get(i), prev == null ? 0L : prev);
                    dbg.append(String.format(Locale.US, "SF[%d] %s -> %s, %.1f fps\n", i, layer,
                            r.valid ? "dados ok" : "sem dados", r.fps));
                    if (i == 0) dbg.append("  bruto: ").append(head(sections.get(i), 3)).append('\n');
                    if (!r.valid) continue;
                    anyValid = true;
                    previousMax.put(layer, r.maxTs);
                    if (chosen == null && r.fps > 0f) chosen = r;
                }
            } else {
                dbg.append("Nenhuma camada do SurfaceFlinger contém o pacote ").append(pkg).append(".\n");
            }
            if (chosen != null) return positive(chosen.fps, "SF", chosen.intervalsNs, dbg);

            // 2) timestats (contador de quadros)
            float tsFps = sampleTimeStats(dbg);
            if (!Float.isNaN(tsFps) && tsFps > 0f) return positive(tsFps, "TS", NO_INTERVALS, dbg);

            // 3) gfxinfo
            boolean gfxValid = false;
            try {
                String gfx = shell.run("dumpsys gfxinfo " + pkg + " framestats");
                FpsParser.Result g = FpsParser.computeFramestats(gfx, previousGfxMax);
                dbg.append(String.format(Locale.US, "GFX -> %s, %.1f fps\n",
                        g.valid ? "dados ok" : "sem dados", g.fps));
                if (g.valid) {
                    gfxValid = true;
                    previousGfxMax = g.maxTs;
                    if (g.fps > 0f) return positive(g.fps, "GFX", g.intervalsNs, dbg);
                }
            } catch (Exception exception) {
                dbg.append("GFX erro: ").append(exception.getMessage()).append('\n');
            }

            debug = dbg.toString();
            if (anyValid || gfxValid || !Float.isNaN(tsFps)) {
                zeroStreak++;
                if (zeroStreak < 2 && lastFps > 0f) { // segura 1 ciclo para não piscar
                    return new Sample(lastFps, pkg, "SF", "ok", NO_INTERVALS);
                }
                return new Sample(0f, pkg, "SF", "parado", NO_INTERVALS);
            }
            lastResolve = -1L; // reavalia as camadas no próximo ciclo
            String shortPkg = shorten(pkg);
            return new Sample(Float.NaN, pkg, null,
                    layers.isEmpty() ? "Sem camada: " + shortPkg : "Sem dados: " + shortPkg, NO_INTERVALS);
        } catch (Exception exception) {
            lastResolve = -1L;
            dbg.append("ERRO: ").append(exception.getMessage()).append('\n');
            debug = dbg.toString();
            return new Sample(Float.NaN, pkg, null, "Erro no Shizuku", NO_INTERVALS);
        }
    }

    private Sample positive(float fps, String source, long[] intervals, StringBuilder dbg) {
        zeroStreak = 0;
        lastFps = fps;
        dbg.append(String.format(Locale.US, "=> %.1f fps via %s\n", fps, source));
        debug = dbg.toString();
        return new Sample(fps, pkg, source, "ok", intervals);
    }

    /** FPS pela diferença do contador totalFrames entre duas leituras. NaN = sem dados. */
    private float sampleTimeStats(StringBuilder dbg) {
        try {
            if (!tsEnabled) {
                shell.run(TS_ENABLE_CMD);
                tsEnabled = true;
                dbg.append("TS: timestats ativado\n");
            }
            String out = shell.run(TS_DUMP_CMD);
            long now = System.nanoTime();
            Map<String, Long> current = FpsParser.parseTimeStats(out, pkg);
            dbg.append("TS: ").append(current.size()).append(" camada(s) do pacote\n");

            float result = Float.NaN;
            if (!current.isEmpty() && previousTsNanos > 0L) {
                double dt = (now - previousTsNanos) / 1e9;
                if (dt >= 0.3) {
                    long best = 0L;
                    for (Map.Entry<String, Long> entry : current.entrySet()) {
                        Long before = previousTs.get(entry.getKey());
                        if (before != null && entry.getValue() >= before) {
                            best = Math.max(best, entry.getValue() - before);
                        }
                    }
                    result = (float) (best / dt);
                    dbg.append(String.format(Locale.US, "TS: +%d quadros em %.2f s\n", best, dt));
                }
            }
            tsEmptyStreak = current.isEmpty() ? tsEmptyStreak + 1 : 0;
            if (tsEmptyStreak >= 5) { // reativa caso o sistema tenha desligado
                tsEnabled = false;
                tsEmptyStreak = 0;
            }
            previousTs = current;
            previousTsNanos = now;
            return result;
        } catch (Exception exception) {
            dbg.append("TS erro: ").append(exception.getMessage()).append('\n');
            return Float.NaN;
        }
    }

    private void resolve(long nowMs, StringBuilder dbg) throws Exception {
        lastResolve = nowMs;
        String out = shell.run(RESOLVE_CMD);
        if (out == null) out = "";
        int idx = out.indexOf("@@LIST");
        String focusPart = idx >= 0 ? out.substring(0, idx) : out;
        String listPart = idx >= 0 ? out.substring(idx + "@@LIST".length()) : "";
        String newPkg = FpsParser.parseFocusedPackage(focusPart);
        if (newPkg == null || !newPkg.equals(pkg)) {
            previousMax.clear();
            previousTs = new HashMap<>();
            previousTsNanos = 0L;
            previousGfxMax = 0L;
            zeroStreak = 0;
            lastFps = 0f;
        }
        pkg = newPkg;
        layers = FpsParser.pickLayers(listPart, pkg, 4);
        dbg.append("App em foco: ").append(pkg).append('\n');
        dbg.append("Camadas candidatas: ").append(layers.size()).append('\n');
        for (String layer : layers) dbg.append("  • ").append(layer).append('\n');
    }

    private static String head(String text, int lines) {
        if (text == null) return "";
        String[] parts = text.split("\n");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length && i < lines; i++) {
            if (i > 0) sb.append(" | ");
            sb.append(parts[i].trim());
        }
        return sb.toString();
    }

    public static String shorten(String value) {
        if (value == null) return "";
        return value.length() > 24 ? "…" + value.substring(value.length() - 23) : value;
    }
}
