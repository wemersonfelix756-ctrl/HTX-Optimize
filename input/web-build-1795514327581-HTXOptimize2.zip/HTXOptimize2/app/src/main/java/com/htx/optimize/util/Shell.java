package com.htx.optimize.util;

/** Executor de comandos shell (implementado via Shizuku; fake nos testes). */
public interface Shell {
    String run(String command) throws Exception;
}
