package com.htx.optimize.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

public class RamHistoryGraphView extends View {

    private static final int MAX_SAMPLES = 24;

    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Integer> samples = new ArrayList<>();

    public RamHistoryGraphView(Context context) { super(context); init(); }

    public RamHistoryGraphView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        float d = getResources().getDisplayMetrics().density;
        gridPaint.setColor(0x2222E5FF);
        gridPaint.setStrokeWidth(d);

        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(2.5f * d);
        linePaint.setStrokeJoin(Paint.Join.ROUND);
        linePaint.setStrokeCap(Paint.Cap.ROUND);
        linePaint.setColor(0xFF22E5FF);
        linePaint.setShadowLayer(6f * d, 0f, 0f, 0xAA22E5FF);

        fillPaint.setStyle(Paint.Style.FILL);
        dotPaint.setColor(0xFFFFFFFF);
        dotPaint.setShadowLayer(8f * d, 0f, 0f, 0xFF22E5FF);
    }

    public void addSample(int percent) {
        if (samples.size() >= MAX_SAMPLES) samples.remove(0);
        samples.add(Math.max(0, Math.min(100, percent)));
        invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        fillPaint.setShader(new LinearGradient(0f, 0f, 0f, h,
                0x6622E5FF, 0x00E879F9, Shader.TileMode.CLAMP));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        for (int i = 1; i <= 3; i++) {
            float y = (h * i) / 4f;
            canvas.drawLine(0f, y, w, y, gridPaint);
        }
        if (samples.size() < 2) return;

        float d = getResources().getDisplayMetrics().density;
        Path line = new Path();
        Path area = new Path();
        float stepX = (float) w / (MAX_SAMPLES - 1);
        float startX = w - (samples.size() - 1) * stepX;
        float lastX = startX;
        float lastY = h;

        for (int i = 0; i < samples.size(); i++) {
            float x = startX + i * stepX;
            float y = h - ((samples.get(i) / 100f) * (h - 16f * d) + 8f * d);
            if (i == 0) {
                line.moveTo(x, y);
                area.moveTo(x, h);
                area.lineTo(x, y);
            } else {
                float mid = (lastX + x) / 2f;
                line.cubicTo(mid, lastY, mid, y, x, y);
                area.cubicTo(mid, lastY, mid, y, x, y);
            }
            lastX = x;
            lastY = y;
        }
        area.lineTo(lastX, h);
        area.close();

        canvas.drawPath(area, fillPaint);
        canvas.drawPath(line, linePaint);
        canvas.drawCircle(lastX, lastY, 4f * d, dotPaint);
    }
}
