package com.htx.optimize.monitor;

import android.content.Context;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Lê a temperatura da CPU via sysfs; se o Android bloquear, usa a temperatura da bateria. */
public final class ThermalReader {

    public static final class Reading {
        public final float celsius;      // NaN = indisponível
        public final boolean fromCpu;    // false = valor da bateria (fallback)

        Reading(float celsius, boolean fromCpu) {
            this.celsius = celsius;
            this.fromCpu = fromCpu;
        }
    }

    private static final String[] CPU_HINTS = {
            "cpu", "soc", "tsens", "mtktscpu", "cluster", "big", "little",
            "apss", "cpuss", "kryo", "exynos", "ap_thermal", "tz_cpu"};

    private static List<File> cpuZones;

    private ThermalReader() { }

    public static synchronized Reading read(Context context) {
        if (cpuZones == null) cpuZones = discoverCpuZones();
        float max = Float.NaN;
        for (File zone : cpuZones) {
            float value = parseTemp(readLine(new File(zone, "temp")));
            if (!Float.isNaN(value) && (Float.isNaN(max) || value > max)) max = value;
        }
        if (!Float.isNaN(max)) return new Reading(max, true);

        SystemMonitor.BatterySnapshot battery = SystemMonitor.readBattery(context);
        if (battery.temperatureCelsius != null) return new Reading(battery.temperatureCelsius, false);
        return new Reading(Float.NaN, false);
    }

    public static String format(Reading reading) {
        if (reading == null || Float.isNaN(reading.celsius)) return "--";
        return String.format(Locale.US, "%.0f°", reading.celsius);
    }

    private static List<File> discoverCpuZones() {
        List<File> result = new ArrayList<>();
        try {
            File base = new File("/sys/class/thermal");
            File[] zones = base.listFiles();
            if (zones == null) return result;
            for (File zone : zones) {
                if (!zone.getName().startsWith("thermal_zone")) continue;
                String type = readLine(new File(zone, "type"));
                if (type == null) continue;
                String lower = type.toLowerCase(Locale.ROOT);
                boolean match = false;
                for (String hint : CPU_HINTS) {
                    if (lower.contains(hint)) { match = true; break; }
                }
                if (!match) continue;
                if (!Float.isNaN(parseTemp(readLine(new File(zone, "temp"))))) result.add(zone);
            }
        } catch (RuntimeException ignored) {
            // Sem acesso: o fallback da bateria será usado.
        }
        return result;
    }

    private static String readLine(File file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line = reader.readLine();
            return line == null ? null : line.trim();
        } catch (Exception exception) {
            return null;
        }
    }

    private static float parseTemp(String raw) {
        if (raw == null || raw.isEmpty()) return Float.NaN;
        try {
            float value = Float.parseFloat(raw);
            if (value > 1000f) value /= 1000f;
            else if (value > 150f) value /= 10f;
            return value >= 10f && value <= 125f ? value : Float.NaN;
        } catch (NumberFormatException exception) {
            return Float.NaN;
        }
    }
}
