package com.htx.optimize;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.IdRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.htx.optimize.fragments.HomeFragment;
import com.htx.optimize.fragments.RamBoosterFragment;
import com.htx.optimize.fragments.RamCleanerFragment;
import com.htx.optimize.fragments.StorageFragment;
import com.htx.optimize.fragments.ToolsFragment;
import com.htx.optimize.util.FormatUtils;
import com.htx.optimize.util.PermissionHelper;

public class MainActivity extends AppCompatActivity {

    private static final String STATE_SELECTED_TAB = "htx.selected_tab";
    private BottomNavigationView bottomNavigation;
    private int selectedTabId = R.id.nav_home;

    private boolean chainActive;
    private boolean waitingRuntime;
    private final boolean[] asked = new boolean[3];

    private final ActivityResultLauncher<String[]> runtimeLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                waitingRuntime = false;
                if (chainActive) requestNext();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View root = findViewById(R.id.root_layout);
        if (root != null) {
            final int left = root.getPaddingLeft();
            final int top = root.getPaddingTop();
            final int right = root.getPaddingRight();
            final int bottom = root.getPaddingBottom();
            ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
                Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                view.setPadding(left + bars.left, top + bars.top,
                        right + bars.right, bottom + bars.bottom);
                return insets;
            });
        }

        bottomNavigation = findViewById(R.id.bottom_navigation);
        if (savedInstanceState != null) {
            selectedTabId = savedInstanceState.getInt(STATE_SELECTED_TAB, R.id.nav_home);
        }

        if (bottomNavigation != null) {
            bottomNavigation.setOnItemSelectedListener(item -> {
                selectedTabId = item.getItemId();
                return showTab(selectedTabId);
            });

            if (savedInstanceState == null) {
                bottomNavigation.setSelectedItemId(R.id.nav_home);
            } else {
                bottomNavigation.setSelectedItemId(selectedTabId);
            }
        } else if (savedInstanceState == null) {
            showTab(R.id.nav_home);
        }

        if (savedInstanceState == null && !PermissionHelper.allGranted(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Permissões necessárias")
                    .setMessage("Para otimizar a RAM, limpar arquivos e mostrar o monitor flutuante "
                            + "(FPS, CPU e RAM) sobre outros apps, o HTX Optimize precisa de:\n\n"
                            + "• Acesso ao armazenamento\n• Sobrepor outros aplicativos\n• Notificações")
                    .setNegativeButton("Depois", null)
                    .setPositiveButton("Continuar", (d, w) -> startPermissionFlow())
                    .show();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (chainActive && !waitingRuntime) requestNext();
    }

    /** Pede, em sequência, notificações, armazenamento e sobreposição de apps. */
    public void startPermissionFlow() {
        java.util.Arrays.fill(asked, false);
        chainActive = true;
        requestNext();
    }

    private void requestNext() {
        if (isFinishing() || isDestroyed()) return;
        if (!PermissionHelper.hasNotifications(this) && !asked[0]) {
            asked[0] = true;
            waitingRuntime = true;
            runtimeLauncher.launch(new String[]{Manifest.permission.POST_NOTIFICATIONS});
            return;
        }
        if (!PermissionHelper.hasStorage(this) && !asked[1]) {
            asked[1] = true;
            if (Build.VERSION.SDK_INT >= 30) {
                launchSettings(PermissionHelper.allFilesIntent(this));
            } else {
                waitingRuntime = true;
                runtimeLauncher.launch(new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE});
            }
            return;
        }
        if (!PermissionHelper.hasOverlay(this) && !asked[2]) {
            asked[2] = true;
            launchSettings(PermissionHelper.overlayIntent(this));
            return;
        }
        chainActive = false;
    }

    private void launchSettings(Intent intent) {
        if (!FormatUtils.safeStartActivity(this, intent)) requestNext();
    }

    public void selectTab(@IdRes int menuItemId) {
        if (bottomNavigation != null && !isFinishing() && !isDestroyed()) {
            bottomNavigation.setSelectedItemId(menuItemId);
        }
    }

    private boolean showTab(@IdRes int id) {
        Fragment target;
        if (id == R.id.nav_ram_cleaner) {
            target = new RamCleanerFragment();
        } else if (id == R.id.nav_ram_booster) {
            target = new RamBoosterFragment();
        } else if (id == R.id.nav_storage) {
            target = new StorageFragment();
        } else if (id == R.id.nav_tools) {
            target = new ToolsFragment();
        } else {
            target = new HomeFragment();
            selectedTabId = R.id.nav_home;
        }

        FragmentManager manager = getSupportFragmentManager();
        if (isFinishing() || isDestroyed() || manager.isStateSaved()) {
            return false;
        }
        manager.beginTransaction()
                .setReorderingAllowed(true)
                .replace(R.id.fragment_container, target)
                .commit();
        return true;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putInt(STATE_SELECTED_TAB, selectedTabId);
        super.onSaveInstanceState(outState);
    }
}
