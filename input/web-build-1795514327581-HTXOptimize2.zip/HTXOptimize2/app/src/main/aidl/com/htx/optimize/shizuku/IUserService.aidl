package com.htx.optimize.shizuku;

interface IUserService {
    // Código reservado pelo Shizuku para encerrar o serviço.
    void destroy() = 16777114;

    // Executa "sh -c <command>" com o privilégio do Shizuku e devolve a saída (stdout+stderr).
    String exec(String command) = 1;
}
