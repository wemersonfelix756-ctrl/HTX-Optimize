package com.htx.optimize;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.view.*;
import android.widget.*;
import androidx.documentfile.provider.DocumentFile;
import java.io.File;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_FOLDER = 501;
    private LinearLayout root, content;
    private TextView ramValue, storageValue, batteryValue, statusText;
    private DocumentFile selectedFolder;
    private final ArrayList<DocumentFile> foundFiles = new ArrayList<>();
    private final ArrayList<CheckBox> fileChecks = new ArrayList<>();

    private int purple = Color.rgb(183, 105, 255);
    private int bg = Color.rgb(9, 7, 17);
    private int panel = Color.rgb(24, 19, 37);
    private int muted = Color.rgb(177, 166, 196);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildShell();
        showDashboard();
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        TextView brand = new TextView(this);
        brand.setText("HTX  OPTIMIZE  ✦");
        brand.setTextColor(purple);
        brand.setTextSize(22);
        brand.setTypeface(Typeface.DEFAULT_BOLD);
        brand.setPadding(dp(20), dp(22), dp(16), dp(4));
        root.addView(brand);
        TextView sub = new TextView(this);
        sub.setText("ANDROID PERFORMANCE CENTER  •  V2.0");
        sub.setTextColor(muted);
        sub.setTextSize(10);
        sub.setPadding(dp(20), 0, dp(16), dp(16));
        root.addView(sub);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(4), dp(16), dp(22));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setPadding(dp(8), dp(8), dp(8), dp(8));
        nav.setBackgroundColor(Color.rgb(17, 13, 27));
        addNav(nav, "Início", this::showDashboard);
        addNav(nav, "RAM", this::showRam);
        addNav(nav, "Arquivos", this::showStorage);
        addNav(nav, "Sistema", this::showSystem);
        root.addView(nav);
        setContentView(root);
    }

    private void addNav(LinearLayout nav, String label, Runnable action) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(8), dp(12), dp(8), dp(12));
        b.setOnClickListener(v -> action.run());
        nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private void showDashboard() {
        content.removeAllViews();
        heading("Painel de desempenho", "Resumo em tempo real do dispositivo");
        LinearLayout row = new LinearLayout(this);
        row.addView(metricCard("RAM DISPONÍVEL", getRamAvailable(), v -> ramValue = v), new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(metricCard("BATERIA", getBattery(), v -> batteryValue = v), new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(row);
        content.addView(metricCard("ARMAZENAMENTO", getStorage(), v -> storageValue = v));
        cardTitle("Ações rápidas");
        actionButton("Analisar memória RAM", this::showRam);
        actionButton("Analisar arquivos e espaço", this::showStorage);
        actionButton("Ferramentas do Android", this::showSystem);
        cardTitle("Estado do sistema");
        TextView note = body("O HTX Optimize monitora informações do aparelho e abre ferramentas oficiais do Android. O sistema controla automaticamente a memória; este app não força encerramento de outros aplicativos.");
        content.addView(note);
        cardTitle("Desenvolvedor");
        content.addView(body("Wemerson Dev  •  Android Optimization & Development\nHTX Optimize 2.0"));
    }

    private View metricCard(String title, String value, java.util.function.Consumer<TextView> sink) {
        LinearLayout c = card();
        TextView t = label(title);
        TextView v = new TextView(this);
        v.setText(value); v.setTextColor(Color.WHITE); v.setTextSize(20); v.setTypeface(null, Typeface.BOLD);
        c.addView(t); c.addView(v);
        if (sink != null) sink.accept(v);
        return c;
    }

    private void showRam() {
        content.removeAllViews();
        heading("RAM Cleaner", "Monitoramento seguro da memória");
        content.addView(metricCard("RAM DISPONÍVEL", getRamAvailable(), null));
        ActivityManager am = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        content.addView(metricCard("RAM TOTAL", formatBytes(mi.totalMem), null));
        content.addView(metricCard("ESTADO", mi.lowMemory ? "Memória baixa" : "Funcionamento normal", null));
        cardTitle("O que você pode fazer");
        content.addView(body("O Android decide quando pausar ou encerrar processos em segundo plano. Aplicativos comuns não podem fechar à força outros apps nem garantir aumento de RAM."));
        actionButton("Abrir configurações de aplicativos", () -> openSettings("android.settings.APPLICATION_SETTINGS"));
        actionButton("Abrir opções de desenvolvedor", () -> openSettings("android.settings.APPLICATION_DEVELOPMENT_SETTINGS"));
        actionButton("Atualizar leitura", this::showRam);
    }

    private void showStorage() {
        content.removeAllViews();
        heading("Gerenciador de armazenamento", "Escolha uma pasta para analisar arquivos");
        content.addView(body("Por segurança, o Android exige que você escolha a pasta que o HTX Optimize poderá analisar. O app não acessa dados privados de outros aplicativos."));
        actionButton("Escolher pasta para analisar", () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, PICK_FOLDER);
        });
        if (selectedFolder != null) {
            content.addView(body("Pasta selecionada: " + selectedFolder.getName()));
            actionButton("Analisar arquivos", this::scanFolder);
            actionButton("Limpar resultados", () -> { foundFiles.clear(); showStorage(); });
        }
        if (!foundFiles.isEmpty()) {
            cardTitle("Arquivos encontrados (maiores primeiro)");
            fileChecks.clear();
            for (DocumentFile f : foundFiles) {
                CheckBox cb = new CheckBox(this);
                cb.setTextColor(Color.WHITE);
                cb.setText(f.getName() + "  •  " + formatBytes(f.length()));
                cb.setTag(f);
                fileChecks.add(cb);
                content.addView(cb);
            }
            actionButton("Excluir arquivos selecionados", this::deleteSelected);
            content.addView(body("Confira cada item antes de excluir. A exclusão não pode ser desfeita."));
        }
    }

    private void scanFolder() {
        foundFiles.clear();
        scanRecursive(selectedFolder, 0);
        Collections.sort(foundFiles, (a,b) -> Long.compare(b.length(), a.length()));
        showStorage();
        Toast.makeText(this, foundFiles.size() + " arquivo(s) encontrados", Toast.LENGTH_SHORT).show();
    }

    private void scanRecursive(DocumentFile dir, int depth) {
        if (dir == null || !dir.isDirectory() || depth > 8 || foundFiles.size() > 500) return;
        for (DocumentFile f : dir.listFiles()) {
            if (f.isDirectory()) scanRecursive(f, depth + 1);
            else if (f.isFile()) foundFiles.add(f);
        }
    }

    private void deleteSelected() {
        int deleted = 0;
        for (CheckBox cb : fileChecks) {
            if (cb.isChecked()) {
                DocumentFile f = (DocumentFile) cb.getTag();
                if (f.delete()) deleted++;
            }
        }
        Toast.makeText(this, deleted + " arquivo(s) excluído(s)", Toast.LENGTH_LONG).show();
        scanFolder();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FOLDER && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags);
            selectedFolder = DocumentFile.fromTreeUri(this, uri);
            showStorage();
        }
    }

    private void showSystem() {
        content.removeAllViews();
        heading("Ferramentas do sistema", "Atalhos para configurações oficiais");
        actionButton("Armazenamento", () -> openSettings("android.settings.INTERNAL_STORAGE_SETTINGS"));
        actionButton("Bateria", () -> openSettings("android.settings.BATTERY_SAVER_SETTINGS"));
        actionButton("Gerenciar aplicativos", () -> openSettings("android.settings.APPLICATION_SETTINGS"));
        actionButton("Informações do HTX Optimize", () -> {
            Intent i = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });
        cardTitle("Sobre as otimizações");
        content.addView(body("O HTX Optimize não promete acelerar o aparelho por truques. Ele oferece informações, análise de arquivos escolhidos por você e atalhos para recursos nativos do Android."));
        cardTitle("Créditos");
        content.addView(body("Desenvolvido por Wemerson Dev\nEspecialidade: Android Optimization & Development\nAplicativo: HTX Optimize\nVersão: 2.0"));
    }

    private void heading(String title, String subtitle) {
        TextView h = new TextView(this); h.setText(title); h.setTextColor(Color.WHITE); h.setTextSize(23); h.setTypeface(null, Typeface.BOLD);
        h.setPadding(0, dp(8), 0, dp(4)); content.addView(h);
        TextView s = body(subtitle); s.setPadding(0, 0, 0, dp(14)); content.addView(s);
    }
    private void cardTitle(String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(purple); t.setTextSize(15); t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(2), dp(18), dp(2), dp(8)); content.addView(t);
    }
    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(14), dp(14), dp(14)); c.setBackgroundColor(panel);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, dp(6), dp(8), dp(8)); c.setLayoutParams(p);
        return c;
    }
    private TextView label(String s) { TextView t = new TextView(this); t.setText(s); t.setTextColor(muted); t.setTextSize(10); t.setPadding(0,0,0,dp(8)); return t; }
    private TextView body(String s) { TextView t = new TextView(this); t.setText(s); t.setTextColor(muted); t.setTextSize(13); t.setLineSpacing(dp(3),1f); t.setPadding(dp(2),dp(4),dp(2),dp(8)); return t; }
    private void actionButton(String text, Runnable r) {
        TextView b = new TextView(this); b.setText(text + "   ›"); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setTypeface(null, Typeface.BOLD);
        b.setPadding(dp(16),dp(15),dp(16),dp(15)); b.setBackgroundColor(panel);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(5),0,dp(5)); content.addView(b,p);
        b.setOnClickListener(v -> r.run());
    }
    private void addNavDummy() {}
    private String getRamAvailable() {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
        return formatBytes(mi.availMem);
    }
    private String getStorage() {
        File path = getFilesDir();
        android.os.StatFs stat = new android.os.StatFs(path.getAbsolutePath());
        long total = stat.getTotalBytes(), free = stat.getAvailableBytes();
        return formatBytes(free) + " livre de " + formatBytes(total);
    }
    private String getBattery() {
        Intent i = registerReceiver(null, new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return "Indisponível";
        int level = i.getIntExtra("level", -1), scale = i.getIntExtra("scale", 100);
        return (level < 0 ? "?" : (level * 100 / scale)) + "%";
    }
    private String formatBytes(long n) {
        if (n < 1024) return n + " B";
        int exp = (int)(Math.log(n)/Math.log(1024));
        String pre = "KMGTPE".charAt(exp-1) + "B";
        return String.format(java.util.Locale.US, "%.1f %s", n/Math.pow(1024,exp), pre);
    }
    private void openSettings(String action) {
        try { startActivity(new Intent(action)); }
        catch (Exception e) { Toast.makeText(this, "Essa tela não está disponível neste Android.", Toast.LENGTH_SHORT).show(); }
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density); }
}
