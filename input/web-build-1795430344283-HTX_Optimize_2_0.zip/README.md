# HTX Optimize 2.0

Projeto Android nativo (Java) para compilar em APK.

## Incluído
- Painel com RAM disponível, armazenamento e bateria.
- Monitoramento de RAM e estado de memória baixa.
- Gerenciador de arquivos usando a pasta escolhida pelo usuário via Android Storage Access Framework.
- Lista arquivos encontrados e permite selecionar/excluir arquivos.
- Atalhos para configurações nativas de armazenamento, bateria e aplicativos.
- Créditos: Wemerson Dev — Android Optimization & Development.

## Limites importantes do Android
- O app só analisa a pasta que o usuário autorizar.
- Não acessa dados privados de outros apps.
- Apps comuns não podem forçar o encerramento de outros apps nem "esvaziar" RAM artificialmente. O Android administra processos automaticamente.
- O espaço mostrado no painel é o espaço disponível na partição de dados do app; para analisar outras pastas, use o Gerenciador de armazenamento.

## Compilar
Abra este repositório em um serviço de build Android compatível com Gradle/Android Gradle Plugin 8.7.3, JDK 17 e compile o módulo `app` (assembleDebug).
