package com.htx.optimize.monitor;

import com.htx.optimize.util.Shell;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Mede o FPS real do app em foco (precisa de um Shell privilegiado).
 * 1) SurfaceFlinger --latency (jogos/vídeo/SurfaceView)  2) gfxinfo framestats (apps com UI padrão).
 */
public final class FpsSampler {

    public static final class Sample {
        public final float fps;          // NaN = indisponível
        public final String pkg;         // app em foco (pode ser null)
        public final String source;      // "SF", "GFX" ou null
        public final String status;      // motivo quando indisponível
        public final long[] intervalsNs; // tempos de quadro novos

        Sample(float fps, String pkg, String source, String status, long[] intervalsNs) {
            this.fps = fps;
            this.pkg = pkg;
            this.source = source;
            this.status = status;
            this.intervalsNs = intervalsNs;
        }
    }

    private static final long RESOLVE_INTERVAL_MS = 4000L;
    private static final long[] NO_INTERVALS = new long[0];
    private static final String RESOLVE_CMD =
            "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'; echo '@@LIST'; "
                    + "dumpsys SurfaceFlinger --list";

    private final Shell shell;
    private final Map<String, Long> previousMax = new HashMap<>();
    private long previousGfxMax;
    private List<String> layers = new ArrayList<>();
    private String pkg;
    private long lastResolve = -1L;
    private String debug = "";

    public FpsSampler(Shell shell) {
        this.shell = shell;
    }

    public String debugReport() { return debug; }

    public Sample sample(long nowMs) {
        StringBuilder dbg = new StringBuilder();
        try {
            if (layers.isEmpty() || lastResolve < 0L || nowMs - lastResolve > RESOLVE_INTERVAL_MS) {
                resolve(nowMs, dbg);
            }
            if (pkg == null) {
                dbg.append("Nenhum app em foco encontrado (mCurrentFocus vazio).\n");
                debug = dbg.toString();
                return new Sample(Float.NaN, null, null, "Sem app em foco", NO_INTERVALS);
            }

            boolean anyValid = false;
            FpsParser.Result chosen = null;
            if (!layers.isEmpty()) {
                String output = shell.run(FpsParser.buildLatencyCommand(layers));
                List<String> sections = FpsParser.splitSections(output, layers.size());
                for (int i = 0; i < layers.size(); i++) {
                    String layer = layers.get(i);
                    Long prev = previousMax.get(layer);
                    FpsParser.Result r = FpsParser.compute(sections.get(i), prev == null ? 0L : prev);
                    dbg.append(String.format(Locale.US, "SF[%d] %s -> %s, %.1f fps\n", i, layer,
                            r.valid ? "dados ok" : "sem dados", r.fps));
                    if (!r.valid) continue;
                    anyValid = true;
                    previousMax.put(layer, r.maxTs);
                    if (chosen == null && r.fps > 0f) chosen = r;
                }
            } else {
                dbg.append("Nenhuma camada do SurfaceFlinger contém o pacote ").append(pkg).append(".\n");
            }
            if (chosen != null) {
                debug = dbg.toString();
                return new Sample(chosen.fps, pkg, "SF", "ok", chosen.intervalsNs);
            }

            // Fallback: gfxinfo (apps comuns)
            boolean gfxValid = false;
            try {
                String gfx = shell.run("dumpsys gfxinfo " + pkg + " framestats");
                FpsParser.Result g = FpsParser.computeFramestats(gfx, previousGfxMax);
                dbg.append(String.format(Locale.US, "GFX -> %s, %.1f fps\n",
                        g.valid ? "dados ok" : "sem dados", g.fps));
                if (g.valid) {
                    gfxValid = true;
                    previousGfxMax = g.maxTs;
                    if (g.fps > 0f) {
                        debug = dbg.toString();
                        return new Sample(g.fps, pkg, "GFX", "ok", g.intervalsNs);
                    }
                }
            } catch (Exception exception) {
                dbg.append("GFX erro: ").append(exception.getMessage()).append('\n');
            }

            debug = dbg.toString();
            if (anyValid || gfxValid) return new Sample(0f, pkg, "SF", "ok", NO_INTERVALS);
            lastResolve = -1L; // reavalia as camadas no próximo ciclo
            String shortPkg = shorten(pkg);
            return new Sample(Float.NaN, pkg, null,
                    layers.isEmpty() ? "Sem camada: " + shortPkg : "Sem dados: " + shortPkg, NO_INTERVALS);
        } catch (Exception exception) {
            lastResolve = -1L;
            dbg.append("ERRO: ").append(exception.getMessage()).append('\n');
            debug = dbg.toString();
            return new Sample(Float.NaN, pkg, null, "Erro no Shizuku", NO_INTERVALS);
        }
    }

    private void resolve(long nowMs, StringBuilder dbg) throws Exception {
        lastResolve = nowMs;
        String out = shell.run(RESOLVE_CMD);
        if (out == null) out = "";
        int idx = out.indexOf("@@LIST");
        String focusPart = idx >= 0 ? out.substring(0, idx) : out;
        String listPart = idx >= 0 ? out.substring(idx + "@@LIST".length()) : "";
        String newPkg = FpsParser.parseFocusedPackage(focusPart);
        if (newPkg == null || !newPkg.equals(pkg)) {
            previousMax.clear();
            previousGfxMax = 0L;
        }
        pkg = newPkg;
        layers = FpsParser.pickLayers(listPart, pkg, 4);
        dbg.append("App em foco: ").append(pkg).append('\n');
        dbg.append("Camadas candidatas: ").append(layers.size()).append('\n');
        for (String layer : layers) dbg.append("  • ").append(layer).append('\n');
    }

    public static String shorten(String value) {
        if (value == null) return "";
        return value.length() > 24 ? "…" + value.substring(value.length() - 23) : value;
    }
}
