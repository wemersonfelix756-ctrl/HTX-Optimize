package com.htx.optimize.monitor;

import static org.junit.Assert.*;

import com.htx.optimize.util.Shell;
import java.util.Arrays;
import org.junit.Test;

public class FpsParserTest {

    private static String latency(int frames, long stepNs, long startNs) {
        StringBuilder sb = new StringBuilder("16666666\n");
        for (int i = 0; i < frames; i++) {
            long t = startNs + i * stepNs;
            sb.append(t).append(' ').append(t).append(' ').append(t).append('\n');
        }
        sb.append("0 9223372036854775807 0\n");
        return sb.toString();
    }

    @Test public void computesSixtyFps() {
        FpsParser.Result r = FpsParser.compute(latency(120, 16_666_667L, 1_000_000_000L), 0L);
        assertTrue(r.valid);
        assertEquals(60f, r.fps, 1.5f);
    }

    @Test public void computesThirtyFps() {
        FpsParser.Result r = FpsParser.compute(latency(90, 33_333_333L, 5_000_000_000L), 0L);
        assertEquals(30f, r.fps, 1.5f);
    }

    @Test public void reportsZeroWhenNoNewFrames() {
        String out = latency(60, 16_666_667L, 1_000_000_000L);
        FpsParser.Result first = FpsParser.compute(out, 0L);
        FpsParser.Result second = FpsParser.compute(out, first.maxTs);
        assertTrue(second.valid);
        assertEquals(0f, second.fps, 0.01f);
    }

    @Test public void invalidWhenEmpty() {
        assertFalse(FpsParser.compute("0\n", 0L).valid);
        assertFalse(FpsParser.compute(null, 0L).valid);
    }

    @Test public void parsesFocusedPackage() {
        String dump = "  mCurrentFocus=Window{a1b2c3 u0 com.dts.freefireth/com.dts.freefireth.FFMainActivity}\n"
                + "  mFocusedApp=ActivityRecord{1234 u0 com.dts.freefireth/.FFMainActivity t12}\n";
        assertEquals("com.dts.freefireth", FpsParser.parseFocusedPackage(dump));
        assertNull(FpsParser.parseFocusedPackage("  mCurrentFocus=null\n"));
    }

    @Test public void picksSurfaceViewFirst() {
        String list = "com.game/com.game.Main#0\nBackground for SurfaceView[com.game/com.game.Main](BLAST)#1\n"
                + "SurfaceView[com.game/com.game.Main](BLAST)#2\nother.app/x#0\n";
        assertEquals(Arrays.asList("SurfaceView[com.game/com.game.Main](BLAST)#2", "com.game/com.game.Main#0"),
                FpsParser.pickLayers(list, "com.game", 3));
    }

    @Test public void samplerEndToEnd() {
        final String focus = "mCurrentFocus=Window{a u0 com.game/com.game.Main}\n@@LIST\n"
                + "SurfaceView[com.game/com.game.Main](BLAST)#2\n";
        Shell fake = new Shell() {
            @Override public String run(String command) {
                if (command.contains("mCurrentFocus")) return focus;
                return "@@L0\n" + latency(120, 16_666_667L, 1_000_000_000L);
            }
        };
        FpsSampler sampler = new FpsSampler(fake);
        FpsSampler.Sample s = sampler.sample(1000L);
        assertEquals("com.game", s.pkg);
        assertEquals(60f, s.fps, 1.5f);
    }

    @Test public void quotesSingleQuotes() {
        assertEquals("'a'\\''b'", FpsParser.quote("a'b"));
    }

    @Test public void fallsBackToOtherColumns() {
        StringBuilder sb = new StringBuilder("16666666\n");
        for (int i = 0; i < 120; i++) {
            long t = 2_000_000_000L + i * 16_666_667L;
            sb.append(t).append(" 0 ").append(t).append('\n'); // coluna 2 vazia
        }
        FpsParser.Result r = FpsParser.compute(sb.toString(), 0L);
        assertTrue(r.valid);
        assertEquals(60f, r.fps, 1.5f);
    }

    @Test public void parsesGfxinfoFramestats() {
        StringBuilder sb = new StringBuilder("Profile data in ms:\n---PROFILEDATA---\nFlags,IntendedVsync,FrameCompleted,\n");
        for (int i = 0; i < 100; i++) {
            long t = 3_000_000_000L + i * 16_666_667L;
            sb.append("0,").append(t).append(',').append(t).append(",\n");
        }
        sb.append("---PROFILEDATA---\n");
        FpsParser.Result r = FpsParser.computeFramestats(sb.toString(), 0L);
        assertTrue(r.valid);
        assertEquals(60f, r.fps, 1.5f);
        assertTrue(r.intervalsNs.length > 50);
    }

    @Test public void statsComputeLows() {
        FpsStats stats = new FpsStats();
        long[] frames = new long[200];
        for (int i = 0; i < frames.length; i++) frames[i] = i % 50 == 0 ? 50_000_000L : 16_666_667L;
        stats.addIntervals("com.game", frames);
        FpsStats.Summary s = stats.summary();
        assertNotNull(s);
        assertTrue(s.low1Fps < s.avgFps);
        assertEquals(4, s.stutters);
    }
}
