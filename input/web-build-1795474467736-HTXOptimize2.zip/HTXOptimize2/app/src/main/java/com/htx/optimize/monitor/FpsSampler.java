package com.htx.optimize.monitor;

import com.htx.optimize.util.Shell;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Mede o FPS real do app em foco consultando o SurfaceFlinger (precisa de um Shell privilegiado). */
public final class FpsSampler {

    public static final class Sample {
        public final float fps;      // NaN = indisponível
        public final String pkg;     // app em foco (pode ser null)

        Sample(float fps, String pkg) {
            this.fps = fps;
            this.pkg = pkg;
        }
    }

    private static final long RESOLVE_INTERVAL_MS = 4000L;
    private static final String RESOLVE_CMD =
            "dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'; echo '@@LIST'; "
                    + "dumpsys SurfaceFlinger --list";

    private final Shell shell;
    private final Map<String, Long> previousMax = new HashMap<>();
    private List<String> layers = new ArrayList<>();
    private String pkg;
    private long lastResolve = -1L;

    public FpsSampler(Shell shell) {
        this.shell = shell;
    }

    public Sample sample(long nowMs) {
        try {
            if (layers.isEmpty() || lastResolve < 0L || nowMs - lastResolve > RESOLVE_INTERVAL_MS) {
                resolve(nowMs);
            }
            if (layers.isEmpty()) return new Sample(Float.NaN, pkg);

            String output = shell.run(FpsParser.buildLatencyCommand(layers));
            List<String> sections = FpsParser.splitSections(output, layers.size());
            boolean anyValid = false;
            for (int i = 0; i < layers.size(); i++) {
                String layer = layers.get(i);
                Long prev = previousMax.get(layer);
                FpsParser.Result r = FpsParser.compute(sections.get(i), prev == null ? 0L : prev);
                if (!r.valid) continue;
                anyValid = true;
                previousMax.put(layer, r.maxTs);
                if (r.fps > 0f) return new Sample(r.fps, pkg);
            }
            if (anyValid) return new Sample(0f, pkg);
            lastResolve = -1L; // camada sumiu: reavalia no próximo ciclo
            return new Sample(Float.NaN, pkg);
        } catch (Exception exception) {
            lastResolve = -1L;
            return new Sample(Float.NaN, pkg);
        }
    }

    private void resolve(long nowMs) throws Exception {
        lastResolve = nowMs;
        String out = shell.run(RESOLVE_CMD);
        if (out == null) out = "";
        int idx = out.indexOf("@@LIST");
        String focusPart = idx >= 0 ? out.substring(0, idx) : out;
        String listPart = idx >= 0 ? out.substring(idx + "@@LIST".length()) : "";
        String newPkg = FpsParser.parseFocusedPackage(focusPart);
        if (newPkg == null || !newPkg.equals(pkg)) previousMax.clear();
        pkg = newPkg;
        layers = FpsParser.pickLayers(listPart, pkg, 3);
    }
}
