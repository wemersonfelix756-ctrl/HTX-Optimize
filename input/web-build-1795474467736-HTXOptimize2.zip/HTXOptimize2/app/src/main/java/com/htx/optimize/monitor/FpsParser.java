package com.htx.optimize.monitor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Interpretação pura (sem Android) das saídas de dumpsys usadas para medir o FPS real. */
public final class FpsParser {

    public static final class Result {
        public final float fps;
        public final long maxTs;
        public final boolean valid;

        Result(float fps, long maxTs, boolean valid) {
            this.fps = fps;
            this.maxTs = maxTs;
            this.valid = valid;
        }
    }

    private static final long PENDING_TS = Long.MAX_VALUE / 2;
    private static final Pattern FOCUS_PKG = Pattern.compile("\\bu\\d+\\s+([A-Za-z0-9_.]+)/");

    private FpsParser() { }

    /** Saída de "dumpsys SurfaceFlinger --latency <layer>": 1ª linha = período; depois 3 colunas. */
    public static Result compute(String output, long prevMaxTs) {
        if (output == null) return new Result(0f, 0L, false);
        String[] lines = output.split("\n");
        List<Long> stamps = new ArrayList<>();
        for (int i = 1; i < lines.length; i++) {
            String[] parts = lines[i].trim().split("\\s+");
            if (parts.length < 3) continue;
            try {
                long actual = Long.parseLong(parts[1]);
                if (actual > 0L && actual < PENDING_TS) stamps.add(actual);
            } catch (NumberFormatException ignored) {
                // linha inválida
            }
        }
        if (stamps.isEmpty()) return new Result(0f, 0L, false);

        long max = Collections.max(stamps);
        if (max == prevMaxTs) return new Result(0f, max, true); // nenhum quadro novo
        long windowStart = max - 1_000_000_000L;
        long first = max;
        int count = 0;
        for (long ts : stamps) {
            if (ts >= windowStart) {
                count++;
                if (ts < first) first = ts;
            }
        }
        long span = max - first;
        if (count < 2 || span <= 0L) return new Result(1f, max, true);
        float fps = (count - 1) * 1_000_000_000f / span;
        return new Result(Math.min(fps, 240f), max, true);
    }

    /** Pacote em foco a partir das linhas mCurrentFocus / mFocusedApp do "dumpsys window". */
    public static String parseFocusedPackage(String text) {
        if (text == null) return null;
        String fallback = null;
        for (String line : text.split("\n")) {
            boolean current = line.contains("mCurrentFocus") && !line.contains("=null");
            boolean app = line.contains("mFocusedApp") && !line.contains("=null");
            if (!current && !app) continue;
            Matcher m = FOCUS_PKG.matcher(line);
            if (!m.find()) continue;
            if (current) return m.group(1);
            if (fallback == null) fallback = m.group(1);
        }
        return fallback;
    }

    /** Camadas candidatas (SurfaceView primeiro) do "dumpsys SurfaceFlinger --list". */
    public static List<String> pickLayers(String list, String pkg, int max) {
        List<String> found = new ArrayList<>();
        if (list == null || pkg == null) return found;
        for (String raw : list.split("\n")) {
            String line = raw.trim();
            if (line.isEmpty() || !line.contains(pkg)) continue;
            if (line.startsWith("Background for") || line.startsWith("Bounds for")
                    || line.startsWith("Letterbox") || line.startsWith("Dim layer")) continue;
            if (!found.contains(line)) found.add(line);
        }
        Collections.sort(found, new Comparator<String>() {
            @Override public int compare(String a, String b) {
                return Integer.compare(rank(a), rank(b));
            }
        });
        return found.size() > max ? new ArrayList<>(found.subList(0, max)) : found;
    }

    private static int rank(String layer) {
        if (layer.startsWith("SurfaceView")) return 0;
        if (layer.contains("/") && layer.contains("#")) return 1;
        return 2;
    }

    public static String quote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    public static String buildLatencyCommand(List<String> layers) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < layers.size(); i++) {
            sb.append("echo '@@L").append(i).append("'; dumpsys SurfaceFlinger --latency ")
                    .append(quote(layers.get(i))).append("; ");
        }
        return sb.toString();
    }

    public static List<String> splitSections(String output, int count) {
        List<StringBuilder> builders = new ArrayList<>();
        for (int i = 0; i < count; i++) builders.add(new StringBuilder());
        int current = -1;
        if (output != null) {
            for (String line : output.split("\n")) {
                String t = line.trim();
                if (t.startsWith("@@L")) {
                    try {
                        current = Integer.parseInt(t.substring(3));
                    } catch (NumberFormatException e) {
                        current = -1;
                    }
                } else if (current >= 0 && current < count) {
                    builders.get(current).append(line).append('\n');
                }
            }
        }
        List<String> result = new ArrayList<>();
        for (StringBuilder b : builders) result.add(b.toString());
        return result;
    }
}
