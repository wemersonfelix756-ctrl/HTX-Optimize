package com.htx.optimize.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import com.htx.optimize.MainActivity;
import com.htx.optimize.monitor.FpsSampler;
import com.htx.optimize.monitor.SystemMonitor;
import com.htx.optimize.monitor.ThermalReader;
import com.htx.optimize.shizuku.ShizukuBridge;
import com.htx.optimize.util.AppPrefs;
import com.htx.optimize.util.PermissionHelper;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Janelinha flutuante (HUD) com FPS da tela, temperatura da CPU e uso de RAM. */
public class OverlayService extends Service {

    public static final String ACTION_START = "com.htx.optimize.overlay.START";
    public static final String ACTION_STOP = "com.htx.optimize.overlay.STOP";

    private static final String CHANNEL_ID = "htx_overlay";
    private static final int NOTIFICATION_ID = 2301;
    private static final long TICK_MS = 1000L;
    private static final String PREFS = "htx_overlay_prefs";
    private static final String KEY_X = "x";
    private static final String KEY_Y = "y";

    private static final int CYAN = 0xFF22E5FF;
    private static final int OK = 0xFF34D399;
    private static final int WARN = 0xFFFBBF24;
    private static final int CRIT = 0xFFF87171;

    private static volatile boolean running;

    private final Handler main = new Handler(Looper.getMainLooper());
    private ExecutorService io;
    private WindowManager windowManager;
    private WindowManager.LayoutParams params;
    private LinearLayout hud;
    private TextView tvFps, tvCpu, tvRam;
    private TextView lbFps, lbCpu, lbRam;
    private boolean appliedBig;
    private FpsSampler sampler;

    private int frames;
    private long windowStart;
    private float refreshRate = 60f;

    private final Choreographer.FrameCallback frameCallback = new Choreographer.FrameCallback() {
        @Override public void doFrame(long frameTimeNanos) {
            frames++;
            if (running && hud != null) Choreographer.getInstance().postFrameCallback(this);
        }
    };

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running || hud == null) return;
            long now = System.currentTimeMillis();
            long elapsed = Math.max(1L, now - windowStart);
            final float fps = frames * 1000f / elapsed;
            frames = 0;
            windowStart = now;
            readAndRender(fps);
            main.postDelayed(this, TICK_MS);
        }
    };

    public static boolean isRunning() { return running; }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        enterForeground();
        if (!PermissionHelper.hasOverlay(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (hud == null) addOverlay();
        if (AppPrefs.realFps(this)) ShizukuBridge.bind(this);
        return START_NOT_STICKY;
    }

    private void enterForeground() {
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Monitor flutuante", NotificationManager.IMPORTANCE_LOW);
            channel.setShowBadge(false);
            nm.createNotificationChannel(channel);
        }
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stopIntent = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent stop = PendingIntent.getService(this, 1, stopIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentTitle("HTX Monitor ativo")
                .setContentText("FPS • CPU • RAM na tela")
                .setContentIntent(open)
                .addAction(0, "Fechar monitor", stop)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    @SuppressWarnings("deprecation")
    private void addOverlay() {
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        if (windowManager == null) { stopSelf(); return; }
        try {
            refreshRate = windowManager.getDefaultDisplay().getRefreshRate();
        } catch (RuntimeException ignored) {
            refreshRate = 60f;
        }

        hud = new LinearLayout(this);
        hud.setOrientation(LinearLayout.HORIZONTAL);
        hud.setGravity(Gravity.CENTER_VERTICAL);
        hud.setPadding(dp(10), dp(6), dp(10), dp(6));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE6050A18);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), CYAN);
        hud.setBackground(bg);

        tvFps = addCell(hud, "TELA");
        lbFps = lastLabel;
        addDivider(hud);
        tvCpu = addCell(hud, "CPU");
        lbCpu = lastLabel;
        addDivider(hud);
        tvRam = addCell(hud, "RAM");
        lbRam = lastLabel;

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        params.x = prefs.getInt(KEY_X, dp(12));
        params.y = prefs.getInt(KEY_Y, dp(90));

        hud.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;

            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = params.x; startY = params.y;
                        touchX = event.getRawX(); touchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = Math.max(0, startX + (int) (event.getRawX() - touchX));
                        params.y = Math.max(0, startY + (int) (event.getRawY() - touchY));
                        try {
                            windowManager.updateViewLayout(hud, params);
                        } catch (RuntimeException ignored) { }
                        return true;
                    case MotionEvent.ACTION_UP:
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                .putInt(KEY_X, params.x).putInt(KEY_Y, params.y).apply();
                        return true;
                    default:
                        return false;
                }
            }
        });

        try {
            windowManager.addView(hud, params);
        } catch (RuntimeException exception) {
            hud = null;
            stopSelf();
            return;
        }

        running = true;
        io = Executors.newSingleThreadExecutor();
        frames = 0;
        windowStart = System.currentTimeMillis();
        Choreographer.getInstance().postFrameCallback(frameCallback);
        main.postDelayed(tick, TICK_MS);
    }

    private void readAndRender(final float displayFps) {
        final Context app = getApplicationContext();
        if (io == null || io.isShutdown()) return;
        final boolean wantReal = AppPrefs.realFps(app) && ShizukuBridge.isConnected();
        io.execute(() -> {
            float shown = displayFps;
            boolean real = false;
            if (wantReal) {
                if (sampler == null) sampler = new FpsSampler(ShizukuBridge::exec);
                FpsSampler.Sample sample = sampler.sample(System.currentTimeMillis());
                if (!Float.isNaN(sample.fps)) {
                    shown = sample.fps;
                    real = true;
                }
            }
            final float fps = shown;
            final boolean isReal = real;
            final ThermalReader.Reading temp = ThermalReader.read(app);
            final SystemMonitor.RamSnapshot ram = SystemMonitor.readRam(app);
            main.post(() -> {
                if (!running || hud == null) return;
                applyAppearance();
                float ratio = refreshRate > 0f ? fps / refreshRate : 1f;
                lbFps.setText(isReal ? "FPS" : "TELA");
                tvFps.setText(String.format(Locale.US, "%.0f", fps));
                tvFps.setTextColor(ratio >= 0.9f ? OK : ratio >= 0.6f ? WARN : CRIT);

                tvCpu.setText(ThermalReader.format(temp) + (temp.fromCpu ? "" : "b"));
                tvCpu.setTextColor(Float.isNaN(temp.celsius) ? Color.LTGRAY
                        : temp.celsius < 45f ? OK : temp.celsius < 60f ? WARN : CRIT);

                tvRam.setText(ram.usedPercent + "%");
                tvRam.setTextColor(ram.usedPercent < 70 ? OK : ram.usedPercent < 85 ? WARN : CRIT);
            });
        });
    }

    private void applyAppearance() {
        hud.setAlpha(AppPrefs.overlayOpacity(this) / 100f);
        boolean big = AppPrefs.overlayBig(this);
        if (big == appliedBig) return;
        appliedBig = big;
        float value = big ? 20f : 15f;
        float label = big ? 11f : 9f;
        for (TextView t : new TextView[]{tvFps, tvCpu, tvRam}) t.setTextSize(value);
        for (TextView t : new TextView[]{lbFps, lbCpu, lbRam}) t.setTextSize(label);
    }

    private TextView addCell(LinearLayout parent, String label) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText(label);
        title.setTextColor(CYAN);
        title.setTextSize(9f);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setLetterSpacing(0.12f);
        lastLabel = title;

        TextView value = new TextView(this);
        value.setText("--");
        value.setTextColor(Color.WHITE);
        value.setTextSize(15f);
        value.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        value.setMinWidth(dp(34));
        value.setGravity(Gravity.CENTER_HORIZONTAL);

        cell.addView(title);
        cell.addView(value);
        parent.addView(cell);
        return value;
    }

    private void addDivider(LinearLayout parent) {
        View line = new View(this);
        line.setBackgroundColor(0x5522E5FF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(1), dp(24));
        lp.setMargins(dp(8), 0, dp(8), 0);
        parent.addView(line, lp);
    }

    private TextView lastLabel;

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override public void onDestroy() {
        running = false;
        main.removeCallbacksAndMessages(null);
        try {
            Choreographer.getInstance().removeFrameCallback(frameCallback);
        } catch (RuntimeException ignored) { }
        if (windowManager != null && hud != null) {
            try {
                windowManager.removeView(hud);
            } catch (RuntimeException ignored) { }
        }
        hud = null;
        ShizukuBridge.unbind(this);
        if (io != null) io.shutdownNow();
        super.onDestroy();
    }
}
