package com.htx.optimize.shizuku;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import rikka.shizuku.Shizuku;

/** Ponte com o Shizuku: estado, permissão e serviço de usuário para rodar comandos. */
public final class ShizukuBridge {

    public static final String SHIZUKU_PACKAGE = "moe.shizuku.privileged.api";
    public static final int REQUEST_CODE = 7301;

    public enum State { NOT_INSTALLED, NOT_RUNNING, NO_PERMISSION, READY }

    private static volatile IUserService service;
    private static volatile boolean binding;

    private static final ServiceConnection CONNECTION = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName name, IBinder binder) {
            service = binder != null && binder.pingBinder() ? IUserService.Stub.asInterface(binder) : null;
            binding = false;
        }

        @Override public void onServiceDisconnected(ComponentName name) {
            service = null;
            binding = false;
        }
    };

    private ShizukuBridge() { }

    public static boolean isInstalled(Context context) {
        try {
            context.getPackageManager().getPackageInfo(SHIZUKU_PACKAGE, 0);
            return true;
        } catch (PackageManager.NameNotFoundException exception) {
            return false;
        } catch (RuntimeException exception) {
            return false;
        }
    }

    public static boolean isRunning() {
        try {
            return Shizuku.pingBinder();
        } catch (RuntimeException exception) {
            return false;
        }
    }

    public static boolean hasPermission() {
        try {
            return isRunning() && !Shizuku.isPreV11()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (RuntimeException exception) {
            return false;
        }
    }

    public static State state(Context context) {
        if (!isRunning()) return isInstalled(context) ? State.NOT_RUNNING : State.NOT_INSTALLED;
        return hasPermission() ? State.READY : State.NO_PERMISSION;
    }

    public static void requestPermission() {
        try {
            if (isRunning() && !Shizuku.isPreV11()) Shizuku.requestPermission(REQUEST_CODE);
        } catch (RuntimeException ignored) {
            // Shizuku indisponível
        }
    }

    public static Intent launchIntent(Context context) {
        return context.getPackageManager().getLaunchIntentForPackage(SHIZUKU_PACKAGE);
    }

    private static Shizuku.UserServiceArgs args(Context context) {
        return new Shizuku.UserServiceArgs(new ComponentName(context.getPackageName(),
                ShizukuUserService.class.getName()))
                .daemon(false)
                .processNameSuffix("shell")
                .debuggable(false)
                .version(1);
    }

    public static boolean isConnected() {
        IUserService s = service;
        return s != null && s.asBinder().pingBinder();
    }

    public static synchronized void bind(Context context) {
        if (isConnected() || binding || !hasPermission()) return;
        try {
            binding = true;
            Shizuku.bindUserService(args(context.getApplicationContext()), CONNECTION);
        } catch (RuntimeException exception) {
            binding = false;
        }
    }

    public static synchronized void unbind(Context context) {
        try {
            if (service != null || binding) {
                Shizuku.unbindUserService(args(context.getApplicationContext()), CONNECTION, true);
            }
        } catch (RuntimeException ignored) {
            // já desconectado
        }
        service = null;
        binding = false;
    }

    /** Bloqueante: chamar fora da thread principal. */
    public static boolean awaitConnected(Context context, long timeoutMs) {
        bind(context);
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (!isConnected() && System.currentTimeMillis() < deadline) {
            try {
                Thread.sleep(100L);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        return isConnected();
    }

    public static String exec(String command) throws Exception {
        IUserService s = service;
        if (s == null) throw new IllegalStateException("Shizuku não conectado");
        return s.exec(command);
    }
}
