# HTX Optimize 2.2 — Reforçado

Aplicativo Android nativo de monitoramento local e gerenciamento de arquivos selecionados pelo usuário. A interface existente foi preservada: layouts, cores, ícones, drawables e menu não foram redesenhados.

## Reforços internos
- Leituras de RAM, armazenamento e bateria executadas fora da thread principal nas telas de monitoramento.
- Atualizações interrompidas quando a tela deixa de estar ativa e callbacks protegidos contra views destruídas.
- Navegação com transações seguras, restauração da aba selecionada e sem `commitAllowingStateLoss`.
- Monitoramento de RAM com execução em segundo plano e encerramento correto dos workers no ciclo de vida dos fragments.
- Varredura SAF com limite de arquivos e profundidade, tratamento por entrada, ordenação por tamanho e proteção contra resultados obsoletos.
- Exclusão somente de arquivos explicitamente selecionados, com confirmação, contagem de sucesso/falha e atualização da lista. Pastas não são excluídas.
- Cálculos de espaço com proteção contra valores negativos e overflow.
- Leitura de bateria e memória com resultados de fallback quando o Android/provedor não fornece dados.
- `allowBackup=false` mantido para evitar backup automático dos dados locais do app.
- Versão Android atualizada para 2.2 (versionCode 22).

## Limites reais do Android
Um app comum não pode encerrar à força processos de outros aplicativos nem garantir liberação global de RAM. A função Booster faz diagnóstico e solicita GC apenas para o processo do HTX Optimize; o Android gerencia os demais processos. A exclusão de arquivos depende das permissões concedidas pelo seletor de documentos do Android.

## Gerar APK pelo GitHub Actions
1. Extraia o ZIP e envie o conteúdo da pasta `HTXOptimize2` para um repositório GitHub.
2. Abra **Actions** e execute **Build HTX Optimize 2.2 APK**.
3. Baixe o artefato **HTX-Optimize-2.2-APKs**.
4. O APK Debug serve para testes. O APK Release gerado pelo workflow é unsigned e precisa ser assinado com sua chave privada antes de distribuição.

## Verificação
Os arquivos Java/XML foram revisados estaticamente e os XMLs serão validados no pacote. Este ambiente não possui Gradle nem Android SDK configurados; portanto, não afirmamos que o APK foi compilado ou executado aqui.


## v2.5 — Shizuku, Modo Jogo e novo visual

- FPS real do app em foco via Shizuku (`dumpsys SurfaceFlinger --latency`); sem Shizuku a janelinha mostra a taxa da tela ("TELA").
- Otimização profunda opcional (`am force-stop`) via Shizuku.
- Modo Jogo (1 toque), info de CPU, teste de velocidade do armazenamento, aparência da janelinha (opacidade/tamanho).
- minSdk agora é 24 (requisito da biblioteca do Shizuku).
