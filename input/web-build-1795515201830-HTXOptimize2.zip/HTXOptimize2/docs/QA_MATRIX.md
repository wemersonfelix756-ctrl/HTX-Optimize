# HTX Optimize QA matrix

| Area | Scenario | Expected result |
|---|---|---|
| Startup | Cold launch | Main screen opens without InflateException |
| Navigation | Tap each bottom item | Matching fragment appears |
| Navigation | Rotate/recreate Activity | Selected destination is restored |
| Navigation | Background then return | No duplicate fragment or crash |
| RAM | Device reports zero/unknown values | UI shows safe fallback |
| RAM | Low-memory flag is set | Status is informational; no false cleanup claim |
| Storage | Storage stat unavailable | UI shows unavailable state |
| Storage | Provider returns null display name | Generic safe label is used |
| Storage | File disappears before delete | Operation reports failure and continues safely |
| Storage | Permission revoked | User receives actionable explanation |
| Battery | Battery intent unavailable | Battery fields show unavailable |
| Battery | Temperature unavailable | No fabricated temperature |
| Settings | Target screen missing on OEM build | Friendly fallback message |
| Permissions | User denies access | App remains usable where possible |
| Lifecycle | Leave screen during work | Work is cancelled or safely detached |
| Privacy | Inspect logs | No file contents or credentials logged |
| Release | Install signed APK | App launches and core flows work |
| Permissões | Primeira abertura | Aviso explicativo aparece uma única vez; depois só o card da Início |
| Permissões | Conceder uma a uma (notificações, arquivos, sobrepor) | Cada tela do sistema abre em sequência e o card mostra ✔ |
| Janelinha | Ligar/desligar pela Início e pela notificação | Aparece sobre outros apps; arrastar move; toque alterna compacto |
| Janelinha | Reiniciar o celular sem iniciar o Shizuku | Rótulo "TELA" + motivo na linha pequena |
| FPS real | Shizuku autorizado + jogo aberto | Rótulo "FPS", app e fonte (SF/TS/GFX) na linha pequena |
| FPS real | Diagnóstico FPS (10s) | Texto com app em foco, camadas e FPS lido |
| RAM Booster | Otimizar com e sem modo profundo | Relatório antes/depois; apps protegidos não são encerrados |
| Apps protegidos | Marcar apps e otimizar | Apps marcados continuam abertos |
| Armazenamento | Analisar todo o armazenamento | Lista dos maiores arquivos; excluir pede confirmação |
| Limpeza | Limpar temporários | Só .tmp/.temp/.log/.cache/miniaturas antigos; confirmação antes de apagar |
| Modo Jogo | Tocar uma vez | RAM liberada + janelinha ligada (se permitido) |

## Manual test record

Record device model, Android version, build variant, APK version, test date,
and pass/fail notes for each row before publishing a release.
