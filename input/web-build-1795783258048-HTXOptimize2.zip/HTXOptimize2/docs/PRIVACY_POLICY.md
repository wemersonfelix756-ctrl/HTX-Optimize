# Política de Privacidade — HTX Optimize

**Última atualização:** (preencha a data de publicação)

O HTX Optimize funciona inteiramente no seu aparelho. **O aplicativo não coleta, não armazena em servidores e não compartilha dados pessoais**, e não contém anúncios nem ferramentas de análise de terceiros.

## O que o aplicativo acessa e por quê
| Recurso | Para que serve |
|---|---|
| Acesso a todos os arquivos | Gerenciador de arquivos, "Maiores arquivos" e limpeza de temporários. Nada é apagado sem a sua confirmação. |
| Lista de aplicativos instalados | Escolher "Apps protegidos" e encerrar processos em segundo plano na otimização de RAM. |
| Sobrepor outros aplicativos | Exibir a janelinha de FPS, temperatura e RAM. |
| Notificações | Mostrar a notificação obrigatória do serviço da janelinha. |
| Instalar pacotes | Abrir o instalador do Android para APKs escolhidos por você no gerenciador. |
| Shizuku (opcional) | Se você o autorizar: medir o FPS real, executar comandos no Terminal e usar o modo profundo. Os comandos rodam localmente. |

## Dados e armazenamento
- Preferências (tema, opções da janelinha, favoritos, histórico e comandos salvos do Terminal) ficam **somente no aparelho**.
- O app não usa conexão com a internet para funcionar.
- Desinstalar o aplicativo apaga esses dados.

## Seus direitos e contato
Como não coletamos dados pessoais, não há dados para exportar ou excluir fora do seu aparelho.
Dúvidas: (preencha seu e-mail de contato).
