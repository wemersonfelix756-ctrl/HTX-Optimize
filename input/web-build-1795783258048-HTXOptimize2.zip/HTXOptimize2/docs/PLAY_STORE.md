# Publicação na Google Play — guia e checklist

> Este projeto está **preparado** para publicação (build AAB, assinatura por secrets, política de privacidade, textos). A **aprovação depende da análise do Google** e nenhuma revisão pode ser garantida. Preencha os campos marcados com (preencha).

## 1. Conta e identidade
- Conta de desenvolvedor Google Play (taxa única) e, para app **pago**, perfil de pagamentos/merchant configurado no Play Console.
- Defina o preço no Play Console (app pago = compra única; não há código de cobrança no app).
- `applicationId`: `com.htx.optimize` (não pode mudar depois de publicar).

## 2. Assinatura e build
1. Gere uma chave de upload: `keytool -genkeypair -v -keystore htx-upload.jks -alias htx -keyalg RSA -keysize 2048 -validity 10000`
2. Guarde o `.jks` e as senhas em local seguro (perder a chave dificulta atualizações).
3. No GitHub, crie os secrets: `HTX_KEYSTORE_BASE64` (`base64 -w0 htx-upload.jks`), `HTX_KEYSTORE_PASSWORD`, `HTX_KEY_ALIAS`, `HTX_KEY_PASSWORD`.
4. O workflow gera `app-release.aab` — é o arquivo que você envia ao Play Console. Ative o **Play App Signing**.
5. Aumente `versionCode` a cada envio (em `app/build.gradle`).

## 3. Permissões restritas — o que o Google vai pedir para você justificar
| Permissão | Justificativa sugerida | Risco |
|---|---|---|
| `MANAGE_EXTERNAL_STORAGE` | A função principal é um gerenciador de arquivos (navegar, copiar, mover, compactar e extrair em todo o armazenamento). | Médio: aceito para gerenciadores de arquivos; exige o formulário de declaração. |
| `QUERY_ALL_PACKAGES` | Listar apps para "Apps protegidos" e encerrar processos na otimização de RAM. | **Alto**: a política restringe o uso; se for negada, remova a permissão e o app listará só apps com `<queries>` declaradas. |
| `REQUEST_INSTALL_PACKAGES` | Abrir o instalador para APKs que o usuário seleciona no gerenciador. | Médio/alto: se negada, remova a permissão e o item "Instalar". |
| `SYSTEM_ALERT_WINDOW` | Janelinha flutuante de FPS/CPU/RAM escolhida pelo usuário. | Baixo/médio. |
| `FOREGROUND_SERVICE_SPECIAL_USE` | Serviço que mantém a janelinha visível (subtipo declarado no manifesto). | Médio: o Console pede descrição. |
| `KILL_BACKGROUND_PROCESSES` | Otimização de RAM. | Baixo. |

## 4. Pontos de política a observar
- **Alegações honestas:** não prometa "acelerar o celular" nem "aumentar a RAM". O texto da loja deve dizer o que o app faz: encerra apps em segundo plano, limpa temporários, mede FPS, gerencia arquivos.
- **Terminal/Shizuku:** o app só executa comandos digitados pelo usuário, com confirmação para comandos perigosos. Descreva isso na declaração de funcionalidade.
- **Formulário de Segurança dos Dados:** "Não coleta dados" e "Não compartilha dados" (confirme que nenhuma biblioteca de terceiros foi adicionada).
- **Classificação de conteúdo:** questionário do Console (sem conteúdo sensível).
- **Política de privacidade:** hospede `docs/PRIVACY_POLICY.md` numa URL pública e informe no Console.
- **targetSdk:** o projeto usa 35; mantenha-o atualizado conforme o prazo anual do Google.

## 5. Ficha da loja (sugestão)
**Título (30):** HTX Optimize: FPS e Arquivos

**Descrição curta (80):** Medidor de FPS, gerenciador de arquivos, terminal e otimização de memória.

**Descrição completa:**
O HTX Optimize reúne, em um só app, as ferramentas que você usa para cuidar do celular:
• Início: nota de saúde do aparelho e medidores de RAM, armazenamento, bateria e temperatura.
• Otimização: libera memória encerrando apps em segundo plano, limpa arquivos temporários e protege os apps que você escolher. Modo Jogo em um toque.
• Monitor: janelinha flutuante com FPS, temperatura da CPU e RAM. Com o Shizuku, mede o FPS real do app em foco, com média e 1% low.
• Arquivos: gerenciador completo — copiar, mover, renomear, compartilhar, buscar, maiores arquivos e miniaturas. Compacta e extrai ZIP, 7Z, TAR, TAR.GZ, GZ e extrai RAR, com navegação dentro dos arquivos compactados.
• Terminal: execute comandos sh (com Shizuku, como usuário shell), com histórico, comandos salvos e atalhos.
• Temas Aurora, AMOLED e Claro. Sem anúncios. Sem coleta de dados.
Algumas funções exigem permissões que você concede por escolha e o Shizuku (opcional).

**Capturas de tela necessárias:** pelo menos 2 (recomendado 4–8) de celular: Início, Monitor com a janelinha, Arquivos com o menu de ações, Terminal. Gráfico de recursos 1024×500 e ícone 512×512.

## 6. Antes de enviar
- [ ] Testar em pelo menos 2 aparelhos/versões do Android (veja `docs/QA_MATRIX.md`).
- [ ] Testar a instalação do `.aab` pela faixa de teste interno.
- [ ] Preencher a URL da política de privacidade e o e-mail de contato.
- [ ] Revisar os textos da loja contra a seção 4.
