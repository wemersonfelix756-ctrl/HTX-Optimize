package com.htx.optimize.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.Nullable;
import com.htx.optimize.R;

/** Medidor circular limpo: número grande no centro, rótulo abaixo e arco com degradê. */
public class ArcGaugeView extends View {

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint numberPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arcRect = new RectF();
    private final Matrix gradientMatrix = new Matrix();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private float current;
    private float target;
    private String label = "";
    private int band = -1;
    private int colorA, colorB, warn, bad, accent, accent2;

    private final Runnable step = new Runnable() {
        @Override public void run() {
            float diff = target - current;
            if (Math.abs(diff) < 0.6f) {
                current = target;
                invalidate();
                return;
            }
            current += diff * 0.2f;
            invalidate();
            handler.postDelayed(this, 16L);
        }
    };

    public ArcGaugeView(Context context) { super(context); init(context); }

    public ArcGaugeView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        accent = ThemeColors.get(context, R.attr.htxAccent);
        accent2 = ThemeColors.get(context, R.attr.htxAccent2);
        warn = ThemeColors.get(context, R.attr.htxWarn);
        bad = ThemeColors.get(context, R.attr.htxBad);
        float stroke = dp(12f);

        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setStrokeWidth(stroke);
        trackPaint.setStrokeCap(Paint.Cap.ROUND);
        trackPaint.setColor(ThemeColors.get(context, R.attr.htxSurfaceHigh));

        progressPaint.setStyle(Paint.Style.STROKE);
        progressPaint.setStrokeWidth(stroke);
        progressPaint.setStrokeCap(Paint.Cap.ROUND);

        numberPaint.setColor(ThemeColors.get(context, R.attr.htxText));
        numberPaint.setTextSize(sp(46f));
        numberPaint.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        numberPaint.setTextAlign(Paint.Align.CENTER);

        labelPaint.setColor(ThemeColors.get(context, R.attr.htxTextDim));
        labelPaint.setTextSize(sp(11f));
        labelPaint.setLetterSpacing(0.14f);
        labelPaint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        labelPaint.setTextAlign(Paint.Align.CENTER);
        applyBand(0);
    }

    public void setProgressAnimated(int percent, String text) {
        label = text == null ? "" : text;
        target = Math.max(0f, Math.min(100f, percent));
        applyBand(Math.round(target));
        handler.removeCallbacks(step);
        handler.post(step);
    }

    private void applyBand(int value) {
        int newBand = value >= 65 ? 0 : value >= 40 ? 1 : 2;
        if (newBand == band) return;
        band = newBand;
        colorA = newBand == 0 ? accent : newBand == 1 ? warn : bad;
        colorB = newBand == 0 ? accent2 : newBand == 1 ? 0xFFF59E0B : 0xFFEF4444;
        rebuildShader();
    }

    private void rebuildShader() {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;
        SweepGradient gradient = new SweepGradient(w / 2f, h / 2f,
                new int[]{colorA, colorB, colorB}, new float[]{0f, 0.75f, 1f});
        gradientMatrix.setRotate(135f, w / 2f, h / 2f);
        gradient.setLocalMatrix(gradientMatrix);
        progressPaint.setShader(gradient);
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        rebuildShader();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        handler.removeCallbacksAndMessages(null);
    }

    @Override protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;
        float inset = dp(14f);
        float size = Math.min(w, h) - inset * 2f;
        float left = (w - size) / 2f;
        float top = (h - size) / 2f;
        arcRect.set(left, top, left + size, top + size);

        canvas.drawArc(arcRect, 135f, 270f, false, trackPaint);
        float sweep = 270f * (current / 100f);
        if (sweep > 0.5f) canvas.drawArc(arcRect, 135f, sweep, false, progressPaint);

        float cx = w / 2f;
        float cy = h / 2f;
        canvas.drawText(String.valueOf(Math.round(current)), cx, cy + dp(10f), numberPaint);
        canvas.drawText(label.toUpperCase(), cx, cy + dp(34f), labelPaint);
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }

    private float sp(float v) { return v * getResources().getDisplayMetrics().scaledDensity; }
}
