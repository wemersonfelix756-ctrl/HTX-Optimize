package com.htx.optimize.fragments;

import androidx.appcompat.app.AlertDialog;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.htx.optimize.MainActivity;
import com.htx.optimize.R;
import com.htx.optimize.monitor.HealthScore;
import com.htx.optimize.monitor.SystemMonitor;
import com.htx.optimize.monitor.ThermalReader;
import com.htx.optimize.optimizer.JunkCleaner;
import com.htx.optimize.optimizer.RamOptimizer;
import com.htx.optimize.overlay.OverlayService;
import com.htx.optimize.shizuku.ShizukuBridge;
import com.htx.optimize.ui.ArcGaugeView;
import com.htx.optimize.ui.UiAnim;
import com.htx.optimize.util.AppPrefs;
import com.htx.optimize.util.FormatUtils;
import com.htx.optimize.util.PermissionHelper;
import com.htx.optimize.util.ProtectedApps;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Início: saúde do aparelho, medidores ao vivo e todas as ações de otimização. */
public class HomeFragment extends Fragment {

    private static final long REFRESH_MS = 2500L;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Runnable loop = new Runnable() {
        @Override public void run() {
            refresh();
            main.postDelayed(this, REFRESH_MS);
        }
    };

    private ArcGaugeView gauge;
    private TextView tvHint, tvDevice, tvPerm, tvReport;
    private TextView tvRamValue, tvRamSub, tvStorageValue, tvStorageSub, tvBatteryValue, tvBatterySub, tvCpuValue, tvCpuSub;
    private ProgressBar pRam, pStorage, pBattery, pCpu, pOpt;
    private View cardPerm;
    private Button btnOptimize, btnGame, btnJunk, btnProtected;
    private boolean busy;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        super.onViewCreated(view, state);
        gauge = view.findViewById(R.id.gauge_health);
        tvHint = view.findViewById(R.id.tv_health_hint);
        tvDevice = view.findViewById(R.id.tv_device_line);
        tvPerm = view.findViewById(R.id.tv_perm_status);
        tvReport = view.findViewById(R.id.tv_opt_report);
        tvRamValue = view.findViewById(R.id.tv_ram_value);
        tvRamSub = view.findViewById(R.id.tv_ram_sub);
        tvStorageValue = view.findViewById(R.id.tv_storage_value);
        tvStorageSub = view.findViewById(R.id.tv_storage_sub);
        tvBatteryValue = view.findViewById(R.id.tv_battery_value);
        tvBatterySub = view.findViewById(R.id.tv_battery_sub);
        tvCpuValue = view.findViewById(R.id.tv_cpu_value);
        tvCpuSub = view.findViewById(R.id.tv_cpu_sub);
        pRam = view.findViewById(R.id.progress_ram);
        pStorage = view.findViewById(R.id.progress_storage);
        pBattery = view.findViewById(R.id.progress_battery);
        pCpu = view.findViewById(R.id.progress_cpu);
        pOpt = view.findViewById(R.id.progress_opt);
        cardPerm = view.findViewById(R.id.card_perm);
        btnOptimize = view.findViewById(R.id.btn_optimize);
        btnGame = view.findViewById(R.id.btn_game);
        btnJunk = view.findViewById(R.id.btn_junk);
        btnProtected = view.findViewById(R.id.btn_protected);

        view.findViewById(R.id.btn_grant).setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).startPermissionFlow();
        });
        btnOptimize.setOnClickListener(v -> runBoost(false));
        btnGame.setOnClickListener(v -> runBoost(true));
        btnJunk.setOnClickListener(v -> scanJunk());
        btnProtected.setOnClickListener(v -> showProtectedApps());

        SwitchCompat deep = view.findViewById(R.id.sw_deep);
        deep.setChecked(AppPrefs.deepBoost(requireContext()));
        deep.setOnCheckedChangeListener((b, checked) -> {
            AppPrefs.setDeepBoost(requireContext(), checked);
            if (checked && ShizukuBridge.state(requireContext()) != ShizukuBridge.State.READY) {
                toast("O modo profundo precisa do Shizuku autorizado (aba Monitor).");
            }
        });
        UiAnim.revealChildren(view);
    }

    @Override public void onResume() {
        super.onResume();
        main.removeCallbacks(loop);
        main.post(loop);
    }

    @Override public void onPause() {
        main.removeCallbacks(loop);
        super.onPause();
    }

    @Override public void onDestroyView() {
        main.removeCallbacksAndMessages(null);
        gauge = null; tvHint = null; tvDevice = null; tvPerm = null; tvReport = null;
        tvRamValue = null; tvRamSub = null; tvStorageValue = null; tvStorageSub = null;
        tvBatteryValue = null; tvBatterySub = null; tvCpuValue = null; tvCpuSub = null;
        pRam = null; pStorage = null; pBattery = null; pCpu = null; pOpt = null;
        cardPerm = null; btnOptimize = null; btnGame = null; btnJunk = null; btnProtected = null;
        super.onDestroyView();
    }

    @Override public void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ medidores

    private void refresh() {
        if (!isAdded() || worker.isShutdown()) return;
        final Context app = requireContext().getApplicationContext();
        updatePermissions(app);
        worker.execute(() -> {
            final SystemMonitor.RamSnapshot ram = SystemMonitor.readRam(app);
            final SystemMonitor.StorageSnapshot storage = SystemMonitor.readInternalStorage();
            final SystemMonitor.BatterySnapshot battery = SystemMonitor.readBattery(app);
            final ThermalReader.Reading cpu = ThermalReader.read(app);
            StringBuilder device = new StringBuilder(SystemMonitor.getDeviceModel())
                    .append(" • ").append(SystemMonitor.getAndroidVersionSummary());
            if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL != null && !Build.SOC_MODEL.isEmpty()
                    && !Build.SOC_MODEL.equalsIgnoreCase("unknown")) {
                device.append(" • ").append(Build.SOC_MODEL);
            }
            device.append(" • ").append(Runtime.getRuntime().availableProcessors()).append(" núcleos");
            final String deviceLine = device.toString();
            main.post(() -> render(ram, storage, battery, cpu, deviceLine));
        });
    }

    private void render(SystemMonitor.RamSnapshot ram, SystemMonitor.StorageSnapshot storage,
                        SystemMonitor.BatterySnapshot battery, ThermalReader.Reading cpu, String deviceLine) {
        if (!isAdded() || getView() == null || gauge == null) return;
        tvRamValue.setText(ram.usedPercent + "%");
        tvRamSub.setText(FormatUtils.formatBytes(ram.usedBytes) + " de " + FormatUtils.formatBytes(ram.totalBytes));
        pRam.setProgress(ram.usedPercent);

        tvStorageValue.setText(storage.usedPercent + "%");
        tvStorageSub.setText("livre " + FormatUtils.formatBytes(storage.freeBytes));
        pStorage.setProgress(storage.usedPercent);

        tvBatteryValue.setText(battery.levelPercent + "%");
        tvBatterySub.setText(battery.statusText);
        pBattery.setProgress(Math.max(0, Math.min(100, battery.levelPercent)));

        float temp = !Float.isNaN(cpu.celsius) ? cpu.celsius
                : battery.temperatureCelsius != null ? battery.temperatureCelsius : Float.NaN;
        if (Float.isNaN(temp)) {
            tvCpuValue.setText("—");
            tvCpuSub.setText("sem sensor");
            pCpu.setProgress(0);
        } else {
            tvCpuValue.setText(String.format(Locale.US, "%.0f°C", temp));
            tvCpuSub.setText(cpu.fromCpu ? "sensor da CPU" : "sensor da bateria");
            pCpu.setProgress(Math.max(0, Math.min(100, Math.round((temp - 20f) / 60f * 100f))));
        }

        HealthScore.Result health = HealthScore.compute(ram.usedPercent, storage.usedPercent, temp,
                battery.levelPercent, ram.lowMemory);
        gauge.setProgressAnimated(health.score, health.label);
        tvHint.setText(health.hint);
        tvDevice.setText(deviceLine);
    }

    private void updatePermissions(Context app) {
        if (cardPerm == null) return;
        StringBuilder missing = new StringBuilder();
        if (!PermissionHelper.hasStorage(app)) missing.append("Arquivos");
        if (!PermissionHelper.hasOverlay(app)) missing.append(missing.length() > 0 ? " • " : "").append("Sobrepor apps");
        if (!PermissionHelper.hasNotifications(app)) missing.append(missing.length() > 0 ? " • " : "").append("Notificações");
        cardPerm.setVisibility(missing.length() == 0 ? View.GONE : View.VISIBLE);
        if (tvPerm != null) tvPerm.setText(missing);
    }

    // ------------------------------------------------------------------ otimização

    private void setBusy(boolean value, @Nullable String message) {
        busy = value;
        if (btnOptimize != null) btnOptimize.setEnabled(!value);
        if (btnGame != null) btnGame.setEnabled(!value);
        if (btnJunk != null) btnJunk.setEnabled(!value);
        if (btnProtected != null) btnProtected.setEnabled(!value);
        if (pOpt != null) pOpt.setVisibility(value ? View.VISIBLE : View.GONE);
        if (message != null && tvReport != null) tvReport.setText(message);
    }

    private void runBoost(final boolean gameMode) {
        if (!isAdded() || busy || worker.isShutdown()) return;
        setBusy(true, gameMode ? "Preparando o Modo Jogo…" : "Otimizando… encerrando apps em segundo plano.");
        final Context app = requireContext().getApplicationContext();
        worker.execute(() -> {
            boolean deep = AppPrefs.deepBoost(app) && ShizukuBridge.awaitConnected(app, 2500L);
            final RamOptimizer.Result r = RamOptimizer.run(app, deep ? ShizukuBridge::exec : null);
            final boolean deepUsed = deep;
            main.post(() -> {
                if (!isAdded() || getView() == null) return;
                setBusy(false, null);
                boolean overlayOk = PermissionHelper.hasOverlay(app);
                if (gameMode && overlayOk && !OverlayService.isRunning()) {
                    ContextCompat.startForegroundService(app,
                            new Intent(app, OverlayService.class).setAction(OverlayService.ACTION_START));
                }
                long delta = r.deltaBytes();
                StringBuilder report = new StringBuilder(gameMode ? "Modo Jogo ativo.\n" : "Otimização concluída.\n");
                report.append(delta > 0 ? "+" + FormatUtils.formatBytes(delta) + " de RAM livre"
                        : "A RAM já estava otimizada");
                report.append(" • ").append(r.requested).append(" app(s) encerrado(s)");
                if (deepUsed) report.append(" (profundo)");
                if (r.cacheFreed > 0) report.append(" • cache ").append(FormatUtils.formatBytes(r.cacheFreed));
                if (gameMode) {
                    report.append(overlayOk ? "\nJanelinha de FPS ligada." : "\nConceda “Sobrepor apps” para ligar a janelinha.");
                }
                if (tvReport != null) tvReport.setText(report);
                if (gameMode && !overlayOk && getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).startPermissionFlow();
                }
                refresh();
            });
        });
    }

    private void scanJunk() {
        if (!isAdded() || busy || worker.isShutdown()) return;
        if (!PermissionHelper.hasStorage(requireContext())) {
            toast("Conceda o acesso aos arquivos primeiro.");
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).startPermissionFlow();
            return;
        }
        setBusy(true, "Procurando arquivos temporários…");
        worker.execute(() -> {
            final JunkCleaner.Scan scan = JunkCleaner.scan();
            main.post(() -> {
                if (!isAdded() || getView() == null) return;
                setBusy(false, null);
                if (scan.files.isEmpty()) {
                    if (tvReport != null) tvReport.setText("Nenhum arquivo temporário encontrado.");
                    return;
                }
                final String size = FormatUtils.formatBytes(scan.bytes);
                if (tvReport != null) tvReport.setText(scan.files.size() + " arquivo(s) temporário(s): " + size);
                new MaterialAlertDialogBuilder(requireContext())
                        .setTitle("Limpar temporários")
                        .setMessage("Excluir " + scan.files.size() + " arquivo(s) (.tmp, .log, .cache, miniaturas) e liberar " + size + "?")
                        .setNegativeButton("Cancelar", null)
                        .setPositiveButton("Excluir", (d, w) -> deleteJunk(scan))
                        .show();
            });
        });
    }

    private void deleteJunk(final JunkCleaner.Scan scan) {
        if (!isAdded() || worker.isShutdown()) return;
        setBusy(true, "Excluindo…");
        worker.execute(() -> {
            final long freed = JunkCleaner.delete(scan.files);
            main.post(() -> {
                if (!isAdded() || getView() == null) return;
                setBusy(false, "Limpeza concluída: " + FormatUtils.formatBytes(freed) + " liberados.");
                refresh();
            });
        });
    }

    private void showProtectedApps() {
        if (!isAdded() || worker.isShutdown()) return;
        final Context app = requireContext().getApplicationContext();
        worker.execute(() -> {
            final List<ProtectedApps.Entry> apps = ProtectedApps.launchableApps(app);
            final Set<String> saved = ProtectedApps.get(app);
            main.post(() -> {
                if (!isAdded() || getView() == null) return;
                if (apps.isEmpty()) {
                    toast("Nenhum app encontrado.");
                    return;
                }
                final CharSequence[] labels = new CharSequence[apps.size()];
                final boolean[] checked = new boolean[apps.size()];
                for (int i = 0; i < apps.size(); i++) {
                    labels[i] = apps.get(i).label;
                    checked[i] = saved.contains(apps.get(i).pkg);
                }
                new MaterialAlertDialogBuilder(requireContext())
                        .setTitle("Apps protegidos (nunca encerrar)")
                        .setMultiChoiceItems(labels, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                        .setNegativeButton("Cancelar", null)
                        .setPositiveButton("Salvar", (dialog, which) -> {
                            Set<String> chosen = new HashSet<>();
                            for (int i = 0; i < apps.size(); i++) if (checked[i]) chosen.add(apps.get(i).pkg);
                            ProtectedApps.set(app, chosen);
                            Toast.makeText(app, chosen.size() + " app(s) protegido(s).", Toast.LENGTH_SHORT).show();
                        })
                        .show();
            });
        });
    }

    private void toast(String message) {
        if (isAdded()) Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show();
    }
}
