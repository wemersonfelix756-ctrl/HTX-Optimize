package com.htx.optimize.files;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.htx.optimize.R;
import com.htx.optimize.ui.ThemeColors;
import java.util.List;

/** Menu de ações de um item (aparece ao segurar), no estilo de folha inferior do ZArchiver. */
public final class FileActionSheet {

    public static final class Action {
        final int icon;
        final String label;
        final Runnable run;
        final boolean danger;

        public Action(int icon, String label, Runnable run) { this(icon, label, run, false); }

        public Action(int icon, String label, Runnable run, boolean danger) {
            this.icon = icon;
            this.label = label;
            this.run = run;
            this.danger = danger;
        }
    }

    private FileActionSheet() { }

    private static int dp(Context c, int v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    public static void show(Context ctx, String title, String subtitle, int headerIcon, int headerColor, List<Action> actions) {
        final BottomSheetDialog dialog = new BottomSheetDialog(ctx);
        int text = ThemeColors.get(ctx, R.attr.htxText);
        int faint = ThemeColors.get(ctx, R.attr.htxTextFaint);
        int bad = ThemeColors.get(ctx, R.attr.htxBad);
        int outline = ThemeColors.get(ctx, R.attr.htxOutline);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout header = new LinearLayout(ctx);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(ctx, 22), dp(ctx, 20), dp(ctx, 22), dp(ctx, 14));

        FrameLayout badge = new FrameLayout(ctx);
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setCornerRadius(dp(ctx, 14));
        badgeBg.setColor((headerColor & 0x00FFFFFF) | 0x2E000000);
        badge.setBackground(badgeBg);
        ImageView icon = new ImageView(ctx);
        icon.setImageResource(headerIcon);
        icon.setColorFilter(headerColor, PorterDuff.Mode.SRC_IN);
        badge.addView(icon, new FrameLayout.LayoutParams(dp(ctx, 26), dp(ctx, 26), Gravity.CENTER));
        header.addView(badge, new LinearLayout.LayoutParams(dp(ctx, 48), dp(ctx, 48)));

        LinearLayout texts = new LinearLayout(ctx);
        texts.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textsLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        textsLp.setMarginStart(dp(ctx, 14));
        TextView tvTitle = new TextView(ctx);
        tvTitle.setText(title);
        tvTitle.setTextColor(text);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f);
        tvTitle.setSingleLine(true);
        tvTitle.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        tvTitle.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
        TextView tvSub = new TextView(ctx);
        tvSub.setText(subtitle);
        tvSub.setTextColor(faint);
        tvSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        tvSub.setSingleLine(true);
        texts.addView(tvTitle);
        texts.addView(tvSub);
        header.addView(texts, textsLp);
        root.addView(header);

        View line = new View(ctx);
        line.setBackgroundColor(outline);
        root.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 1)));

        TypedValue ripple = new TypedValue();
        ctx.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, ripple, true);

        LinearLayout list = new LinearLayout(ctx);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, dp(ctx, 6), 0, dp(ctx, 14));
        for (final Action action : actions) {
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setMinimumHeight(dp(ctx, 54));
            row.setPadding(dp(ctx, 24), 0, dp(ctx, 24), 0);
            row.setBackgroundResource(ripple.resourceId);
            ImageView ic = new ImageView(ctx);
            ic.setImageResource(action.icon);
            ic.setColorFilter(action.danger ? bad : ThemeColors.get(ctx, R.attr.htxTextDim), PorterDuff.Mode.SRC_IN);
            row.addView(ic, new LinearLayout.LayoutParams(dp(ctx, 22), dp(ctx, 22)));
            TextView label = new TextView(ctx);
            label.setText(action.label);
            label.setTextColor(action.danger ? bad : text);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f);
            LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            labelLp.setMarginStart(dp(ctx, 20));
            row.addView(label, labelLp);
            row.setOnClickListener(v -> {
                dialog.dismiss();
                action.run.run();
            });
            list.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        ScrollView scroll = new ScrollView(ctx);
        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        dialog.setContentView(root);
        dialog.setOnShowListener(d -> {
            View sheet = dialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
            if (sheet != null) BottomSheetBehavior.from(sheet).setState(BottomSheetBehavior.STATE_EXPANDED);
        });
        dialog.show();
    }
}
