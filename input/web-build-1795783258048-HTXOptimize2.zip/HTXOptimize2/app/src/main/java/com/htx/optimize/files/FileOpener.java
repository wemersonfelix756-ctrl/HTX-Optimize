package com.htx.optimize.files;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.MimeTypeMap;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Abrir e compartilhar arquivos com outros apps (via FileProvider). */
public final class FileOpener {

    private FileOpener() { }

    public static Uri uriFor(Context context, File file) {
        return FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", file);
    }

    public static String mimeOf(File file) {
        String ext = FileKind.extensionOf(file.getName());
        String mime = ext.isEmpty() ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return mime != null ? mime : "*/*";
    }

    public static void open(Context context, File file) {
        try {
            String mime = file.getName().toLowerCase().endsWith(".apk")
                    ? "application/vnd.android.package-archive" : mimeOf(file);
            if ("application/vnd.android.package-archive".equals(mime) && Build.VERSION.SDK_INT >= 26
                    && !context.getPackageManager().canRequestPackageInstalls()) {
                Toast.makeText(context, "Permita instalar apps desconhecidos para o HTX Optimize.", Toast.LENGTH_LONG).show();
                context.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + context.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                return;
            }
            Intent intent = new Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uriFor(context, file), mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (ActivityNotFoundException exception) {
            Toast.makeText(context, "Nenhum app encontrado para abrir este arquivo.", Toast.LENGTH_LONG).show();
        } catch (RuntimeException exception) {
            Toast.makeText(context, "Não foi possível abrir: " + exception.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /** Escolher o app para abrir (equivale a "Abrir com…"). */
    public static void openWith(Context context, File file) {
        try {
            Intent view = new Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uriFor(context, file), mimeOf(file))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            context.startActivity(Intent.createChooser(view, "Abrir com").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (RuntimeException exception) {
            Toast.makeText(context, "Nenhum app encontrado para abrir este arquivo.", Toast.LENGTH_LONG).show();
        }
    }

    public static void share(Context context, List<File> files) {
        try {
            ArrayList<Uri> uris = new ArrayList<>();
            for (File file : files) if (file.isFile()) uris.add(uriFor(context, file));
            if (uris.isEmpty()) {
                Toast.makeText(context, "Só é possível compartilhar arquivos (não pastas).", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(uris.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE).setType("*/*");
            if (uris.size() == 1) intent.putExtra(Intent.EXTRA_STREAM, uris.get(0));
            else intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            context.startActivity(Intent.createChooser(intent, "Compartilhar").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (RuntimeException exception) {
            Toast.makeText(context, "Não foi possível compartilhar: " + exception.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
