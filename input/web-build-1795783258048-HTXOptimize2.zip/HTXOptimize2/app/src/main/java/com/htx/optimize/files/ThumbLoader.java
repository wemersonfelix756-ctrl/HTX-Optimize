package com.htx.optimize.files;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.media.ThumbnailUtils;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Miniaturas de imagens e ícones de APK, carregadas em segundo plano com cache em memória. */
public final class ThumbLoader {

    public interface Callback {
        void onBitmap(Bitmap bitmap);
    }

    private static final LruCache<String, Bitmap> CACHE =
            new LruCache<String, Bitmap>((int) Math.max(2048L, Runtime.getRuntime().maxMemory() / 1024L / 12L)) {
                @Override protected int sizeOf(String key, Bitmap value) { return value.getByteCount() / 1024; }
            };
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private ThumbLoader() { }

    private static String key(File f) {
        return f.getAbsolutePath() + "|" + f.lastModified() + "|" + f.length();
    }

    public static Bitmap cached(File file) { return CACHE.get(key(file)); }

    public static void load(final Context context, final File file, final boolean apk, final int sizePx, final Callback callback) {
        final Context app = context.getApplicationContext();
        POOL.execute(() -> {
            Bitmap bitmap = null;
            try {
                bitmap = apk ? apkIcon(app, file, sizePx) : image(file, sizePx);
            } catch (RuntimeException | OutOfMemoryError ignored) {
                // sem miniatura
            }
            if (bitmap == null) return;
            CACHE.put(key(file), bitmap);
            final Bitmap result = bitmap;
            MAIN.post(() -> callback.onBitmap(result));
        });
    }

    private static Bitmap image(File file, int size) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
        int sample = 1;
        while (bounds.outWidth / (sample * 2) >= size && bounds.outHeight / (sample * 2) >= size) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        Bitmap full = BitmapFactory.decodeFile(file.getAbsolutePath(), opts);
        if (full == null) return null;
        Bitmap thumb = ThumbnailUtils.extractThumbnail(full, size, size);
        if (thumb != full) full.recycle();
        return thumb;
    }

    private static Bitmap apkIcon(Context context, File file, int size) {
        PackageManager pm = context.getPackageManager();
        PackageInfo info = pm.getPackageArchiveInfo(file.getAbsolutePath(), 0);
        if (info == null || info.applicationInfo == null) return null;
        ApplicationInfo ai = info.applicationInfo;
        ai.sourceDir = file.getAbsolutePath();
        ai.publicSourceDir = file.getAbsolutePath();
        Drawable icon = ai.loadIcon(pm);
        if (icon == null) return null;
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        icon.setBounds(0, 0, size, size);
        icon.draw(canvas);
        return bitmap;
    }
}
