package com.htx.optimize.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.util.TypedValue;
import androidx.annotation.AttrRes;
import androidx.annotation.StyleRes;
import com.htx.optimize.R;

/** Acesso às cores do tema atual (Aurora, AMOLED ou Claro) e escolha do tema. */
public final class ThemeColors {

    public static final String[] THEME_NAMES = {"Aurora", "AMOLED", "Claro"};

    private ThemeColors() { }

    public static int get(Context context, @AttrRes int attr) {
        TypedValue value = new TypedValue();
        context.getTheme().resolveAttribute(attr, value, true);
        return value.data;
    }

    @StyleRes
    public static int themeRes(int index) {
        switch (index) {
            case 1: return R.style.Theme_HTXOptimize_Amoled;
            case 2: return R.style.Theme_HTXOptimize_Light;
            default: return R.style.Theme_HTXOptimize;
        }
    }

    /** Cor do ícone/rótulo da barra de baixo: ativo = destaque, inativo = texto apagado. */
    public static ColorStateList navTint(Context context) {
        return new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{get(context, R.attr.htxAccent), get(context, R.attr.htxTextFaint)});
    }
}
