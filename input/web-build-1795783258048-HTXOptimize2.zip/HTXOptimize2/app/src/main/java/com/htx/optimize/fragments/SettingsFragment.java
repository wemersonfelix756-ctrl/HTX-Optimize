package com.htx.optimize.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.htx.optimize.R;
import com.htx.optimize.ui.UiAnim;
import com.htx.optimize.util.AppPrefs;

/** Ajustes: tema do aplicativo, versão, avaliação/compartilhamento e privacidade. */
public class SettingsFragment extends Fragment {

    private final Button[] themeButtons = new Button[3];

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        super.onViewCreated(view, state);
        final Context ctx = requireContext();

        int[] ids = {R.id.btn_theme_0, R.id.btn_theme_1, R.id.btn_theme_2};
        int current = AppPrefs.theme(ctx);
        for (int i = 0; i < ids.length; i++) {
            final int index = i;
            themeButtons[i] = view.findViewById(ids[i]);
            themeButtons[i].setBackgroundResource(i == current ? R.drawable.bg_btn_primary : R.drawable.bg_btn_tonal);
            themeButtons[i].setOnClickListener(v -> {
                if (AppPrefs.theme(ctx) == index) return;
                AppPrefs.setTheme(ctx, index);
                requireActivity().recreate();
            });
        }

        TextView version = view.findViewById(R.id.tv_settings_version);
        String name = "?";
        try {
            PackageInfo info = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0);
            if (info.versionName != null) name = info.versionName;
        } catch (Exception ignored) {
            // mantém "?"
        }
        version.setText("HTX Optimize " + name);
        ((TextView) view.findViewById(R.id.tv_settings_dev)).setText(
                "Desenvolvido por " + getString(R.string.dev_name) + " — " + getString(R.string.dev_specialty));

        view.findViewById(R.id.btn_rate).setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + ctx.getPackageName())));
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://play.google.com/store/apps/details?id=" + ctx.getPackageName())));
                } catch (Exception ignored) {
                    Toast.makeText(ctx, "Não foi possível abrir a Play Store.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        view.findViewById(R.id.btn_share_app).setOnClickListener(v -> {
            Intent send = new Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, "Conheça o HTX Optimize: https://play.google.com/store/apps/details?id=" + ctx.getPackageName());
            startActivity(Intent.createChooser(send, "Compartilhar"));
        });
        UiAnim.revealChildren(view);
    }
}
