package com.htx.optimize.files;

import android.graphics.Bitmap;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.drawable.GradientDrawable;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.htx.optimize.R;
import com.htx.optimize.util.FormatUtils;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/** Lista de arquivos no estilo ZArchiver: ícone colorido, nome, data/tamanho e seleção múltipla. */
public class FileListAdapter extends RecyclerView.Adapter<FileListAdapter.Holder> {

    public interface Listener {
        void onClick(FileEntry entry, int position);
        void onLongClick(FileEntry entry, int position);
    }

    private final List<FileEntry> items = new ArrayList<>();
    private final Listener listener;
    private boolean selectionMode;

    public FileListAdapter(Listener listener) {
        this.listener = listener;
    }

    public void setItems(List<FileEntry> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    public void setSelectionMode(boolean enabled) {
        selectionMode = enabled;
        notifyDataSetChanged();
    }

    public List<FileEntry> getItems() { return items; }

    public List<FileEntry> getSelected() {
        List<FileEntry> selected = new ArrayList<>();
        for (FileEntry entry : items) if (entry.selected) selected.add(entry);
        return selected;
    }

    public void toggle(int position) {
        if (position < 0 || position >= items.size()) return;
        items.get(position).selected = !items.get(position).selected;
        notifyItemChanged(position);
    }

    public void select(int position, boolean value) {
        if (position < 0 || position >= items.size()) return;
        items.get(position).selected = value;
        notifyItemChanged(position);
    }

    public void selectAll(boolean value) {
        for (FileEntry entry : items) entry.selected = value;
        notifyDataSetChanged();
    }

    @NonNull @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_fm_file, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        FileEntry entry = items.get(position);
        h.name.setText(entry.name);
        h.meta.setText(metaText(h.itemView, entry));
        FileKind kind = entry.kind();
        int color = colorFor(kind);
        h.icon.setImageResource(iconFor(kind));
        h.icon.setColorFilter(color, PorterDuff.Mode.SRC_IN);
        GradientDrawable badge = new GradientDrawable();
        badge.setCornerRadius(h.badge.getResources().getDisplayMetrics().density * 14f);
        badge.setColor((color & 0x00FFFFFF) | 0x26000000);
        h.badge.setBackground(badge);
        h.thumb.setVisibility(View.GONE);
        h.icon.setVisibility(View.VISIBLE);
        h.badge.setTag(null);
        if (entry.file != null && (kind == FileKind.IMAGE || kind == FileKind.APK)) {
            final java.io.File file = entry.file;
            final String path = file.getAbsolutePath();
            h.badge.setTag(path);
            Bitmap cached = ThumbLoader.cached(file);
            if (cached != null) {
                showThumb(h, cached);
            } else {
                int px = Math.round(44f * h.badge.getResources().getDisplayMetrics().density);
                ThumbLoader.load(h.badge.getContext(), file, kind == FileKind.APK, px, bitmap -> {
                    if (path.equals(h.badge.getTag())) showThumb(h, bitmap);
                });
            }
        }
        h.check.setVisibility(selectionMode ? View.VISIBLE : View.GONE);
        h.check.setChecked(entry.selected);
        h.itemView.setActivated(entry.selected);
        h.itemView.setOnClickListener(v -> {
            int pos = h.getBindingAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) listener.onClick(items.get(pos), pos);
        });
        h.itemView.setOnLongClickListener(v -> {
            int pos = h.getBindingAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) listener.onLongClick(items.get(pos), pos);
            return true;
        });
    }

    @Override public int getItemCount() { return items.size(); }

    private static String metaText(View view, FileEntry e) {
        StringBuilder sb = new StringBuilder();
        if (e.subtitle != null && !e.subtitle.isEmpty()) {
            sb.append(e.subtitle);
            if (!e.dir && e.size >= 0) sb.append(" • ").append(FormatUtils.formatBytes(e.size));
        } else {
            if (e.modified > 0) {
                sb.append(DateFormat.getMediumDateFormat(view.getContext()).format(new Date(e.modified)))
                        .append(' ')
                        .append(DateFormat.getTimeFormat(view.getContext()).format(new Date(e.modified)));
            }
            if (e.dir) {
                if (e.childCount >= 0) sb.append(sb.length() > 0 ? " • " : "").append(e.childCount).append(e.childCount == 1 ? " item" : " itens");
            } else if (e.size >= 0) {
                sb.append(sb.length() > 0 ? " • " : "").append(FormatUtils.formatBytes(e.size));
            }
        }
        return sb.toString();
    }

    private static void showThumb(Holder h, Bitmap bitmap) {
        h.thumb.setImageBitmap(bitmap);
        h.thumb.setVisibility(View.VISIBLE);
        h.icon.setVisibility(View.GONE);
    }

    public void invertSelection() {
        for (FileEntry entry : items) entry.selected = !entry.selected;
        notifyDataSetChanged();
    }

    public static int iconFor(FileKind kind) {
        switch (kind) {
            case FOLDER: return R.drawable.ic_file_folder;
            case ARCHIVE: return R.drawable.ic_file_archive;
            case IMAGE: return R.drawable.ic_file_image;
            case VIDEO: return R.drawable.ic_file_video;
            case AUDIO: return R.drawable.ic_file_audio;
            case APK: return R.drawable.ic_file_apk;
            case TEXT: case SCRIPT: return R.drawable.ic_file_text;
            default: return R.drawable.ic_file_generic;
        }
    }

    public static int colorFor(FileKind kind) {
        switch (kind) {
            case FOLDER: return 0xFFFBBF24;
            case ARCHIVE: return 0xFFFB923C;
            case IMAGE: return 0xFF34D399;
            case VIDEO: return 0xFFF87171;
            case AUDIO: return 0xFFA78BFA;
            case APK: return 0xFF4ADE80;
            case TEXT: return 0xFF93C5FD;
            case SCRIPT: return 0xFF22E5FF;
            case PDF: return 0xFFF87171;
            default: return 0xFF9FB3D1;
        }
    }

    static final class Holder extends RecyclerView.ViewHolder {
        final ImageView icon;
        final TextView name, meta;
        final CheckBox check;
        final View badge;
        final ImageView thumb;

        Holder(@NonNull View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.iv_fm_icon);
            name = itemView.findViewById(R.id.tv_fm_name);
            meta = itemView.findViewById(R.id.tv_fm_meta);
            check = itemView.findViewById(R.id.cb_fm_select);
            badge = itemView.findViewById(R.id.fl_fm_badge);
            thumb = itemView.findViewById(R.id.iv_fm_thumb);
            badge.setClipToOutline(true);
            badge.setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View view, Outline outline) {
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(),
                            view.getResources().getDisplayMetrics().density * 14f);
                }
            });
        }
    }
}
