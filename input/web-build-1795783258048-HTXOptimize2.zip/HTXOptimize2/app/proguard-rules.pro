# Regras usadas apenas na minificação opcional (-PminifyRelease=true).
-keep class com.htx.optimize.** { *; }

# Shizuku (serviço de usuário carregado pelo nome da classe) e AIDL
-keep class rikka.shizuku.** { *; }
-keep class com.htx.optimize.shizuku.** { *; }

# Bibliotecas acessadas por reflexão (7Z e RAR)
-keep class org.apache.commons.compress.** { *; }
-keep class org.tukaani.xz.** { *; }
-keep class com.github.junrar.** { *; }
-dontwarn org.apache.commons.compress.**
-dontwarn org.tukaani.xz.**
-dontwarn com.github.junrar.**
-dontwarn org.slf4j.**
-dontwarn javax.annotation.**
-dontwarn com.github.luben.zstd.**
-dontwarn org.brotli.dec.**
-dontwarn org.objectweb.asm.**
