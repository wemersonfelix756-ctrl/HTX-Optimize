#!/usr/bin/env python3
"""Fast structural checks for HTX Optimize resources before Android compilation."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "app" / "src" / "main" / "res"
JAVA = ROOT / "app" / "src" / "main" / "java"
errors = []
xml_files = list(RES.rglob("*.xml"))
for path in xml_files:
    try:
        ET.parse(path)
    except ET.ParseError as exc:
        errors.append(f"XML inválido: {path.relative_to(ROOT)}: {exc}")

known_ids = set()
for path in xml_files:
    content = path.read_text(encoding="utf-8")
    known_ids.update(re.findall(r"@\+id/([A-Za-z0-9_]+)", content))
    known_ids.update(re.findall(r"@id/([A-Za-z0-9_]+)", content))

for path in JAVA.rglob("*.java"):
    content = path.read_text(encoding="utf-8")
    for resource_id in re.findall(r"(?<![A-Za-z0-9_.])R\.id\.([A-Za-z0-9_]+)", content):
        if resource_id not in known_ids:
            errors.append(f"ID não encontrado: {resource_id} em {path.relative_to(ROOT)}")

# --- IDs duplicados dentro do mesmo layout ---
for path in (RES / "layout").glob("*.xml"):
    ids = re.findall(r"@\+id/([A-Za-z0-9_]+)", path.read_text(encoding="utf-8"))
    for dup in sorted({i for i in ids if ids.count(i) > 1}):
        errors.append(f"ID duplicado '{dup}' em {path.relative_to(ROOT)}")

# --- recursos: R.string / R.drawable / R.layout ... e @string/@drawable/@color/@style ---
defined = {"string": set(), "color": set(), "style": set(), "drawable": set(), "layout": set(),
           "menu": set(), "mipmap": set(), "id": set(known_ids)}
for path in (RES / "values").glob("*.xml"):
    text = path.read_text(encoding="utf-8")
    for kind in ("string", "color", "style"):
        defined[kind].update(re.findall(rf'<{kind}\s+name="([A-Za-z0-9_.]+)"', text))
for folder in RES.iterdir():
    if not folder.is_dir():
        continue
    base = folder.name.split("-")[0]
    if base in ("drawable", "layout", "menu", "mipmap", "color"):
        for res_file in folder.iterdir():
            defined.setdefault(base, set()).add(res_file.stem)

for path in JAVA.rglob("*.java"):
    content = path.read_text(encoding="utf-8")
    for kind in ("string", "drawable", "layout", "menu", "mipmap", "color"):
        for name in re.findall(rf"(?<![A-Za-z0-9_.])R\.{kind}\.([A-Za-z0-9_]+)", content):
            if name not in defined.get(kind, set()):
                errors.append(f"R.{kind}.{name} não existe ({path.relative_to(ROOT)})")

for path in xml_files + [ROOT / "app" / "src" / "main" / "AndroidManifest.xml"]:
    content = path.read_text(encoding="utf-8")
    for kind, name in re.findall(r"@(string|drawable|color|style|mipmap|menu|layout)/([A-Za-z0-9_.]+)", content):
        if kind == "style" and not name.startswith("Theme.HTX"):
            continue  # estilos de bibliotecas (Material/AppCompat)
        key = name.replace(".", "_") if kind == "style" else name
        names = defined.get(kind, set())
        if name not in names and key not in {n.replace(".", "_") for n in names}:
            errors.append(f"@{kind}/{name} não existe ({path.relative_to(ROOT)})")

# --- atributos e estilos do tema ---
attrs_defined = set()
attrs_file = RES / "values" / "attrs.xml"
if attrs_file.exists():
    attrs_defined = set(re.findall(r'<attr\s+name="([A-Za-z0-9_]+)"', attrs_file.read_text(encoding="utf-8")))
styles_defined = set()
for path in (RES / "values").glob("*.xml"):
    for name in re.findall(r'<style\s+name="([A-Za-z0-9_.]+)"', path.read_text(encoding="utf-8")):
        styles_defined.add(name.replace(".", "_"))
for path in JAVA.rglob("*.java"):
    content = path.read_text(encoding="utf-8")
    for name in re.findall(r"(?<![A-Za-z0-9_.])R\.attr\.([A-Za-z0-9_]+)", content):
        if name not in attrs_defined:
            errors.append(f"R.attr.{name} não existe ({path.relative_to(ROOT)})")
    for name in re.findall(r"(?<![A-Za-z0-9_.])R\.style\.([A-Za-z0-9_]+)", content):
        if name not in styles_defined:
            errors.append(f"R.style.{name} não existe ({path.relative_to(ROOT)})")
for path in xml_files:
    for name in re.findall(r"\?attr/(htx[A-Za-z0-9]+)", path.read_text(encoding="utf-8")):
        if name not in attrs_defined:
            errors.append(f"?attr/{name} não existe ({path.relative_to(ROOT)})")

menu = RES / "menu" / "bottom_nav_menu.xml"
if menu.exists():
    try:
        tree = ET.parse(menu)
        items = tree.getroot().findall("item")
        if len(items) > 5:
            errors.append(f"BottomNavigationView tem {len(items)} itens; o limite recomendado é 5.")
    except ET.ParseError:
        pass

if errors:
    print("\n".join(errors), file=sys.stderr)
    sys.exit(1)
print(f"Verificação estrutural concluída: {len(xml_files)} XMLs válidos; IDs Java resolvidos.")
