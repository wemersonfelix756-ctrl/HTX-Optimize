HTX Optimize 2.0 — projeto Android Java

IMPORTANTE
Este ZIP contém o PROJETO-FONTE, não um APK compilado. O ambiente desta sessão não possui Android SDK nem Gradle, então não consigo compilar/testar um APK aqui.

Como compilar:
1. Abra/import o projeto em Android Studio ou serviço de build Android compatível.
2. Use JDK 17 e Android SDK Platform 35.
3. Execute: gradle assembleDebug
4. APK gerado em: app/build/outputs/apk/debug/app-debug.apk

Limitações reais do Android:
- Apps comuns não podem forçar encerramento de outros apps nem alterar prioridade de jogos.
- O indicador flutuante mostra taxa de atualização do ecrã (Hz), não FPS interno do jogo.
- CPU detalhada e métricas de FPS de outros apps podem ser bloqueadas pelo Android.
- O botão de otimização oferece ações seguras; não promete liberar RAM artificialmente.
