package com.htx.optimize;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;
import android.widget.TextView;

public class FpsOverlayService extends Service {
    WindowManager wm; TextView bubble; Handler h=new Handler(); Runnable tick;
    @Override public void onCreate() {
        super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        bubble=new TextView(this); bubble.setTextColor(Color.WHITE); bubble.setBackgroundColor(0xDD5B268E);
        bubble.setPadding(18,12,18,12); bubble.setTextSize(12);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(-2,-2,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.END; p.x=20; p.y=180;
        bubble.setOnTouchListener(new View.OnTouchListener(){float x,y; public boolean onTouch(View v,android.view.MotionEvent e){
            if(e.getAction()==0){x=e.getRawX();y=e.getRawY();return true;}
            if(e.getAction()==2){p.x-=(int)(e.getRawX()-x);p.y+=(int)(e.getRawY()-y);x=e.getRawX();y=e.getRawY();wm.updateViewLayout(bubble,p);return true;} return true;
        }});
        wm.addView(bubble,p);
        tick=new Runnable(){public void run(){
            float hz=getDisplayHz(); bubble.setText(String.format(java.util.Locale.US,"HTX • %.0f Hz",hz));
            h.postDelayed(this,1000);
        }}; h.post(tick);
    }
    float getDisplayHz(){ try { if(Build.VERSION.SDK_INT>=30) return getDisplay().getRefreshRate(); } catch(Exception e){} return 60f; }
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){h.removeCallbacks(tick);if(bubble!=null)wm.removeView(bubble);super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
