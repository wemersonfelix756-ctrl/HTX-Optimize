package com.htx.optimize;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;

public class MainActivity extends Activity {
    LinearLayout page;
    TextView ram, cpu, status;
    Handler handler = new Handler();
    Runnable monitor;
    static final int PICK_ICON = 44;

    int purple = Color.rgb(177, 92, 255);
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(10,8,18));
        getWindow().setNavigationBarColor(Color.rgb(10,8,18));
        page = new LinearLayout(this); page.setOrientation(1);
        page.setPadding(24,28,24,24); page.setBackgroundColor(Color.rgb(10,8,18));
        ScrollView scroll = new ScrollView(this); scroll.addView(page); setContentView(scroll);
        title("HTX OPTIMIZE", "TURBO COMMAND CENTER • v2.0");
        card("MONITORAMENTO EM TEMPO REAL");
        ram = line("RAM: lendo...");
        cpu = line("CPU: leitura indisponível");
        status = line("Sistema pronto");
        button("OTIMIZAR SISTEMA", () -> optimize());
        card("MODO TURBO");
        line("Atalho para reduzir distrações e abrir as opções de bateria/desempenho do Android. O app não altera a prioridade de outros aplicativos.");
        button("ATIVAR MODO TURBO", () -> {
            try { startActivity(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)); }
            catch(Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        });
        card("FPS FLUTUANTE");
        line("O Android não permite que um app comum leia o FPS interno de outros jogos. A bolha mostra a taxa de atualização do ecrã (Hz), não FPS real do jogo.");
        button("PERMITIR SOBREPOSIÇÃO", () -> {
            if (!Settings.canDrawOverlays(this))
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));
            else Toast.makeText(this,"Permissão já concedida",Toast.LENGTH_SHORT).show();
        });
        button("MOSTRAR INDICADOR FLUTUANTE", () -> {
            if (Settings.canDrawOverlays(this)) startService(new Intent(this,FpsOverlayService.class));
            else Toast.makeText(this,"Conceda a permissão de sobreposição primeiro",Toast.LENGTH_LONG).show();
        });
        button("PARAR INDICADOR", () -> stopService(new Intent(this,FpsOverlayService.class)));
        card("PERMISSÕES E ARQUIVOS");
        line("Escolha uma pasta para conceder acesso aos arquivos selecionados. O app não acessa dados privados de outros aplicativos.");
        button("ESCOLHER PASTA", () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            startActivityForResult(i, 31);
        });
        card("PERSONALIZAÇÃO E CRÉDITOS");
        button("ESCOLHER IMAGEM DE ÍCONE (PRÉVIA)", () -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i,PICK_ICON);
        });
        line("Wemerson Dev  •  Android Optimization & Development");
        line("HTX Optimize 2.0");
        startMonitor();
    }
    void title(String a,String b) {
        TextView t = new TextView(this); t.setText(a); t.setTextColor(Color.WHITE); t.setTextSize(27); t.setTypeface(null,1); page.addView(t);
        TextView s = new TextView(this); s.setText(b); s.setTextColor(purple); s.setTextSize(11); s.setPadding(0,4,0,22); page.addView(s);
    }
    void card(String s) {
        TextView t = new TextView(this); t.setText("◆  "+s); t.setTextColor(purple); t.setTextSize(14); t.setTypeface(null,1);
        t.setPadding(0,22,0,8); page.addView(t);
        View v = new View(this); v.setBackgroundColor(Color.rgb(65,42,88)); v.setLayoutParams(new LinearLayout.LayoutParams(-1,2)); page.addView(v);
    }
    TextView line(String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.rgb(220,215,230)); t.setTextSize(14); t.setPadding(0,12,0,12); page.addView(t); return t;
    }
    void button(String s,Runnable r) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(91,38,142)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,7,0,7); page.addView(b,lp); b.setOnClickListener(v -> r.run());
    }
    void startMonitor() {
        monitor = new Runnable() { public void run() {
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            ((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
            long total = mi.totalMem/1048576, free = mi.availMem/1048576, used = total-free;
            ram.setText("RAM: "+used+" MB usados / "+total+" MB • "+free+" MB livres");
            cpu.setText("CPU: monitoramento detalhado bloqueado pelo Android para apps comuns");
            handler.postDelayed(this,1500);
        }};
        handler.post(monitor);
    }
    void optimize() {
        // Safe app-local trim only; Android decides which background processes can be reclaimed.
        ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
        am.trimMemory(android.content.ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN);
        status.setText("Solicitação de limpeza segura enviada ao próprio app. O Android gerencia os demais processos.");
        Toast.makeText(this,"Otimização segura concluída",Toast.LENGTH_LONG).show();
    }
    @Override protected void onDestroy(){ super.onDestroy(); if(monitor!=null) handler.removeCallbacks(monitor); }
    @Override protected void onActivityResult(int req,int res,Intent data) {
        super.onActivityResult(req,res,data);
        if(res==RESULT_OK && data!=null && data.getData()!=null) {
            if(req==31) {
                getContentResolver().takePersistableUriPermission(data.getData(), data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));
                Toast.makeText(this,"Acesso à pasta concedido",Toast.LENGTH_SHORT).show();
            } else if(req==PICK_ICON) Toast.makeText(this,"Imagem selecionada para prévia. Ícone instalado exige recompilar o APK.",Toast.LENGTH_LONG).show();
        }
    }
}
