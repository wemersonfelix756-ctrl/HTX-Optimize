from pathlib import Path
from PIL import Image, ImageDraw

SOURCE = Path("assets/icon_source.jpg")
RES_DIR = Path("app/src/main/res")

MIPMAP_SIZES = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}

def main():
    if SOURCE.exists():
        base = Image.open(SOURCE).convert("RGBA")
        side = min(base.width, base.height)
        left = (base.width - side) // 2
        top = (base.height - side) // 2
        square = base.crop((left, top, left + side, top + side))

        for folder, px in MIPMAP_SIZES.items():
            out_dir = RES_DIR / folder
            out_dir.mkdir(parents=True, exist_ok=True)
            resized = square.resize((px, px), Image.Resampling.LANCZOS)
            resized.save(out_dir / "ic_launcher.png", "PNG")
            resized.save(out_dir / "ic_launcher_round.png", "PNG")

        fg_dir = RES_DIR / "mipmap-xxxhdpi"
        fg_dir.mkdir(parents=True, exist_ok=True)
        square.resize((432, 432), Image.Resampling.LANCZOS).save(fg_dir / "ic_launcher_foreground.png", "PNG")
    else:
        for folder, px in MIPMAP_SIZES.items():
            out_dir = RES_DIR / folder
            out_dir.mkdir(parents=True, exist_ok=True)
            img = Image.new("RGBA", (px, px), (13, 10, 22, 255))
            draw = ImageDraw.Draw(img)
            pad = max(2, px // 6)
            draw.rounded_rectangle([pad, pad, px - pad, px - pad], radius=max(4, px // 5),
                                   outline=(168, 85, 247, 255), width=max(2, px // 16))
            inner = max(4, px // 3)
            draw.ellipse([inner, inner, px - inner, px - inner], fill=(124, 58, 237, 255))
            img.save(out_dir / "ic_launcher.png", "PNG")
            img.save(out_dir / "ic_launcher_round.png", "PNG")

        fg_dir = RES_DIR / "mipmap-xxxhdpi"
        fg_dir.mkdir(parents=True, exist_ok=True)
        fg = Image.new("RGBA", (432, 432), (0, 0, 0, 0))
        draw_fg = ImageDraw.Draw(fg)
        draw_fg.ellipse([116, 116, 316, 316], fill=(168, 85, 247, 255), outline=(192, 132, 252, 255), width=12)
        fg.save(fg_dir / "ic_launcher_foreground.png", "PNG")

if __name__ == "__main__":
    main()
