package com.htx.optimize.storage;

import android.content.Context;
import android.net.Uri;
import androidx.documentfile.provider.DocumentFile;

public class FileItem {

    private final Uri uri;
    private final String name;
    private final String mimeType;
    private final long sizeBytes;
    private boolean selected;

    public FileItem(Uri uri, String name, String mimeType, long sizeBytes) {
        this.uri = uri;
        this.name = name != null ? name : "arquivo";
        this.mimeType = mimeType != null ? mimeType : "desconhecido";
        this.sizeBytes = Math.max(0L, sizeBytes);
        this.selected = false;
    }

    public Uri getUri() {
        return uri;
    }

    public String getName() {
        return name;
    }

    public String getMimeType() {
        return mimeType;
    }

    public long getSizeBytes() {
        return sizeBytes;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public DocumentFile toDocumentFile(Context context) {
        return DocumentFile.fromSingleUri(context, uri);
    }
}
