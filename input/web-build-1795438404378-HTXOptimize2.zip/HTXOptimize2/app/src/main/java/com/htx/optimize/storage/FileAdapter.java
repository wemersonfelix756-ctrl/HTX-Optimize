package com.htx.optimize.storage;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.htx.optimize.R;
import com.htx.optimize.util.FormatUtils;
import java.util.ArrayList;
import java.util.List;

public class FileAdapter extends RecyclerView.Adapter<FileAdapter.FileViewHolder> {

    public interface OnSelectionChangedListener {
        void onSelectionChanged(int selectedCount, long selectedBytes);
    }

    private final List<FileItem> items = new ArrayList<>();
    private final OnSelectionChangedListener listener;

    public FileAdapter(OnSelectionChangedListener listener) {
        this.listener = listener;
    }

    public void setItems(List<FileItem> newItems) {
        items.clear();
        if (newItems != null) {
            items.addAll(newItems);
        }
        notifyDataSetChanged();
        notifySelection();
    }

    public List<FileItem> getSelectedItems() {
        List<FileItem> selected = new ArrayList<>();
        for (FileItem item : items) {
            if (item.isSelected()) {
                selected.add(item);
            }
        }
        return selected;
    }

    @NonNull
    @Override
    public FileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_file, parent, false);
        return new FileViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FileViewHolder holder, int position) {
        FileItem item = items.get(position);
        holder.tvName.setText(item.getName());
        holder.tvMeta.setText(FormatUtils.formatBytes(item.getSizeBytes()) + " • " + item.getMimeType());
        holder.checkBox.setOnCheckedChangeListener(null);
        holder.checkBox.setChecked(item.isSelected());

        View.OnClickListener toggle = v -> {
            boolean next = !item.isSelected();
            item.setSelected(next);
            holder.checkBox.setChecked(next);
            notifySelection();
        };

        holder.itemView.setOnClickListener(toggle);
        holder.checkBox.setOnClickListener(toggle);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private void notifySelection() {
        if (listener == null) {
            return;
        }
        int count = 0;
        long total = 0L;
        for (FileItem item : items) {
            if (item.isSelected()) {
                count++;
                total += item.getSizeBytes();
            }
        }
        listener.onSelectionChanged(count, total);
    }

    static class FileViewHolder extends RecyclerView.ViewHolder {
        final CheckBox checkBox;
        final TextView tvName;
        final TextView tvMeta;

        FileViewHolder(@NonNull View itemView) {
            super(itemView);
            checkBox = itemView.findViewById(R.id.cb_file_select);
            tvName = itemView.findViewById(R.id.tv_file_name);
            tvMeta = itemView.findViewById(R.id.tv_file_meta);
        }
    }
}
