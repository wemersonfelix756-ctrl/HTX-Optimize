package com.htx.optimize.fragments;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.htx.optimize.R;
import com.htx.optimize.monitor.SystemMonitor;
import com.htx.optimize.util.FormatUtils;
import java.util.Arrays;
import java.util.Locale;

public class ToolsFragment extends Fragment {

    private TextView tvOutput;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_tools, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvOutput = view.findViewById(R.id.tv_tool_output);

        view.findViewById(R.id.btn_info_device).setOnClickListener(v -> tvOutput.setText(
                "Modelo: " + SystemMonitor.getDeviceModel() +
                        "\nMarca: " + Build.MANUFACTURER +
                        "\nHardware: " + Build.HARDWARE +
                        "\nABIs suportadas: " + Arrays.toString(Build.SUPPORTED_ABIS)));

        view.findViewById(R.id.btn_info_battery).setOnClickListener(v -> {
            SystemMonitor.BatterySnapshot b = SystemMonitor.readBattery(requireContext());
            String temp = b.temperatureCelsius != null
                    ? String.format(Locale.US, "%.1f °C", b.temperatureCelsius)
                    : "Indisponível";
            tvOutput.setText(String.format(Locale.US,
                    "Nível: %s\nTemperatura: %s\nEstado: %s\nSaúde: %s\nTensão: %s\nTecnologia: %s",
                    b.levelPercent >= 0 ? b.levelPercent + "%" : "N/D",
                    temp,
                    b.statusText,
                    b.healthText,
                    b.voltageMv > 0 ? b.voltageMv + " mV" : "N/D",
                    b.technology));
        });

        view.findViewById(R.id.btn_info_storage).setOnClickListener(v -> {
            SystemMonitor.StorageSnapshot s = SystemMonitor.readInternalStorage();
            tvOutput.setText(String.format(Locale.US,
                    "Armazenamento Interno\nTotal: %s\nUtilizado: %s (%d%%)\nLivre: %s",
                    FormatUtils.formatBytes(s.totalBytes),
                    FormatUtils.formatBytes(s.usedBytes),
                    s.usedPercent,
                    FormatUtils.formatBytes(s.freeBytes)));
        });

        view.findViewById(R.id.btn_info_memory).setOnClickListener(v -> {
            SystemMonitor.RamSnapshot r = SystemMonitor.readRam(requireContext());
            tvOutput.setText(String.format(Locale.US,
                    "Memória RAM\nTotal: %s\nUtilizada: %s (%d%%)\nDisponível: %s\nLowMemory: %s",
                    FormatUtils.formatBytes(r.totalBytes),
                    FormatUtils.formatBytes(r.usedBytes),
                    r.usedPercent,
                    FormatUtils.formatBytes(r.availBytes),
                    r.lowMemory));
        });

        view.findViewById(R.id.btn_info_android).setOnClickListener(v -> tvOutput.setText(
                SystemMonitor.getAndroidVersionSummary() +
                        "\nBuild ID: " + Build.DISPLAY +
                        "\nPatch de Segurança: " + (Build.VERSION.SECURITY_PATCH != null ? Build.VERSION.SECURITY_PATCH : "N/D")));

        view.findViewById(R.id.btn_settings_apps).setOnClickListener(v ->
                FormatUtils.safeStartActivity(requireContext(), new Intent(Settings.ACTION_APPLICATION_SETTINGS)));

        view.findViewById(R.id.btn_settings_battery).setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
            if (!FormatUtils.safeStartActivity(requireContext(), intent)) {
                FormatUtils.safeStartActivity(requireContext(), new Intent(Intent.ACTION_POWER_USAGE_SUMMARY));
            }
        });

        view.findViewById(R.id.btn_settings_storage).setOnClickListener(v ->
                FormatUtils.safeStartActivity(requireContext(), new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)));
    }
}
