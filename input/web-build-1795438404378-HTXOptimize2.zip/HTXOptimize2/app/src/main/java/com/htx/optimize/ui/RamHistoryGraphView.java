package com.htx.optimize.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import com.htx.optimize.R;
import java.util.ArrayList;
import java.util.List;

public class RamHistoryGraphView extends View {

    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Integer> samples = new ArrayList<>();
    private static final int MAX_SAMPLES = 24;

    public RamHistoryGraphView(Context context) {
        super(context);
        init(context);
    }

    public RamHistoryGraphView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        gridPaint.setColor(ContextCompat.getColor(context, R.color.htx_glow_soft));
        gridPaint.setStrokeWidth(1.5f);

        linePaint.setColor(ContextCompat.getColor(context, R.color.htx_border_bright));
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(4f);

        fillPaint.setColor(ContextCompat.getColor(context, R.color.htx_glow_soft));
        fillPaint.setStyle(Paint.Style.FILL);
    }

    public void addSample(int percent) {
        if (samples.size() >= MAX_SAMPLES) {
            samples.remove(0);
        }
        samples.add(Math.max(0, Math.min(100, percent)));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) {
            return;
        }

        for (int i = 1; i <= 3; i++) {
            float y = (h * i) / 4f;
            canvas.drawLine(0f, y, w, y, gridPaint);
        }

        if (samples.size() < 2) {
            return;
        }

        Path linePath = new Path();
        Path areaPath = new Path();
        float stepX = (float) w / (MAX_SAMPLES - 1);
        float startX = w - (samples.size() - 1) * stepX;

        for (int i = 0; i < samples.size(); i++) {
            float x = startX + i * stepX;
            float y = h - ((samples.get(i) / 100f) * (h - 16f) + 8f);
            if (i == 0) {
                linePath.moveTo(x, y);
                areaPath.moveTo(x, h);
                areaPath.lineTo(x, y);
            } else {
                linePath.lineTo(x, y);
                areaPath.lineTo(x, y);
            }
        }

        float lastX = startX + (samples.size() - 1) * stepX;
        areaPath.lineTo(lastX, h);
        areaPath.close();

        canvas.drawPath(areaPath, fillPaint);
        canvas.drawPath(linePath, linePaint);
    }
}
