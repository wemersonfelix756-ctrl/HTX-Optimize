package com.htx.optimize;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.htx.optimize.fragments.AboutFragment;
import com.htx.optimize.fragments.HomeFragment;
import com.htx.optimize.fragments.RamBoosterFragment;
import com.htx.optimize.fragments.RamCleanerFragment;
import com.htx.optimize.fragments.StorageFragment;
import com.htx.optimize.fragments.ToolsFragment;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_main);

            View root = findViewById(R.id.root_layout);
            if (root != null) {
                ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
                    Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                    v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                    return insets;
                });
            }

            bottomNavigation = findViewById(R.id.bottom_navigation);
            if (bottomNavigation != null) {
                bottomNavigation.setOnItemSelectedListener(item -> {
                    Fragment target = createFragmentForId(item.getItemId());
                    switchFragment(target);
                    return true;
                });

                if (savedInstanceState == null) {
                    bottomNavigation.setSelectedItemId(R.id.nav_home);
                }
            } else if (savedInstanceState == null) {
                switchFragment(new HomeFragment());
            }
        } catch (Throwable t) {
            showFallbackError(t);
        }
    }

    public void selectTab(int menuItemId) {
        if (bottomNavigation != null) {
            bottomNavigation.setSelectedItemId(menuItemId);
        }
    }

    private Fragment createFragmentForId(int id) {
        if (id == R.id.nav_ram_cleaner) {
            return new RamCleanerFragment();
        } else if (id == R.id.nav_ram_booster) {
            return new RamBoosterFragment();
        } else if (id == R.id.nav_storage) {
            return new StorageFragment();
        } else if (id == R.id.nav_tools) {
            return new ToolsFragment();
        } else if (id == R.id.nav_about) {
            return new AboutFragment();
        }
        return new HomeFragment();
    }

    private void switchFragment(Fragment fragment) {
        if (isFinishing() || isDestroyed() || fragment == null) {
            return;
        }
        try {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commitAllowingStateLoss();
        } catch (Throwable t) {
            showFallbackError(t);
        }
    }

    private void showFallbackError(Throwable t) {
        try {
            TextView tv = new TextView(this);
            tv.setBackgroundColor(0xFF050509);
            tv.setTextColor(0xFFF5F3FF);
            tv.setPadding(32, 64, 32, 32);
            String msg = (t != null && t.getMessage() != null) ? t.getMessage() : "Erro ao iniciar";
            String cls = (t != null) ? t.getClass().getName() : "Exception";
            tv.setText("HTX Optimize - Falha na inicialização:\n\n" + cls + "\n" + msg);
            setContentView(tv);
        } catch (Throwable ignored) {
        }
    }
}
