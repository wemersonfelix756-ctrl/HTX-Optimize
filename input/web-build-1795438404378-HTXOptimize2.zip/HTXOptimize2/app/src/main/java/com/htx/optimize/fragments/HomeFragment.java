package com.htx.optimize.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.htx.optimize.MainActivity;
import com.htx.optimize.R;
import com.htx.optimize.monitor.SystemMonitor;
import com.htx.optimize.ui.ArcGaugeView;
import com.htx.optimize.util.FormatUtils;
import java.util.Locale;

public class HomeFragment extends Fragment {

    private TextView tvDeviceModel;
    private TextView tvAndroidVersion;
    private ArcGaugeView gaugeRam;
    private TextView tvRamDetails;
    private ProgressBar progressStorage;
    private TextView tvStoragePercent;
    private TextView tvStorageDetails;
    private TextView tvBatterySummary;
    private ProgressBar progressBattery;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvDeviceModel = view.findViewById(R.id.tv_device_model);
        tvAndroidVersion = view.findViewById(R.id.tv_android_version);
        gaugeRam = view.findViewById(R.id.gauge_ram);
        tvRamDetails = view.findViewById(R.id.tv_ram_details);
        progressStorage = view.findViewById(R.id.progress_storage);
        tvStoragePercent = view.findViewById(R.id.tv_storage_percent);
        tvStorageDetails = view.findViewById(R.id.tv_storage_details);
        tvBatterySummary = view.findViewById(R.id.tv_battery_summary);
        progressBattery = view.findViewById(R.id.progress_battery);

        Button btnRefresh = view.findViewById(R.id.btn_refresh_dashboard);
        if (btnRefresh != null) {
            btnRefresh.setOnClickListener(v -> refreshAll());
        }

        View vCleaner = view.findViewById(R.id.btn_quick_cleaner);
        if (vCleaner != null) vCleaner.setOnClickListener(v -> openTab(R.id.nav_ram_cleaner));

        View vBooster = view.findViewById(R.id.btn_quick_booster);
        if (vBooster != null) vBooster.setOnClickListener(v -> openTab(R.id.nav_ram_booster));

        View vStorage = view.findViewById(R.id.btn_quick_storage);
        if (vStorage != null) vStorage.setOnClickListener(v -> openTab(R.id.nav_storage));

        View vTools = view.findViewById(R.id.btn_quick_tools);
        if (vTools != null) vTools.setOnClickListener(v -> openTab(R.id.nav_tools));

        refreshAll();
    }

    private void openTab(int menuId) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).selectTab(menuId);
        }
    }

    private void refreshAll() {
        if (!isAdded() || getContext() == null) {
            return;
        }
        try {
            if (tvDeviceModel != null) tvDeviceModel.setText(SystemMonitor.getDeviceModel());
            if (tvAndroidVersion != null) tvAndroidVersion.setText(SystemMonitor.getAndroidVersionSummary());

            SystemMonitor.RamSnapshot ram = SystemMonitor.readRam(requireContext());
            if (gaugeRam != null) gaugeRam.setProgressAnimated(ram.usedPercent, "RAM USADA");
            if (tvRamDetails != null) {
                tvRamDetails.setText(String.format(Locale.US,
                        "Total: %s • Utilizada: %s • Disponível: %s",
                        FormatUtils.formatBytes(ram.totalBytes),
                        FormatUtils.formatBytes(ram.usedBytes),
                        FormatUtils.formatBytes(ram.availBytes)));
            }

            SystemMonitor.StorageSnapshot storage = SystemMonitor.readInternalStorage();
            if (progressStorage != null) progressStorage.setProgress(storage.usedPercent);
            if (tvStoragePercent != null) tvStoragePercent.setText(storage.usedPercent + "% utilizado");
            if (tvStorageDetails != null) {
                tvStorageDetails.setText(String.format(Locale.US,
                        "Total: %s • Usado: %s • Livre: %s",
                        FormatUtils.formatBytes(storage.totalBytes),
                        FormatUtils.formatBytes(storage.usedBytes),
                        FormatUtils.formatBytes(storage.freeBytes)));
            }

            SystemMonitor.BatterySnapshot bat = SystemMonitor.readBattery(requireContext());
            String tempStr = bat.temperatureCelsius != null
                    ? String.format(Locale.US, "%.1f °C", bat.temperatureCelsius)
                    : "Temp. indisponível";
            String pctStr = bat.levelPercent >= 0 ? bat.levelPercent + "%" : "N/D";
            if (tvBatterySummary != null) tvBatterySummary.setText(pctStr + " • " + tempStr + " • " + bat.statusText);
            if (progressBattery != null) progressBattery.setProgress(Math.max(0, Math.min(100, bat.levelPercent)));
        } catch (Throwable ignored) {
        }
    }
}
