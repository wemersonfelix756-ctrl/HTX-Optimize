package com.htx.optimize.util;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.widget.Toast;
import java.util.Locale;

public final class FormatUtils {

    private FormatUtils() {
    }

    public static String formatBytes(long bytes) {
        if (bytes < 0) {
            return "Indisponível";
        }
        double unit = 1024.0;
        if (bytes < unit) {
            return bytes + " B";
        }
        int exp = (int) (Math.log(bytes) / Math.log(unit));
        String pre = "KMGTPE".charAt(exp - 1) + "B";
        return String.format(Locale.US, "%.2f %s", bytes / Math.pow(unit, exp), pre);
    }

    public static boolean safeStartActivity(Context context, Intent intent) {
        if (context == null || intent == null) {
            return false;
        }
        PackageManager pm = context.getPackageManager();
        if (intent.resolveActivity(pm) != null) {
            try {
                context.startActivity(intent);
                return true;
            } catch (Exception e) {
                Toast.makeText(context, "Não foi possível abrir esta configuração no dispositivo.", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        Toast.makeText(context, "Configuração não disponível neste modelo/versão.", Toast.LENGTH_SHORT).show();
        return false;
    }
}
