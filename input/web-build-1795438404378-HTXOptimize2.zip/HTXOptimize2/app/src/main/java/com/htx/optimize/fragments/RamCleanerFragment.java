package com.htx.optimize.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import com.htx.optimize.R;
import com.htx.optimize.monitor.SystemMonitor;
import com.htx.optimize.ui.RamHistoryGraphView;
import com.htx.optimize.util.FormatUtils;
import java.util.Locale;

public class RamCleanerFragment extends Fragment {

    private static final long POLL_INTERVAL_MS = 2000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView tvMetrics;
    private TextView tvState;
    private RamHistoryGraphView graphView;
    private SwitchCompat switchAuto;
    private boolean autoEnabled = true;

    private final Runnable pollRunnable = new Runnable() {
        @Override
        public void run() {
            updateRamTelemetry();
            if (autoEnabled && isResumed()) {
                handler.postDelayed(this, POLL_INTERVAL_MS);
            }
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_ram_cleaner, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvMetrics = view.findViewById(R.id.tv_cleaner_metrics);
        tvState = view.findViewById(R.id.tv_cleaner_state);
        graphView = view.findViewById(R.id.ram_history_graph);
        switchAuto = view.findViewById(R.id.switch_auto_refresh);

        switchAuto.setOnCheckedChangeListener((buttonView, isChecked) -> {
            autoEnabled = isChecked;
            handler.removeCallbacks(pollRunnable);
            if (isChecked && isResumed()) {
                handler.post(pollRunnable);
            }
        });

        Button btnApps = view.findViewById(R.id.btn_open_app_settings);
        btnApps.setOnClickListener(v ->
                FormatUtils.safeStartActivity(requireContext(), new Intent(Settings.ACTION_APPLICATION_SETTINGS)));

        updateRamTelemetry();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (autoEnabled) {
            handler.removeCallbacks(pollRunnable);
            handler.postDelayed(pollRunnable, POLL_INTERVAL_MS);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        handler.removeCallbacks(pollRunnable);
    }

    private void updateRamTelemetry() {
        if (!isAdded() || getContext() == null) {
            return;
        }
        SystemMonitor.RamSnapshot ram = SystemMonitor.readRam(requireContext());
        graphView.addSample(ram.usedPercent);

        tvMetrics.setText(String.format(Locale.US,
                "Utilização: %d%%\nTotal: %s\nUtilizada: %s\nDisponível: %s\nLimiar do sistema: %s",
                ram.usedPercent,
                FormatUtils.formatBytes(ram.totalBytes),
                FormatUtils.formatBytes(ram.usedBytes),
                FormatUtils.formatBytes(ram.availBytes),
                FormatUtils.formatBytes(ram.thresholdBytes)));

        if (ram.lowMemory || ram.usedPercent >= 85) {
            tvState.setText("Estado: Pressão de memória elevada (lowMemory=" + ram.lowMemory + ")");
        } else {
            tvState.setText("Estado: Memória estável (lowMemory=false)");
        }
    }
}
