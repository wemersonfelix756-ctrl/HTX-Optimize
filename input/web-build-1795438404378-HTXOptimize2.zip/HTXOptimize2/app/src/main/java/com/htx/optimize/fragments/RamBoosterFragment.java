package com.htx.optimize.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.htx.optimize.R;
import com.htx.optimize.monitor.SystemMonitor;
import com.htx.optimize.util.FormatUtils;
import java.util.Locale;

public class RamBoosterFragment extends Fragment {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView tvStatus;
    private TextView tvReport;
    private ProgressBar progressBar;
    private Button btnRun;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_ram_booster, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvStatus = view.findViewById(R.id.tv_booster_status);
        tvReport = view.findViewById(R.id.tv_booster_report);
        progressBar = view.findViewById(R.id.progress_booster_scan);
        btnRun = view.findViewById(R.id.btn_run_booster);

        btnRun.setOnClickListener(v -> runSafeBoosterScan());
        view.findViewById(R.id.btn_booster_apps).setOnClickListener(v ->
                FormatUtils.safeStartActivity(requireContext(), new Intent(Settings.ACTION_APPLICATION_SETTINGS)));

        refreshCurrentState();
    }

    private void refreshCurrentState() {
        if (!isAdded() || getContext() == null) {
            return;
        }
        SystemMonitor.RamSnapshot ram = SystemMonitor.readRam(requireContext());
        String diag = (ram.lowMemory || ram.usedPercent >= 82)
                ? "Diagnóstico: Pouca memória disponível. Recomenda-se fechar apps pesados abertos recentemente."
                : "Diagnóstico: Disponibilidade de memória dentro da faixa normal.";
        tvStatus.setText(String.format(Locale.US,
                "RAM disponível atual: %s de %s (%d%% usada)\n%s",
                FormatUtils.formatBytes(ram.availBytes),
                FormatUtils.formatBytes(ram.totalBytes),
                ram.usedPercent,
                diag));
    }

    private void runSafeBoosterScan() {
        if (!isAdded() || getContext() == null) {
            return;
        }
        btnRun.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setProgress(0);

        SystemMonitor.RamSnapshot before = SystemMonitor.readRam(requireContext());

        for (int step = 1; step <= 4; step++) {
            final int pct = step * 25;
            handler.postDelayed(() -> {
                if (isAdded()) {
                    progressBar.setProgress(pct);
                }
            }, step * 180L);
        }

        handler.postDelayed(() -> {
            if (!isAdded() || getContext() == null) {
                return;
            }
            System.gc();
            SystemMonitor.RamSnapshot after = SystemMonitor.readRam(requireContext());
            long deltaAvail = after.availBytes - before.availBytes;
            String deltaStr = deltaAvail >= 0
                    ? "+" + FormatUtils.formatBytes(deltaAvail)
                    : "-" + FormatUtils.formatBytes(Math.abs(deltaAvail));

            tvReport.setText(String.format(Locale.US,
                    "Ações executadas:\n" +
                            "1. Leitura atualizada da telemetria de memória do sistema.\n" +
                            "2. Verificação de pressão de memória (lowMemory=%s).\n" +
                            "3. Solicitação de coleta de lixo (GC) apenas no processo do HTX Optimize.\n" +
                            "4. Variação observada na RAM disponível do sistema: %s (antes: %s | depois: %s).\n" +
                            "Nota: O Android gerencia processos de outros apps automaticamente e não permite encerramento forçado direto por apps comuns.",
                    after.lowMemory,
                    deltaStr,
                    FormatUtils.formatBytes(before.availBytes),
                    FormatUtils.formatBytes(after.availBytes)));

            refreshCurrentState();
            progressBar.setVisibility(View.GONE);
            btnRun.setEnabled(true);
        }, 820L);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        handler.removeCallbacksAndMessages(null);
    }
}
