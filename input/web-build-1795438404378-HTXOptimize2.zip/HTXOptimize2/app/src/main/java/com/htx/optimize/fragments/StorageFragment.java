package com.htx.optimize.fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.htx.optimize.R;
import com.htx.optimize.storage.FileAdapter;
import com.htx.optimize.storage.FileItem;
import com.htx.optimize.util.FormatUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class StorageFragment extends Fragment {

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private TextView tvFolderInfo;
    private TextView tvReport;
    private Button btnDeleteSelected;
    private FileAdapter adapter;
    private Uri currentTreeUri;
    private long lastScannedBytes = 0L;
    private long lastFreedBytes = 0L;

    private final ActivityResultLauncher<Uri> folderPickerLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocumentTree(), uri -> {
                if (uri == null || !isAdded() || getContext() == null) {
                    return;
                }
                try {
                    int flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
                    requireContext().getContentResolver().takePersistableUriPermission(uri, flags);
                } catch (SecurityException ignored) {
                }
                currentTreeUri = uri;
                scanFolder(uri);
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_storage, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvFolderInfo = view.findViewById(R.id.tv_storage_folder_info);
        tvReport = view.findViewById(R.id.tv_storage_report);
        btnDeleteSelected = view.findViewById(R.id.btn_delete_selected);
        RecyclerView rvFiles = view.findViewById(R.id.rv_files);

        adapter = new FileAdapter((count, bytes) -> {
            btnDeleteSelected.setEnabled(count > 0);
            btnDeleteSelected.setText(String.format(Locale.US, "Excluir (%d)", count));
        });

        rvFiles.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvFiles.setAdapter(adapter);

        view.findViewById(R.id.btn_pick_folder).setOnClickListener(v -> folderPickerLauncher.launch(currentTreeUri));
        btnDeleteSelected.setOnClickListener(v -> confirmDeleteSelected());
    }

    private void scanFolder(Uri treeUri) {
        Context appCtx = requireContext().getApplicationContext();
        tvFolderInfo.setText("Analisando pasta selecionada...");
        executor.execute(() -> {
            DocumentFile root = DocumentFile.fromTreeUri(appCtx, treeUri);
            List<FileItem> found = new ArrayList<>();
            long totalSize = 0L;

            if (root != null && root.canRead()) {
                collectFilesRecursive(root, found);
                for (FileItem item : found) {
                    totalSize += item.getSizeBytes();
                }
                Collections.sort(found, (a, b) -> Long.compare(b.getSizeBytes(), a.getSizeBytes()));
            }

            final long scanned = totalSize;
            final String folderName = (root != null && root.getName() != null) ? root.getName() : "Pasta selecionada";

            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> {
                    if (!isAdded()) {
                        return;
                    }
                    lastScannedBytes = scanned;
                    tvFolderInfo.setText("Pasta: " + folderName + " • " + found.size() + " arquivo(s)");
                    updateReportText();
                    adapter.setItems(found);
                });
            }
        });
    }

    private void collectFilesRecursive(DocumentFile dir, List<FileItem> out) {
        DocumentFile[] children = dir.listFiles();
        for (DocumentFile child : children) {
            if (child.isDirectory()) {
                collectFilesRecursive(child, out);
            } else if (child.isFile()) {
                out.add(new FileItem(
                        child.getUri(),
                        child.getName(),
                        child.getType(),
                        child.length()
                ));
            }
        }
    }

    private void confirmDeleteSelected() {
        List<FileItem> selected = adapter.getSelectedItems();
        if (selected.isEmpty() || getContext() == null) {
            return;
        }
        long bytesToDelete = 0L;
        for (FileItem item : selected) {
            bytesToDelete += item.getSizeBytes();
        }

        new AlertDialog.Builder(requireContext())
                .setTitle("Confirmar exclusão")
                .setMessage(String.format(Locale.US,
                        "Deseja excluir permanentemente %d arquivo(s) selecionado(s) (%s)?",
                        selected.size(),
                        FormatUtils.formatBytes(bytesToDelete)))
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (dialog, which) -> deleteFilesAsync(selected))
                .show();
    }

    private void deleteFilesAsync(List<FileItem> toDelete) {
        Context appCtx = requireContext().getApplicationContext();
        executor.execute(() -> {
            long freed = 0L;
            int deletedCount = 0;
            for (FileItem item : toDelete) {
                DocumentFile doc = item.toDocumentFile(appCtx);
                if (doc != null && doc.delete()) {
                    freed += item.getSizeBytes();
                    deletedCount++;
                }
            }

            final long freedFinal = freed;
            final int countFinal = deletedCount;

            if (getActivity() != null) {
                getActivity().runOnUiThread(() -> {
                    if (!isAdded()) {
                        return;
                    }
                    lastFreedBytes += freedFinal;
                    updateReportText();
                    Toast.makeText(getContext(),
                            countFinal + " arquivo(s) excluído(s) (" + FormatUtils.formatBytes(freedFinal) + ")",
                            Toast.LENGTH_SHORT).show();
                    if (currentTreeUri != null) {
                        scanFolder(currentTreeUri);
                    }
                });
            }
        });
    }

    private void updateReportText() {
        tvReport.setText(String.format(Locale.US,
                "Espaço analisado: %s • Espaço liberado: %s",
                FormatUtils.formatBytes(lastScannedBytes),
                FormatUtils.formatBytes(lastFreedBytes)));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }
}
