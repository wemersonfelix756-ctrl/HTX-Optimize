package com.htx.optimize.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import com.htx.optimize.R;
import java.util.Locale;

public class ArcGaugeView extends View {

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint subTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arcRect = new RectF();
    private final Handler animHandler = new Handler(Looper.getMainLooper());

    private float currentPercent = 0f;
    private float targetPercent = 0f;
    private String centerLabel = "RAM";

    private final Runnable stepRunnable = new Runnable() {
        @Override
        public void run() {
            float diff = targetPercent - currentPercent;
            if (Math.abs(diff) < 0.8f) {
                currentPercent = targetPercent;
                invalidate();
                return;
            }
            currentPercent += diff * 0.25f;
            invalidate();
            animHandler.postDelayed(this, 16L);
        }
    };

    public ArcGaugeView(Context context) {
        super(context);
        init(context);
    }

    public ArcGaugeView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        float stroke = dp(12f);

        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setStrokeWidth(stroke);
        trackPaint.setColor(ContextCompat.getColor(context, R.color.htx_glow_soft));

        progressPaint.setStyle(Paint.Style.STROKE);
        progressPaint.setStrokeWidth(stroke);
        progressPaint.setStrokeCap(Paint.Cap.ROUND);
        progressPaint.setColor(ContextCompat.getColor(context, R.color.htx_neon_purple));

        textPaint.setColor(ContextCompat.getColor(context, R.color.htx_text_primary));
        textPaint.setTextSize(sp(24f));
        textPaint.setFakeBoldText(true);
        textPaint.setTextAlign(Paint.Align.CENTER);

        subTextPaint.setColor(ContextCompat.getColor(context, R.color.htx_text_secondary));
        subTextPaint.setTextSize(sp(11f));
        subTextPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setProgressAnimated(int percent, String label) {
        if (label != null) {
            this.centerLabel = label;
        }
        this.targetPercent = Math.max(0f, Math.min(100f, percent));
        animHandler.removeCallbacks(stepRunnable);
        animHandler.post(stepRunnable);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        animHandler.removeCallbacksAndMessages(null);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) {
            return;
        }
        float pad = dp(14f);
        float size = Math.max(10f, Math.min(w, h) - pad * 2f);
        float left = (w - size) / 2f;
        float top = (h - size) / 2f;
        arcRect.set(left, top, left + size, top + size);

        canvas.drawArc(arcRect, 135f, 270f, false, trackPaint);
        float sweep = 270f * (currentPercent / 100f);
        canvas.drawArc(arcRect, 135f, sweep, false, progressPaint);

        float cx = w / 2f;
        float cy = h / 2f;
        canvas.drawText(String.format(Locale.US, "%.0f%%", currentPercent), cx, cy + dp(4f), textPaint);
        canvas.drawText(centerLabel, cx, cy + dp(22f), subTextPaint);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private float sp(float v) {
        return v * getResources().getDisplayMetrics().scaledDensity;
    }
}
