# HTX Optimize 2.0 (`com.htx.optimize`)

Aplicativo nativo Android de monitoramento e gerenciamento de recursos desenvolvido por **Wemerson Dev** (*Android Optimization & Development*).

## Como compilar no GitHub Actions pelo celular (Galaxy A17)
1. Extraia este arquivo ZIP e envie todos os arquivos e pastas para um repositório no GitHub.
2. O workflow `.github/workflows/build-apk.yml` já está configurado com `gradle/actions/setup-gradle@v4` (Gradle 8.9), Java 17 e Android SDK, e gera automaticamente os ícones a partir de `assets/icon_source.jpg`.
3. Acesse a aba **Actions** do seu repositório no GitHub, aguarde o término do job e baixe o artefato **`HTX-Optimize-2.0-debug`** contendo o `app-debug.apk`.
