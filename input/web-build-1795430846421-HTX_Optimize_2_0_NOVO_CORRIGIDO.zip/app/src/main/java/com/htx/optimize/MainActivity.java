package com.htx.optimize;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.StatFs;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.Typeface;
import androidx.documentfile.provider.DocumentFile;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends Activity {
    private static final int PICK_FOLDER = 501;
    private final int bg = Color.rgb(9, 7, 17);
    private final int panel = Color.rgb(25, 19, 39);
    private final int purple = Color.rgb(183, 105, 255);
    private final int muted = Color.rgb(184, 174, 199);

    private LinearLayout content;
    private DocumentFile selectedFolder;
    private final ArrayList<DocumentFile> foundFiles = new ArrayList<>();
    private final ArrayList<CheckBox> fileChecks = new ArrayList<>();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createLayout();
        showDashboard();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private void createLayout() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(bg);

        TextView brand = new TextView(this);
        brand.setText("HTX  OPTIMIZE  ✦");
        brand.setTextColor(purple);
        brand.setTextSize(23);
        brand.setTypeface(Typeface.DEFAULT_BOLD);
        brand.setPadding(dp(20), dp(20), dp(16), dp(3));
        page.addView(brand);

        TextView subtitle = new TextView(this);
        subtitle.setText("ANDROID PERFORMANCE CENTER  •  V2.0");
        subtitle.setTextColor(muted);
        subtitle.setTextSize(10);
        subtitle.setPadding(dp(20), 0, dp(16), dp(14));
        page.addView(subtitle);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(4), dp(16), dp(20));
        scroll.addView(content);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setBackgroundColor(Color.rgb(17, 13, 27));
        nav.setPadding(dp(5), dp(7), dp(5), dp(7));
        addNav(nav, "Início", this::showDashboard);
        addNav(nav, "RAM", this::showRam);
        addNav(nav, "Arquivos", this::showStorage);
        addNav(nav, "Sistema", this::showSystem);
        page.addView(nav);
        setContentView(page);
    }

    private void addNav(LinearLayout nav, String text, Runnable action) {
        TextView item = new TextView(this);
        item.setText(text);
        item.setTextColor(Color.WHITE);
        item.setTextSize(12);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(5), dp(12), dp(5), dp(12));
        item.setOnClickListener(v -> action.run());
        nav.addView(item, new LinearLayout.LayoutParams(0, -2, 1));
    }

    private void heading(String title, String description) {
        TextView h = new TextView(this);
        h.setText(title);
        h.setTextColor(Color.WHITE);
        h.setTextSize(23);
        h.setTypeface(null, Typeface.BOLD);
        h.setPadding(0, dp(8), 0, dp(4));
        content.addView(h);
        TextView d = body(description);
        d.setPadding(0, 0, 0, dp(12));
        content.addView(d);
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.setBackgroundColor(panel);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, dp(5), 0, dp(7));
        box.setLayoutParams(params);
        return box;
    }

    private void metric(String title, String value) {
        LinearLayout box = card();
        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(muted);
        label.setTextSize(10);
        box.addView(label);
        TextView number = new TextView(this);
        number.setText(value);
        number.setTextColor(Color.WHITE);
        number.setTextSize(21);
        number.setTypeface(null, Typeface.BOLD);
        number.setPadding(0, dp(5), 0, 0);
        box.addView(number);
        content.addView(box);
    }

    private void section(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(purple);
        t.setTextSize(15);
        t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(2), dp(15), dp(2), dp(7));
        content.addView(t);
    }

    private TextView body(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(muted);
        t.setTextSize(13);
        t.setLineSpacing(dp(3), 1f);
        t.setPadding(dp(2), dp(4), dp(2), dp(7));
        return t;
    }

    private void action(String text, Runnable run) {
        TextView button = new TextView(this);
        button.setText(text + "   ›");
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setTypeface(null, Typeface.BOLD);
        button.setPadding(dp(15), dp(15), dp(15), dp(15));
        button.setBackgroundColor(panel);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(4), 0, dp(4));
        content.addView(button, p);
        button.setOnClickListener(v -> run.run());
    }

    private void showDashboard() {
        content.removeAllViews();
        heading("Painel de desempenho", "Resumo do seu dispositivo Android");
        metric("RAM DISPONÍVEL", ramAvailable());
        metric("ARMAZENAMENTO INTERNO LIVRE", storageFree());
        metric("BATERIA", batteryLevel());
        section("Ações rápidas");
        action("Analisar memória RAM", this::showRam);
        action("Analisar arquivos e espaço", this::showStorage);
        action("Ferramentas do Android", this::showSystem);
        section("Sobre o monitoramento");
        content.addView(body("O HTX Optimize mostra informações reais do aparelho e oferece ferramentas seguras. O Android administra automaticamente os processos em segundo plano."));
    }

    private void showRam() {
        content.removeAllViews();
        heading("RAM Cleaner", "Monitoramento seguro da memória");
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        manager.getMemoryInfo(info);
        metric("RAM DISPONÍVEL", formatBytes(info.availMem));
        metric("RAM TOTAL", formatBytes(info.totalMem));
        metric("ESTADO DA MEMÓRIA", info.lowMemory ? "Memória baixa" : "Normal");
        section("Ferramentas");
        content.addView(body("Aplicativos comuns não podem encerrar à força outros apps. Evitamos truques que ocupam RAM de propósito, pois podem deixar o celular mais lento e gastar bateria."));
        action("Abrir configurações de aplicativos", () -> openSetting("android.settings.APPLICATION_SETTINGS"));
        action("Atualizar leitura", this::showRam);
    }

    private void showStorage() {
        content.removeAllViews();
        heading("Gerenciador de armazenamento", "Analise uma pasta que você escolher");
        content.addView(body("O Android permite que você escolha uma pasta. O HTX Optimize só analisa os arquivos dentro da pasta autorizada; não acessa dados privados de outros aplicativos."));
        action("Escolher pasta para analisar", () -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, PICK_FOLDER);
        });
        if (selectedFolder != null) {
            content.addView(body("Pasta escolhida: " + selectedFolder.getName()));
            action("Analisar arquivos", this::scanFolder);
        }
        if (!foundFiles.isEmpty()) {
            section("Arquivos encontrados — maiores primeiro");
            fileChecks.clear();
            for (DocumentFile file : foundFiles) {
                CheckBox check = new CheckBox(this);
                check.setTextColor(Color.WHITE);
                check.setText(file.getName() + "  •  " + formatBytes(file.length()));
                check.setTag(file);
                fileChecks.add(check);
                content.addView(check);
            }
            action("Excluir arquivos selecionados", this::deleteSelected);
            content.addView(body("Confira os itens antes de excluir. A exclusão pode não ser recuperável."));
        }
    }

    private void scanFolder() {
        foundFiles.clear();
        scanRecursive(selectedFolder, 0);
        Collections.sort(foundFiles, (a, b) -> Long.compare(b.length(), a.length()));
        showStorage();
        Toast.makeText(this, foundFiles.size() + " arquivo(s) encontrados", Toast.LENGTH_SHORT).show();
    }

    private void scanRecursive(DocumentFile directory, int depth) {
        if (directory == null || !directory.isDirectory() || depth > 8 || foundFiles.size() >= 500) return;
        for (DocumentFile file : directory.listFiles()) {
            if (file.isDirectory()) scanRecursive(file, depth + 1);
            else if (file.isFile()) foundFiles.add(file);
            if (foundFiles.size() >= 500) return;
        }
    }

    private void deleteSelected() {
        int deleted = 0;
        for (CheckBox check : fileChecks) {
            if (check.isChecked()) {
                DocumentFile file = (DocumentFile) check.getTag();
                if (file.delete()) deleted++;
            }
        }
        Toast.makeText(this, deleted + " arquivo(s) excluído(s)", Toast.LENGTH_LONG).show();
        scanFolder();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FOLDER && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try {
                getContentResolver().takePersistableUriPermission(uri, flags);
                selectedFolder = DocumentFile.fromTreeUri(this, uri);
                foundFiles.clear();
                showStorage();
            } catch (Exception ex) {
                Toast.makeText(this, "Não foi possível acessar essa pasta.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void showSystem() {
        content.removeAllViews();
        heading("Ferramentas do sistema", "Atalhos para configurações oficiais do Android");
        action("Armazenamento", () -> openSetting("android.settings.INTERNAL_STORAGE_SETTINGS"));
        action("Bateria", () -> openSetting("android.settings.BATTERY_SAVER_SETTINGS"));
        action("Gerenciar aplicativos", () -> openSetting("android.settings.APPLICATION_SETTINGS"));
        action("Informações do HTX Optimize", () -> {
            Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS",
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        });
        section("Créditos");
        content.addView(body("Wemerson Dev\nAndroid Optimization & Development\nHTX Optimize — versão 2.0"));
    }

    private void openSetting(String action) {
        try {
            startActivity(new Intent(action));
        } catch (Exception e) {
            Toast.makeText(this, "Essa tela não está disponível neste Android.", Toast.LENGTH_SHORT).show();
        }
    }

    private String ramAvailable() {
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(info);
        return formatBytes(info.availMem);
    }

    private String storageFree() {
        StatFs stat = new StatFs(new File("/data").getAbsolutePath());
        return formatBytes(stat.getAvailableBytes());
    }

    private String batteryLevel() {
        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery == null) return "Indisponível";
        int level = battery.getIntExtra("level", -1);
        int scale = battery.getIntExtra("scale", 100);
        return level < 0 ? "Indisponível" : (level * 100 / scale) + "%";
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        int exp = (int) (Math.log(bytes) / Math.log(1024));
        String unit = "KMGTPE".charAt(exp - 1) + "B";
        return String.format(java.util.Locale.US, "%.1f %s", bytes / Math.pow(1024, exp), unit);
    }
}
