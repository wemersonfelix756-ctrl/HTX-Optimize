# HTX Optimize 2.0 — projeto corrigido

Projeto Android nativo em Java, com Gradle e dependência declarada do AndroidX DocumentFile.

## Recursos
- Painel: RAM disponível, armazenamento interno livre e bateria.
- RAM Cleaner: leitura de RAM total/disponível e indicação de memória baixa.
- Gerenciador de arquivos: o usuário escolhe uma pasta pelo seletor oficial do Android; o app lista arquivos e permite selecionar e excluir.
- Atalhos para configurações do Android.
- Créditos: Wemerson Dev — Android Optimization & Development.
- Tema escuro roxo/preto.

## Importante
O app só analisa a pasta que o usuário autoriza. Não lê dados privados de outros apps.
O Android controla o encerramento de processos; este app não tenta matar apps de terceiros nem preencher RAM artificialmente.
O ícone incluído é provisório. Para aplicar o ícone escolhido por você, envie a imagem diretamente nesta conversa.

## Build
Requisitos: JDK 17, Android SDK Platform 35, Build Tools compatíveis e Gradle 8.9.
No GitHub Actions, o workflow incluído executa `gradle :app:assembleDebug` e publica o APK como artefato.
