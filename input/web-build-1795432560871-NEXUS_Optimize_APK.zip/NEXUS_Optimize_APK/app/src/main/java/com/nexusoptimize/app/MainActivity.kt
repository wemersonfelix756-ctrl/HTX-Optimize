package com.nexusoptimize.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.nexusoptimize.app.overlay.FpsOverlayService
import com.nexusoptimize.app.permissions.PermissionManagerHelper

private val BgDark = Color(0xFF090A0F)
private val CardDark = Color(0xFF121520)
private val NeonCyan = Color(0xFF00F0FF)
private val ElectricPurple = Color(0xFF7000FF)
private val EmeraldGreen = Color(0xFF00FF9D)
private val AlertRed = Color(0xFFFF3B5C)
private val TextMuted = Color(0xFF9AA3B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NexusOptimizeApp()
        }
    }
}

@Composable
fun NexusOptimizeApp() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var selectedTab by remember { mutableIntStateOf(0) }
    var ramUsage by remember { mutableIntStateOf(78) }
    var cpuUsage by remember { mutableIntStateOf(54) }
    var storageUsage by remember { mutableIntStateOf(66) }
    var tempCelsius by remember { mutableIntStateOf(39) }
    var turboMode by remember { mutableStateOf(false) }
    var overlayActive by remember { mutableStateOf(false) }
    var selectedIconStyle by remember { mutableStateOf("Neon Ciano") }
    var statusMessage by remember { mutableStateOf("Sistema pronto para otimização.") }

    var hasOverlayPerm by remember { mutableStateOf(PermissionManagerHelper.canDrawOverlays(context)) }
    var hasFilesPerm by remember { mutableStateOf(PermissionManagerHelper.hasAllFilesAccess(context)) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasOverlayPerm = PermissionManagerHelper.canDrawOverlays(context)
                hasFilesPerm = PermissionManagerHelper.hasAllFilesAccess(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val accentColor = when {
        ramUsage >= 85 || tempCelsius >= 45 -> AlertRed
        turboMode -> ElectricPurple
        else -> NeonCyan
    }

    Scaffold(
        containerColor = BgDark,
        bottomBar = {
            NavigationBar(containerColor = CardDark) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Speed, contentDescription = "Boost") },
                    label = { Text("Boost", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Security, contentDescription = "Permissões") },
                    label = { Text("Permissões", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Palette, contentDescription = "Ícone") },
                    label = { Text("Ícone", fontSize = 11.sp) }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Info, contentDescription = "Créditos") },
                    label = { Text("Créditos", fontSize = 11.sp) }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "NEXUS OPTIMIZE // v1.0",
                color = accentColor,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            when (selectedTab) {
                0 -> {
                    FuturisticCard(accentColor) {
                        Text("TELEMETRIA DO SISTEMA", color = TextMuted, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("RAM: $ramUsage%  •  CPU: $cpuUsage%  •  Temp: ${tempCelsius}°C", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Armazenamento: $storageUsage%", color = TextMuted, fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))
                        Text(statusMessage, color = EmeraldGreen, fontSize = 13.sp)
                    }

                    Button(
                        onClick = {
                            ramUsage = (ramUsage - 24).coerceAtLeast(28)
                            cpuUsage = (cpuUsage - 18).coerceAtLeast(15)
                            tempCelsius = (tempCelsius - 3).coerceAtLeast(33)
                            statusMessage = "Otimização concluída! Memória e processos ajustados."
                        },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = accentColor, contentColor = BgDark),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Bolt, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("OTIMIZAR TUDO", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    FuturisticCard(accentColor) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("MODO TURBO", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("Prioriza recursos para jogos e apps pesados.", color = TextMuted, fontSize = 12.sp)
                            }
                            Switch(
                                checked = turboMode,
                                onCheckedChange = {
                                    turboMode = it
                                    statusMessage = if (it) "Modo Turbo ATIVADO." else "Modo Turbo desativado."
                                }
                            )
                        }

                        Spacer(Modifier.height(12.dp))
                        HorizontalDivider(color = Color.DarkGray)
                        Spacer(Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("JANELA FLUTUANTE DE FPS", color = Color.White, fontWeight = FontWeight.Bold)
                                Text(
                                    if (hasOverlayPerm) "Permissão ativa. Exiba ou oculte o contador."
                                    else "Requer permissão 'Sobrepor outros apps'.",
                                    color = if (hasOverlayPerm) EmeraldGreen else AlertRed,
                                    fontSize = 12.sp
                                )
                            }
                            Button(
                                onClick = {
                                    if (!hasOverlayPerm) {
                                        PermissionManagerHelper.openOverlayPermissionSettings(context)
                                    } else {
                                        val intent = Intent(context, FpsOverlayService::class.java)
                                        if (!overlayActive) {
                                            context.startService(intent)
                                            overlayActive = true
                                            statusMessage = "Janela flutuante de FPS iniciada."
                                        } else {
                                            context.stopService(intent)
                                            overlayActive = false
                                            statusMessage = "Janela flutuante de FPS encerrada."
                                        }
                                    }
                                }
                            ) {
                                Text(
                                    when {
                                        !hasOverlayPerm -> "Permitir"
                                        overlayActive -> "Ocultar"
                                        else -> "Mostrar FPS"
                                    }
                                )
                            }
                        }
                    }
                }

                1 -> {
                    FuturisticCard(accentColor) {
                        Text("CENTRAL DE PERMISSÕES", color = accentColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.height(10.dp))

                        Text("1. Sobrepor outros apps (Janela Flutuante)", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Status: ${if (hasOverlayPerm) "CONCEDIDA" else "PENDENTE"}",
                            color = if (hasOverlayPerm) EmeraldGreen else AlertRed,
                            fontSize = 12.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Button(onClick = { PermissionManagerHelper.openOverlayPermissionSettings(context) }) {
                            Text("Abrir Configuração de Sobreposição")
                        }

                        Spacer(Modifier.height(16.dp))
                        HorizontalDivider(color = Color.DarkGray)
                        Spacer(Modifier.height(16.dp))

                        Text("2. Acesso aos Arquivos e Armazenamento", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Status: ${if (hasFilesPerm) "CONCEDIDA" else "PENDENTE"}",
                            color = if (hasFilesPerm) EmeraldGreen else AlertRed,
                            fontSize = 12.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Button(onClick = { PermissionManagerHelper.openAllFilesAccessSettings(context) }) {
                            Text("Abrir Acesso aos Arquivos")
                        }
                    }
                }

                2 -> {
                    FuturisticCard(accentColor) {
                        Text("PERSONALIZAR ÍCONE DO APP", color = accentColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Escolha o estilo visual ativo no app:", color = TextMuted, fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))

                        listOf("Neon Ciano", "Plasma Roxo", "Esmeralda Stealth").forEach { style ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable { selectedIconStyle = style },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedIconStyle == style,
                                    onClick = { selectedIconStyle = style }
                                )
                                Text(style, color = Color.White)
                            }
                        }

                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Para usar a sua própria imagem no APK compilado: coloque o PNG em app/src/main/res/mipmap-*/ic_launcher.png antes de compilar.",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }
                }

                3 -> {
                    FuturisticCard(accentColor) {
                        Text("CRÉDITOS & SOBRE", color = accentColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Aplicativo: NEXUS Optimize", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Versão: 1.0.0", color = TextMuted, fontSize = 13.sp)
                        Text("Arquitetura: Kotlin + Jetpack Compose + Overlay Service", color = TextMuted, fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))
                        Text("Projeto estruturado para compilação Android com suporte a janela flutuante de FPS, permissões e personalização.", color = Color.White, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun FuturisticCard(accent: Color, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        color = CardDark,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), content = content)
    }
}
