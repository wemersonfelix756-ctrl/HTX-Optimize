# NEXUS Optimize APK (Compatível com Android Forge / Projetos Groovy)

Estrutura baseada no padrão do seu projeto (`HTX_Optimize_...`):
- `.github/workflows/build-apk.yml`
- `app/`
- `build.gradle`
- `gradle.properties`
- `README.md`
- `settings.gradle`

## Como usar no Android Forge / compilador Android
1. Extraia o arquivo `.zip` na pasta de projetos / Download do aparelho.
2. Abra a pasta `NEXUS_Optimize_APK` no **Android Forge** (ou no seu ambiente de compilação Android).
3. **Ícone personalizado:** Coloque sua imagem `.png` nas pastas `app/src/main/res/mipmap-*/ic_launcher.png` (ou `ic_launcher_round.png`) antes de compilar.
4. Compile o projeto para gerar o `.apk`.
