package com.htx.optimize.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import com.htx.optimize.R;
import java.util.Locale;

public class ArcGaugeView extends View {

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint subTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arcRect = new RectF();

    private float currentPercent = 0f;
    private String centerLabel = "RAM";

    public ArcGaugeView(Context context) {
        super(context);
        init(context);
    }

    public ArcGaugeView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        float stroke = dp(12f);

        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setStrokeWidth(stroke);
        trackPaint.setColor(ContextCompat.getColor(context, R.color.htx_glow_soft));

        progressPaint.setStyle(Paint.Style.STROKE);
        progressPaint.setStrokeWidth(stroke);
        progressPaint.setStrokeCap(Paint.Cap.ROUND);
        progressPaint.setColor(ContextCompat.getColor(context, R.color.htx_neon_purple));

        textPaint.setColor(ContextCompat.getColor(context, R.color.htx_text_primary));
        textPaint.setTextSize(sp(24f));
        textPaint.setFakeBoldText(true);
        textPaint.setTextAlign(Paint.Align.CENTER);

        subTextPaint.setColor(ContextCompat.getColor(context, R.color.htx_text_secondary));
        subTextPaint.setTextSize(sp(11f));
        subTextPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setProgressAnimated(int targetPercent, String label) {
        this.centerLabel = label;
        int clamped = Math.max(0, Math.min(100, targetPercent));
        ValueAnimator animator = ValueAnimator.ofFloat(currentPercent, clamped);
        animator.setDuration(550);
        animator.addUpdateListener(anim -> {
            currentPercent = (float) anim.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float pad = dp(14f);
        float size = Math.min(getWidth(), getHeight()) - pad * 2f;
        float left = (getWidth() - size) / 2f;
        float top = (getHeight() - size) / 2f;
        arcRect.set(left, top, left + size, top + size);

        canvas.drawArc(arcRect, 135f, 270f, false, trackPaint);
        float sweep = 270f * (currentPercent / 100f);
        canvas.drawArc(arcRect, 135f, sweep, false, progressPaint);

        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        canvas.drawText(String.format(Locale.US, "%.0f%%", currentPercent), cx, cy + dp(4f), textPaint);
        canvas.drawText(centerLabel, cx, cy + dp(22f), subTextPaint);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private float sp(float v) {
        return v * getResources().getDisplayMetrics().scaledDensity;
    }
}
