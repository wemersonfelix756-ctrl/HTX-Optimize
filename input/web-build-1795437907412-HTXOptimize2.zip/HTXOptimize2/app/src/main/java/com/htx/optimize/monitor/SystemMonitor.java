package com.htx.optimize.monitor;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import java.io.File;

public final class SystemMonitor {

    public static final class RamSnapshot {
        public final long totalBytes;
        public final long availBytes;
        public final long usedBytes;
        public final int usedPercent;
        public final boolean lowMemory;
        public final long thresholdBytes;

        public RamSnapshot(long totalBytes, long availBytes, boolean lowMemory, long thresholdBytes) {
            this.totalBytes = Math.max(0L, totalBytes);
            this.availBytes = Math.max(0L, availBytes);
            this.usedBytes = this.totalBytes >= this.availBytes ? (this.totalBytes - this.availBytes) : 0L;
            this.usedPercent = this.totalBytes > 0L
                    ? (int) Math.min(100L, Math.max(0L, (this.usedBytes * 100L) / this.totalBytes))
                    : 0;
            this.lowMemory = lowMemory;
            this.thresholdBytes = Math.max(0L, thresholdBytes);
        }
    }

    public static final class StorageSnapshot {
        public final long totalBytes;
        public final long freeBytes;
        public final long usedBytes;
        public final int usedPercent;

        public StorageSnapshot(long totalBytes, long freeBytes) {
            this.totalBytes = Math.max(0L, totalBytes);
            this.freeBytes = Math.max(0L, freeBytes);
            this.usedBytes = this.totalBytes >= this.freeBytes ? (this.totalBytes - this.freeBytes) : 0L;
            this.usedPercent = this.totalBytes > 0L
                    ? (int) Math.min(100L, Math.max(0L, (this.usedBytes * 100L) / this.totalBytes))
                    : 0;
        }
    }

    public static final class BatterySnapshot {
        public final int levelPercent;
        public final Float temperatureCelsius;
        public final int voltageMv;
        public final String statusText;
        public final String healthText;
        public final String technology;

        public BatterySnapshot(int levelPercent, Float temperatureCelsius, int voltageMv,
                               String statusText, String healthText, String technology) {
            this.levelPercent = levelPercent;
            this.temperatureCelsius = temperatureCelsius;
            this.voltageMv = voltageMv;
            this.statusText = statusText;
            this.healthText = healthText;
            this.technology = technology;
        }
    }

    private SystemMonitor() {
    }

    public static String getDeviceModel() {
        String manufacturer = Build.MANUFACTURER != null ? Build.MANUFACTURER.trim() : "";
        String model = Build.MODEL != null ? Build.MODEL.trim() : "Dispositivo Android";
        if (!manufacturer.isEmpty() && !model.toLowerCase().startsWith(manufacturer.toLowerCase())) {
            return manufacturer.toUpperCase() + " " + model;
        }
        return model;
    }

    public static String getAndroidVersionSummary() {
        String release = Build.VERSION.RELEASE != null ? Build.VERSION.RELEASE : "Desconhecida";
        return "Android " + release + " (API " + Build.VERSION.SDK_INT + ")";
    }

    public static RamSnapshot readRam(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (am == null) {
            return new RamSnapshot(0L, 0L, false, 0L);
        }
        ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(info);
        long total = info.totalMem;
        long avail = info.availMem;
        return new RamSnapshot(total, avail, info.lowMemory, info.threshold);
    }

    public static StorageSnapshot readInternalStorage() {
        File dataDir = Environment.getDataDirectory();
        StatFs statFs = new StatFs(dataDir.getAbsolutePath());
        long blockSize = statFs.getBlockSizeLong();
        long totalBlocks = statFs.getBlockCountLong();
        long availableBlocks = statFs.getAvailableBlocksLong();
        return new StorageSnapshot(totalBlocks * blockSize, availableBlocks * blockSize);
    }

    public static BatterySnapshot readBattery(Context context) {
        Intent intent = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (intent == null) {
            return new BatterySnapshot(-1, null, -1, "Indisponível", "Desconhecida", "N/D");
        }
        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int pct = (level >= 0 && scale > 0) ? (level * 100) / scale : -1;

        int tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
        Float tempC = (tempTenths != Integer.MIN_VALUE && tempTenths > 0) ? (tempTenths / 10.0f) : null;

        int voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
        int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN);
        int health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN);
        String tech = intent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
        if (tech == null || tech.trim().isEmpty()) {
            tech = "N/D";
        }

        return new BatterySnapshot(pct, tempC, voltage, mapBatteryStatus(status), mapBatteryHealth(health), tech);
    }

    private static String mapBatteryStatus(int status) {
        switch (status) {
            case BatteryManager.BATTERY_STATUS_CHARGING:
                return "Carregando";
            case BatteryManager.BATTERY_STATUS_DISCHARGING:
                return "Descarregando";
            case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                return "Sem carregar";
            case BatteryManager.BATTERY_STATUS_FULL:
                return "Completa";
            default:
                return "Desconhecido";
        }
    }

    private static String mapBatteryHealth(int health) {
        switch (health) {
            case BatteryManager.BATTERY_HEALTH_GOOD:
                return "Boa";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                return "Superaquecimento";
            case BatteryManager.BATTERY_HEALTH_DEAD:
                return "Esgotada";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                return "Sobretensão";
            case BatteryManager.BATTERY_HEALTH_COLD:
                return "Fria";
            default:
                return "Desconhecida";
        }
    }
}
