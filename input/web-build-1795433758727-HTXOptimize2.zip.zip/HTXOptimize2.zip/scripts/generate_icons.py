from pathlib import Path
from PIL import Image

SOURCE = Path("assets/icon_source.jpg")
RES_DIR = Path("app/src/main/res")

MIPMAP_SIZES = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}

def main():
    if not SOURCE.exists():
        raise FileNotFoundError("Coloque a imagem oficial em assets/icon_source.jpg antes de gerar os mipmaps.")

    base = Image.open(SOURCE).convert("RGBA")
    side = min(base.width, base.height)
    left = (base.width - side) // 2
    top = (base.height - side) // 2
    square = base.crop((left, top, left + side, top + side))

    for folder, px in MIPMAP_SIZES.items():
        out_dir = RES_DIR / folder
        out_dir.mkdir(parents=True, exist_ok=True)
        resized = square.resize((px, px), Image.Resampling.LANCZOS)
        resized.save(out_dir / "ic_launcher.png", "PNG")
        resized.save(out_dir / "ic_launcher_round.png", "PNG")

    fg_dir = RES_DIR / "mipmap-xxxhdpi"
    fg_dir.mkdir(parents=True, exist_ok=True)
    square.resize((432, 432), Image.Resampling.LANCZOS).save(fg_dir / "ic_launcher_foreground.png", "PNG")

if __name__ == "__main__":
    main()
