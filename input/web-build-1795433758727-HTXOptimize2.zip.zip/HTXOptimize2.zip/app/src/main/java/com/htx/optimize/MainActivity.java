package com.htx.optimize;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.htx.optimize.fragments.AboutFragment;
import com.htx.optimize.fragments.HomeFragment;
import com.htx.optimize.fragments.RamBoosterFragment;
import com.htx.optimize.fragments.RamCleanerFragment;
import com.htx.optimize.fragments.StorageFragment;
import com.htx.optimize.fragments.ToolsFragment;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigation = findViewById(R.id.bottom_navigation);
        bottomNavigation.setOnItemSelectedListener(item -> {
            Fragment target = createFragmentForId(item.getItemId());
            switchFragment(target);
            return true;
        });

        if (savedInstanceState == null) {
            bottomNavigation.setSelectedItemId(R.id.nav_home);
        }
    }

    public void selectTab(int menuItemId) {
        bottomNavigation.setSelectedItemId(menuItemId);
    }

    private Fragment createFragmentForId(int id) {
        if (id == R.id.nav_ram_cleaner) {
            return new RamCleanerFragment();
        } else if (id == R.id.nav_ram_booster) {
            return new RamBoosterFragment();
        } else if (id == R.id.nav_storage) {
            return new StorageFragment();
        } else if (id == R.id.nav_tools) {
            return new ToolsFragment();
        } else if (id == R.id.nav_about) {
            return new AboutFragment();
        }
        return new HomeFragment();
    }

    private void switchFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .setCustomAnimations(
                        android.R.anim.fade_in,
                        android.R.anim.fade_out
                )
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}
