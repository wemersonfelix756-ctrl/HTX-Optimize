package com.htx.optimize.files;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Random;

final class TestUtil {
    private TestUtil() { }

    static File tempDir() throws IOException {
        File dir = Files.createTempDirectory("htx_test").toFile();
        dir.deleteOnExit();
        return dir;
    }

    static File write(File file, byte[] data) throws IOException {
        File parent = file.getParentFile();
        if (parent != null) parent.mkdirs();
        try (FileOutputStream out = new FileOutputStream(file)) { out.write(data); }
        return file;
    }

    static byte[] randomBytes(int size, long seed) {
        byte[] data = new byte[size];
        new Random(seed).nextBytes(data);
        return data;
    }

    static byte[] read(File file) throws IOException {
        return Files.readAllBytes(file.toPath());
    }
}
