package com.htx.optimize.files;

import static org.junit.Assert.*;

import com.htx.optimize.util.DangerousCommands;
import java.io.File;
import com.htx.optimize.util.ShellRunner;
import org.junit.Test;

public class ShellRunnerTest {

    @Test public void capturesOutputAndExitCode() {
        ShellRunner.Result r = new ShellRunner().run("echo ola; echo erro 1>&2; exit 3", null, 5000);
        assertTrue(r.output.contains("ola"));
        assertTrue(r.output.contains("erro"));
        assertEquals(3, r.exitCode);
        assertFalse(r.timedOut);
    }

    @Test public void timeoutKillsLongCommand() {
        long start = System.currentTimeMillis();
        ShellRunner.Result r = new ShellRunner().run("echo inicio; sleep 20", null, 700);
        assertTrue(r.timedOut);
        assertTrue(r.output.contains("inicio"));
        assertTrue(System.currentTimeMillis() - start < 5000);
    }

    @Test public void cancelStopsCommand() throws Exception {
        final ShellRunner runner = new ShellRunner();
        Thread t = new Thread(new Runnable() { @Override public void run() { try { Thread.sleep(300); } catch (InterruptedException e) { return; } runner.cancel(); } });
        t.start();
        ShellRunner.Result r = runner.run("sleep 20", null, 0);
        assertTrue(r.cancelled);
    }

    @Test public void usesWorkingDirectory() throws Exception {
        File dir = TestUtil.tempDir();
        ShellRunner.Result r = new ShellRunner().run("pwd", dir.getAbsolutePath(), 3000);
        assertTrue(r.output.trim().endsWith(dir.getName()));
    }

    @Test public void encodeDecodeRoundTrip() {
        ShellRunner.Result r = ShellRunner.decode(ShellRunner.encode(new ShellRunner.Result("saida\nlinha2\n", 7, true, false)));
        assertEquals("saida\nlinha2\n", r.output);
        assertEquals(7, r.exitCode);
        assertTrue(r.timedOut);
        assertFalse(r.cancelled);
    }

    @Test public void dangerousCommandDetection() {
        assertTrue(DangerousCommands.isDangerous("rm -rf /"));
        assertTrue(DangerousCommands.isDangerous("rm -rf /sdcard/*"));
        assertTrue(DangerousCommands.isDangerous("rm -fr /data"));
        assertTrue(DangerousCommands.isDangerous("dd if=/dev/zero of=/dev/block/sda"));
        assertTrue(DangerousCommands.isDangerous("mkfs.ext4 /dev/sda1"));
        assertFalse(DangerousCommands.isDangerous("rm -rf /sdcard/Download/teste"));
        assertFalse(DangerousCommands.isDangerous("ls -la /sdcard"));
        assertFalse(DangerousCommands.isDangerous("pm list packages -3"));
        assertFalse(DangerousCommands.isDangerous("am force-stop com.example.app"));
    }

}
