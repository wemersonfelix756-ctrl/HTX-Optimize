package com.htx.optimize.files;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.junit.Test;

public class ArchiveUtilsTest {

    private static File sample(File root) throws IOException {
        File src = new File(root, "projeto");
        TestUtil.write(new File(src, "leia.txt"), "olá mundo".getBytes("UTF-8"));
        TestUtil.write(new File(src, "dados/grande.bin"), TestUtil.randomBytes(300_000, 7));
        TestUtil.write(new File(src, "dados/profundo/a/b/c/arquivo com espaço.txt"), "x".getBytes());
        new File(src, "vazia").mkdirs();
        return src;
    }

    private static void roundTrip(ArchiveUtils.Format format, String archiveName) throws Exception {
        File root = TestUtil.tempDir();
        File src = sample(root);
        File archive = new File(root, archiveName);
        ArchiveUtils.compress(Collections.singletonList(src), archive, format, 6, null, null);
        assertTrue(archive.length() > 0);

        List<ArchiveUtils.Entry> entries = ArchiveUtils.list(archive);
        boolean sawBig = false;
        for (ArchiveUtils.Entry e : entries) if (e.path.equals("projeto/dados/grande.bin")) sawBig = true;
        assertTrue("lista deve conter grande.bin: " + entries.size(), sawBig);

        File out = new File(root, "out");
        ArchiveUtils.extract(archive, out, null, null, null);
        assertArrayEquals(TestUtil.read(new File(src, "dados/grande.bin")),
                TestUtil.read(new File(out, "projeto/dados/grande.bin")));
        assertEquals("olá mundo", new String(TestUtil.read(new File(out, "projeto/leia.txt")), "UTF-8"));
        assertTrue(new File(out, "projeto/vazia").isDirectory());
        assertTrue(new File(out, "projeto/dados/profundo/a/b/c/arquivo com espaço.txt").exists());

        // extração parcial (só uma pasta)
        File partial = new File(root, "partial");
        Set<String> only = new HashSet<>(Arrays.asList("projeto/dados/profundo"));
        ArchiveUtils.extract(archive, partial, only, null, null);
        assertTrue(new File(partial, "projeto/dados/profundo/a/b/c/arquivo com espaço.txt").exists());
        assertFalse(new File(partial, "projeto/leia.txt").exists());
    }

    @Test public void zipRoundTrip() throws Exception { roundTrip(ArchiveUtils.Format.ZIP, "p.zip"); }

    @Test public void tarRoundTrip() throws Exception { roundTrip(ArchiveUtils.Format.TAR, "p.tar"); }

    @Test public void tarGzRoundTrip() throws Exception { roundTrip(ArchiveUtils.Format.TAR_GZ, "p.tar.gz"); }

    @Test public void gzSingleFile() throws Exception {
        File root = TestUtil.tempDir();
        File f = TestUtil.write(new File(root, "log.txt"), TestUtil.randomBytes(50_000, 3));
        File gz = new File(root, "log.txt.gz");
        ArchiveUtils.compress(Collections.singletonList(f), gz, ArchiveUtils.Format.GZ, 9, null, null);
        File out = new File(root, "o");
        ArchiveUtils.extract(gz, out, null, null, null);
        assertArrayEquals(TestUtil.read(f), TestUtil.read(new File(out, "log.txt")));
    }

    @Test public void tarHandlesVeryLongPaths() throws Exception {
        File root = TestUtil.tempDir();
        StringBuilder deep = new StringBuilder("raiz");
        for (int i = 0; i < 12; i++) deep.append("/pasta_com_nome_bem_comprido_").append(i);
        File file = TestUtil.write(new File(root, deep + "/final.txt"), "ok".getBytes());
        File tar = new File(root, "long.tar");
        ArchiveUtils.compress(Collections.singletonList(new File(root, "raiz")), tar, ArchiveUtils.Format.TAR, 0, null, null);
        File out = new File(root, "out");
        ArchiveUtils.extract(tar, out, null, null, null);
        assertEquals("ok", new String(TestUtil.read(new File(out, deep + "/final.txt"))));
        assertTrue(file.exists());
    }

    @Test public void zipSlipIsBlocked() throws Exception {
        File root = TestUtil.tempDir();
        File zip = new File(root, "evil.zip");
        try (java.util.zip.ZipOutputStream z = new java.util.zip.ZipOutputStream(new java.io.FileOutputStream(zip))) {
            z.putNextEntry(new java.util.zip.ZipEntry("../escapou.txt"));
            z.write("x".getBytes());
            z.closeEntry();
        }
        File out = new File(root, "out");
        try {
            ArchiveUtils.extract(zip, out, null, null, null);
            fail("deveria bloquear");
        } catch (IOException expected) {
            assertTrue(expected.getMessage().contains("insegura"));
        }
        assertFalse(new File(root, "escapou.txt").exists());
    }

    @Test public void detectsFormatsAndBaseNames() {
        assertEquals(ArchiveUtils.Format.TAR_GZ, ArchiveUtils.detect("a.TAR.GZ"));
        assertEquals(ArchiveUtils.Format.TAR_GZ, ArchiveUtils.detect("a.tgz"));
        assertEquals(ArchiveUtils.Format.SEVEN_Z, ArchiveUtils.detect("a.7z"));
        assertEquals(ArchiveUtils.Format.RAR, ArchiveUtils.detect("a.rar"));
        assertEquals(ArchiveUtils.Format.NONE, ArchiveUtils.detect("a.txt"));
        assertEquals("backup", ArchiveUtils.baseName("backup.tar.gz"));
        assertEquals("fotos", ArchiveUtils.baseName("fotos.zip"));
    }

    @Test public void cancelRemovesPartialArchive() throws Exception {
        File root = TestUtil.tempDir();
        File src = TestUtil.write(new File(root, "grande/a.bin"), TestUtil.randomBytes(2_000_000, 5));
        File zip = new File(root, "x.zip");
        final FileOps.Control control = new FileOps.Control();
        try {
            ArchiveUtils.compress(Collections.singletonList(src.getParentFile()), zip, ArchiveUtils.Format.ZIP, 6,
                    new FileOps.Progress() {
                        @Override public void onProgress(String current, long done, long total) { control.cancel(); }
                    }, control);
            fail("deveria cancelar");
        } catch (FileOps.CancelledException expected) {
            assertFalse(zip.exists());
        }
    }
}
