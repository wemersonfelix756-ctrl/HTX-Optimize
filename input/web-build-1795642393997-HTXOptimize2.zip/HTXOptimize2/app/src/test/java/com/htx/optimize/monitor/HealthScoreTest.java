package com.htx.optimize.monitor;

import static org.junit.Assert.*;

import org.junit.Test;

public class HealthScoreTest {

    @Test public void healthyDeviceScoresHigh() {
        HealthScore.Result r = HealthScore.compute(40, 50, 35f, 80, false);
        assertEquals(100, r.score);
        assertEquals("EXCELENTE", r.label);
    }

    @Test public void ramPressureLowersScoreAndHints() {
        HealthScore.Result r = HealthScore.compute(95, 50, 35f, 80, true);
        assertTrue(r.score < 70);
        assertTrue(r.hint.contains("RAM Booster"));
    }

    @Test public void hotDeviceHintsCooling() {
        HealthScore.Result r = HealthScore.compute(40, 50, 58f, 80, false);
        assertTrue(r.hint.toLowerCase().contains("quente"));
        assertTrue(r.score < 80);
    }

    @Test public void unavailableSensorsDoNotPenalize() {
        HealthScore.Result r = HealthScore.compute(40, 50, Float.NaN, -1, false);
        assertEquals(100, r.score);
    }

    @Test public void scoreIsClamped() {
        HealthScore.Result r = HealthScore.compute(100, 100, 120f, 0, true);
        assertTrue(r.score >= 0 && r.score <= 100);
        assertEquals("CRÍTICO", r.label);
    }
}
