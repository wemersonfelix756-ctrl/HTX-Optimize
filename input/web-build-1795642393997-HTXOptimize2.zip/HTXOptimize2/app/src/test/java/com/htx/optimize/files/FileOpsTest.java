package com.htx.optimize.files;

import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.util.List;
import org.junit.Test;

public class FileOpsTest {

    @Test public void copyFolderRecursively() throws Exception {
        File root = TestUtil.tempDir();
        File src = new File(root, "src");
        TestUtil.write(new File(src, "a.txt"), "hello".getBytes());
        TestUtil.write(new File(src, "sub/b.bin"), TestUtil.randomBytes(200_000, 1));
        File dest = new File(root, "dest");
        dest.mkdirs();
        File copy = FileOps.copy(src, dest, null, null);
        assertEquals("src", copy.getName());
        assertArrayEquals(TestUtil.read(new File(src, "sub/b.bin")), TestUtil.read(new File(copy, "sub/b.bin")));
    }

    @Test public void copyRefusesIntoItself() throws Exception {
        File root = TestUtil.tempDir();
        File src = new File(root, "src");
        new File(src, "inner").mkdirs();
        try {
            FileOps.copy(src, new File(src, "inner"), null, null);
            fail("deveria recusar");
        } catch (IOException expected) {
            assertTrue(expected.getMessage().contains("dentro dela mesma"));
        }
    }

    @Test public void uniqueNameKeepsExtension() throws Exception {
        File root = TestUtil.tempDir();
        TestUtil.write(new File(root, "foto.jpg"), new byte[1]);
        TestUtil.write(new File(root, "foto (1).jpg"), new byte[1]);
        assertEquals("foto (2).jpg", FileOps.uniqueName(root, "foto.jpg").getName());
        TestUtil.write(new File(root, "bk.tar.gz"), new byte[1]);
        assertEquals("bk (1).tar.gz", FileOps.uniqueName(root, "bk.tar.gz").getName());
    }

    @Test public void moveAcrossFolders() throws Exception {
        File root = TestUtil.tempDir();
        File file = TestUtil.write(new File(root, "x/a.txt"), "dados".getBytes());
        File dest = new File(root, "y");
        dest.mkdirs();
        File moved = FileOps.move(file, dest, null, null);
        assertFalse(file.exists());
        assertEquals("dados", new String(TestUtil.read(moved)));
    }

    @Test public void deleteRecursively() throws Exception {
        File root = TestUtil.tempDir();
        File dir = new File(root, "d");
        TestUtil.write(new File(dir, "a/b/c.txt"), new byte[10]);
        FileOps.delete(dir, null);
        assertFalse(dir.exists());
    }

    @Test public void renameValidatesNames() throws Exception {
        File root = TestUtil.tempDir();
        File a = TestUtil.write(new File(root, "a.txt"), new byte[1]);
        TestUtil.write(new File(root, "b.txt"), new byte[1]);
        try { FileOps.rename(a, "b.txt"); fail(); } catch (IOException expected) { /* ok */ }
        try { FileOps.rename(a, "x/y"); fail(); } catch (IOException expected) { /* ok */ }
        assertEquals("c.txt", FileOps.rename(a, "c.txt").getName());
    }

    @Test public void sortFoldersFirstAndBySize() throws Exception {
        File root = TestUtil.tempDir();
        new File(root, "zeta").mkdirs();
        TestUtil.write(new File(root, "big.bin"), new byte[500]);
        TestUtil.write(new File(root, "small.bin"), new byte[5]);
        TestUtil.write(new File(root, ".hidden"), new byte[1]);
        List<File> bySize = FileOps.listSorted(root, false, FileOps.SortKey.SIZE, false);
        assertEquals("zeta", bySize.get(0).getName());
        assertEquals("big.bin", bySize.get(1).getName());
        assertEquals(3, bySize.size());
        assertEquals(4, FileOps.listSorted(root, true, FileOps.SortKey.NAME, true).size());
    }

    @Test public void searchFindsNestedMatches() throws Exception {
        File root = TestUtil.tempDir();
        TestUtil.write(new File(root, "a/b/Relatorio_Final.pdf"), new byte[1]);
        TestUtil.write(new File(root, "c/outro.txt"), new byte[1]);
        List<File> hits = FileOps.search(root, "relatorio", 50, false, null);
        assertEquals(1, hits.size());
    }

    @Test public void hashMatchesKnownValue() throws Exception {
        File root = TestUtil.tempDir();
        File f = TestUtil.write(new File(root, "h.txt"), "abc".getBytes());
        assertEquals("900150983cd24fb0d6963f7d28e17f72", FileOps.hash(f, "MD5", null));
    }

    @Test public void cancelStopsCopyAndCleansUp() throws Exception {
        File root = TestUtil.tempDir();
        File src = TestUtil.write(new File(root, "big.bin"), TestUtil.randomBytes(3_000_000, 2));
        File dest = new File(root, "dest");
        dest.mkdirs();
        final FileOps.Control control = new FileOps.Control();
        try {
            FileOps.copy(src, dest, new FileOps.Progress() {
                @Override public void onProgress(String current, long done, long total) { control.cancel(); }
            }, control);
            fail("deveria cancelar");
        } catch (FileOps.CancelledException expected) {
            assertEquals(0, dest.list().length);
        }
    }

    @Test public void largestFilesAreOrderedAndSkipSmallOnes() throws Exception {
        File root = TestUtil.tempDir();
        TestUtil.write(new File(root, "a/grande.bin"), new byte[3000]);
        TestUtil.write(new File(root, "b/medio.bin"), new byte[2000]);
        TestUtil.write(new File(root, "c/d/pequeno.bin"), new byte[10]);
        TestUtil.write(new File(root, "Android/ignorado.bin"), new byte[9000]);
        TestUtil.write(new File(root, "topo.bin"), new byte[2500]);
        List<File> top = FileOps.largestFiles(root, 2, 1000, null);
        assertEquals(2, top.size());
        assertEquals("grande.bin", top.get(0).getName());
        assertEquals("topo.bin", top.get(1).getName());
        assertEquals(3, FileOps.largestFiles(root, 10, 1000, null).size());
    }
}
