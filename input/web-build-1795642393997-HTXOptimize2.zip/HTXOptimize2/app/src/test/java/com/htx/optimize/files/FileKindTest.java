package com.htx.optimize.files;

import static org.junit.Assert.*;

import org.junit.Test;

public class FileKindTest {
    @Test public void classifiesByExtension() {
        assertEquals(FileKind.FOLDER, FileKind.of("x", true));
        assertEquals(FileKind.ARCHIVE, FileKind.of("a.tar.gz", false));
        assertEquals(FileKind.ARCHIVE, FileKind.of("a.RAR", false));
        assertEquals(FileKind.APK, FileKind.of("app.apk", false));
        assertEquals(FileKind.IMAGE, FileKind.of("f.JPG", false));
        assertEquals(FileKind.VIDEO, FileKind.of("v.mkv", false));
        assertEquals(FileKind.AUDIO, FileKind.of("m.flac", false));
        assertEquals(FileKind.SCRIPT, FileKind.of("run.sh", false));
        assertEquals(FileKind.TEXT, FileKind.of("notas.txt", false));
        assertEquals(FileKind.PDF, FileKind.of("doc.pdf", false));
        assertEquals(FileKind.OTHER, FileKind.of("semextensao", false));
    }
}
