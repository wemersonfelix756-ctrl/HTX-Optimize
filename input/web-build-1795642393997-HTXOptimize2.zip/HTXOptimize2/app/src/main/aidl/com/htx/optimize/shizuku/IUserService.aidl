package com.htx.optimize.shizuku;

interface IUserService {
    // Código reservado pelo Shizuku para encerrar o serviço.
    void destroy() = 16777114;

    // Executa "sh -c <command>" (limite de 20 s) e devolve a saída (stdout+stderr).
    String exec(String command) = 1;

    // Terminal: executa com pasta atual e tempo limite (0 = sem limite). A resposta termina com
    // o marcador de código de saída decodificado por ShellRunner.decode().
    String execWithTimeout(String command, String cwd, long timeoutMs) = 2;

    // Cancela o comando do terminal em andamento.
    void cancel() = 3;
}
