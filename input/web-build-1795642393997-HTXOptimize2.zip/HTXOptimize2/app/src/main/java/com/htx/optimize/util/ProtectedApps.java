package com.htx.optimize.util;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Apps que a otimização nunca deve encerrar (escolhidos pelo usuário). */
public final class ProtectedApps {

    public static final class Entry {
        public final String label;
        public final String pkg;

        Entry(String label, String pkg) {
            this.label = label;
            this.pkg = pkg;
        }
    }

    private static final String KEY = "protected_apps";

    private ProtectedApps() { }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("htx_prefs", Context.MODE_PRIVATE);
    }

    public static Set<String> get(Context c) {
        return new HashSet<>(prefs(c).getStringSet(KEY, Collections.<String>emptySet()));
    }

    public static void set(Context c, Set<String> packages) {
        prefs(c).edit().putStringSet(KEY, new HashSet<>(packages)).apply();
    }

    /** Apps com ícone no launcher, em ordem alfabética (exceto o próprio HTX). Bloqueante. */
    public static List<Entry> launchableApps(Context c) {
        PackageManager pm = c.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> infos;
        try {
            infos = pm.queryIntentActivities(main, 0);
        } catch (RuntimeException exception) {
            return new ArrayList<>();
        }
        Set<String> seen = new HashSet<>();
        List<Entry> result = new ArrayList<>();
        for (ResolveInfo info : infos) {
            if (info.activityInfo == null) continue;
            String pkg = info.activityInfo.packageName;
            if (pkg == null || pkg.equals(c.getPackageName()) || !seen.add(pkg)) continue;
            CharSequence label = info.loadLabel(pm);
            result.add(new Entry(label == null ? pkg : label.toString(), pkg));
        }
        Collections.sort(result, (a, b) -> a.label.toLowerCase(Locale.ROOT).compareTo(b.label.toLowerCase(Locale.ROOT)));
        return result;
    }
}
