package com.htx.optimize.files;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * 7Z (Apache Commons Compress + XZ) e RAR (junrar) acessados por reflexão: se a biblioteca ou o
 * Android não suportar algo, aparece uma mensagem de erro em vez de quebrar o app.
 */
final class ExternalArchives {

    private static final String SEVENZ_FILE = "org.apache.commons.compress.archivers.sevenz.SevenZFile";
    private static final String SEVENZ_OUT = "org.apache.commons.compress.archivers.sevenz.SevenZOutputFile";
    private static final String ARCHIVE_ENTRY = "org.apache.commons.compress.archivers.ArchiveEntry";
    private static final String JUNRAR = "com.github.junrar.Junrar";
    private static final String RAR_ARCHIVE = "com.github.junrar.Archive";

    private ExternalArchives() { }

    private static Object call(Object target, String method) throws ReflectiveOperationException {
        return target.getClass().getMethod(method).invoke(target);
    }

    private static IOException wrap(String what, Throwable error) {
        Throwable cause = error instanceof InvocationTargetException && error.getCause() != null ? error.getCause() : error;
        if (cause instanceof IOException) return (IOException) cause;
        String detail = cause.getMessage() != null ? cause.getMessage() : cause.getClass().getSimpleName();
        if (cause instanceof ClassNotFoundException || cause instanceof NoClassDefFoundError) {
            detail = "biblioteca ausente";
        } else if (cause instanceof NoSuchMethodError || cause instanceof UnsupportedOperationException) {
            detail = "recurso exige Android mais novo";
        }
        return new IOException(what + ": " + detail);
    }

    private static void closeQuietly(Object target) {
        if (target == null) return;
        try {
            target.getClass().getMethod("close").invoke(target);
        } catch (Exception | LinkageError ignored) {
            // melhor esforço
        }
    }

    // ------------------------------------------------------------------ 7Z

    static List<ArchiveUtils.Entry> list7z(File file) throws IOException {
        List<ArchiveUtils.Entry> result = new ArrayList<>();
        Object sz = null;
        try {
            Class<?> cls = Class.forName(SEVENZ_FILE);
            sz = cls.getConstructor(File.class).newInstance(file);
            Method next = cls.getMethod("getNextEntry");
            Object entry;
            while ((entry = next.invoke(sz)) != null) {
                String path = ArchiveUtils.normalize((String) call(entry, "getName"));
                boolean dir = (Boolean) call(entry, "isDirectory");
                long size = (Long) call(entry, "getSize");
                if (!path.isEmpty()) result.add(new ArchiveUtils.Entry(path, dir, dir ? 0L : size, 0L));
            }
            return result;
        } catch (ReflectiveOperationException | LinkageError | RuntimeException error) {
            throw wrap("Não foi possível abrir o 7z", error);
        } finally {
            closeQuietly(sz);
        }
    }

    static void extract7z(File file, File dest, Set<String> only, FileOps.Progress p, FileOps.Control c) throws IOException {
        Object sz = null;
        try {
            Class<?> cls = Class.forName(SEVENZ_FILE);
            sz = cls.getConstructor(File.class).newInstance(file);
            Method next = cls.getMethod("getNextEntry");
            Method read = cls.getMethod("read", byte[].class);
            ArchiveUtils.Progress counter = new ArchiveUtils.Progress(0L, p);
            byte[] buffer = new byte[64 * 1024];
            Object entry;
            while ((entry = next.invoke(sz)) != null) {
                c.check();
                String path = ArchiveUtils.normalize((String) call(entry, "getName"));
                boolean dir = (Boolean) call(entry, "isDirectory");
                if (path.isEmpty() || !ArchiveUtils.included(path, only)) continue;
                File out = ArchiveUtils.safeResolve(dest, path);
                if (dir) {
                    //noinspection ResultOfMethodCallIgnored
                    out.mkdirs();
                    continue;
                }
                ArchiveUtils.ensureParent(out);
                try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out))) {
                    int n;
                    while ((n = (Integer) read.invoke(sz, new Object[]{buffer})) > 0) {
                        c.check();
                        os.write(buffer, 0, n);
                        counter.add(path, n);
                    }
                }
            }
        } catch (ReflectiveOperationException | LinkageError | RuntimeException error) {
            throw wrap("Não foi possível extrair o 7z (senha ou formato incomum?)", error);
        } finally {
            closeQuietly(sz);
        }
    }

    static void compress7z(List<File> sources, File out, long total, FileOps.Progress p, FileOps.Control c) throws IOException {
        Object sz = null;
        try {
            Class<?> cls = Class.forName(SEVENZ_OUT);
            Class<?> entryType = Class.forName(ARCHIVE_ENTRY);
            sz = cls.getConstructor(File.class).newInstance(out);
            Method create = cls.getMethod("createArchiveEntry", File.class, String.class);
            Method put = cls.getMethod("putArchiveEntry", entryType);
            Method write = cls.getMethod("write", byte[].class, int.class, int.class);
            Method closeEntry = cls.getMethod("closeArchiveEntry");
            Method finish = cls.getMethod("finish");
            ArchiveUtils.Progress counter = new ArchiveUtils.Progress(total, p);
            for (File source : sources) add7z(sz, create, put, write, closeEntry, source, source.getName(), out, counter, c);
            finish.invoke(sz);
        } catch (ReflectiveOperationException | LinkageError | RuntimeException error) {
            throw wrap("Não foi possível criar o 7z", error);
        } finally {
            closeQuietly(sz);
        }
    }

    private static void add7z(Object sz, Method create, Method put, Method write, Method closeEntry, File file,
                              String name, File out, ArchiveUtils.Progress counter, FileOps.Control c)
            throws ReflectiveOperationException, IOException {
        c.check();
        if (file.equals(out) || FileOps.isSymlink(file)) return;
        String entryName = file.isDirectory() ? name + "/" : name;
        Object entry = create.invoke(sz, file, entryName);
        put.invoke(sz, entry);
        if (file.isDirectory()) {
            closeEntry.invoke(sz);
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    add7z(sz, create, put, write, closeEntry, child, name + "/" + child.getName(), out, counter, c);
                }
            }
        } else {
            try (InputStream in = new FileInputStream(file)) {
                byte[] buffer = new byte[64 * 1024];
                int n;
                while ((n = in.read(buffer)) > 0) {
                    c.check();
                    write.invoke(sz, buffer, 0, n);
                    counter.add(name, n);
                }
            }
            closeEntry.invoke(sz);
        }
    }

    // ------------------------------------------------------------------ RAR

    static List<ArchiveUtils.Entry> listRar(File file) throws IOException {
        List<ArchiveUtils.Entry> result = new ArrayList<>();
        Object archive = null;
        try {
            Class<?> cls = Class.forName(RAR_ARCHIVE);
            archive = cls.getConstructor(File.class).newInstance(file);
            List<?> headers = (List<?>) cls.getMethod("getFileHeaders").invoke(archive);
            for (Object header : headers) {
                String name;
                try {
                    name = (String) call(header, "getFileName");
                } catch (NoSuchMethodException missing) {
                    name = (String) call(header, "getFileNameString");
                }
                boolean dir = (Boolean) call(header, "isDirectory");
                long size = 0L;
                try {
                    size = ((Number) call(header, "getFullUnpackSize")).longValue();
                } catch (ReflectiveOperationException ignored) {
                    // tamanho desconhecido
                }
                String path = ArchiveUtils.normalize(name);
                if (!path.isEmpty()) result.add(new ArchiveUtils.Entry(path, dir, dir ? 0L : size, 0L));
            }
            return result;
        } catch (ReflectiveOperationException | LinkageError | RuntimeException error) {
            throw wrap("Não foi possível abrir o RAR", error);
        } finally {
            closeQuietly(archive);
        }
    }

    static void extractRar(File file, File dest, Set<String> only, FileOps.Progress p, FileOps.Control c) throws IOException {
        try {
            Method extract = Class.forName(JUNRAR).getMethod("extract", File.class, File.class);
            if (p != null) p.onProgress(file.getName(), 0L, 0L);
            if (only == null) {
                extract.invoke(null, file, dest);
                return;
            }
            // extração parcial: extrai tudo para uma pasta temporária e move só o pedido
            File temp = new File(dest, ".htx_rar_" + System.nanoTime());
            if (!temp.mkdirs()) throw new IOException("Não foi possível criar a pasta temporária.");
            try {
                extract.invoke(null, file, temp);
                moveSelected(temp, temp, dest, only, c);
            } finally {
                FileOps.deleteQuietly(temp);
            }
        } catch (ReflectiveOperationException | LinkageError | RuntimeException error) {
            throw wrap("Não foi possível extrair o RAR (senha ou formato incomum?)", error);
        }
    }

    private static void moveSelected(File root, File dir, File dest, Set<String> only, FileOps.Control c) throws IOException {
        File[] children = dir.listFiles();
        if (children == null) return;
        for (File child : children) {
            c.check();
            String rel = ArchiveUtils.normalize(child.getAbsolutePath().substring(root.getAbsolutePath().length()));
            if (child.isDirectory()) {
                moveSelected(root, child, dest, only, c);
            } else if (ArchiveUtils.included(rel, only)) {
                File out = ArchiveUtils.safeResolve(dest, rel);
                ArchiveUtils.ensureParent(out);
                if (!child.renameTo(out)) FileOps.copy(child, out.getParentFile(), null, c);
            }
        }
    }
}
