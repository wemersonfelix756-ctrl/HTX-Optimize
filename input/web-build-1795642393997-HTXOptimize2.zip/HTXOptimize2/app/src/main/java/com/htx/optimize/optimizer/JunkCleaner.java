package com.htx.optimize.optimizer;

import android.os.Environment;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Localiza arquivos temporários seguros (.tmp, .log, miniaturas...) no armazenamento. */
public final class JunkCleaner {

    public static final class Scan {
        public final List<File> files;
        public final long bytes;

        Scan(List<File> files, long bytes) {
            this.files = files;
            this.bytes = bytes;
        }
    }

    private static final int MAX_FILES = 4000;
    private static final int MAX_DEPTH = 8;
    private static final String[] JUNK_EXT = {
            ".tmp", ".temp", ".log", ".cache", ".thumbdata"};
    private static final long IN_USE_WINDOW_MS = 10L * 60L * 1000L;

    private JunkCleaner() { }

    public static Scan scan() {
        List<File> found = new ArrayList<>();
        long[] total = new long[1];
        File root = Environment.getExternalStorageDirectory();
        if (root != null) walk(root, 0, false, found, total);
        return new Scan(found, total[0]);
    }

    public static long delete(List<File> files) {
        long freed = 0L;
        for (File file : files) {
            long size = file.length();
            try {
                if (file.delete()) freed += size;
            } catch (SecurityException ignored) {
                // arquivo protegido: ignora
            }
        }
        return freed;
    }

    private static void walk(File dir, int depth, boolean inThumbs, List<File> out, long[] total) {
        if (depth > MAX_DEPTH || out.size() >= MAX_FILES) return;
        File[] children = dir.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (out.size() >= MAX_FILES) return;
            String name = child.getName();
            if (child.isDirectory()) {
                if (depth == 0 && name.equals("Android")) continue;
                walk(child, depth + 1, inThumbs || name.equals(".thumbnails"), out, total);
            } else if (child.isFile() && (inThumbs || isJunk(name))
                    && System.currentTimeMillis() - child.lastModified() > IN_USE_WINDOW_MS) {
                out.add(child);
                total[0] += child.length();
            }
        }
    }

    private static boolean isJunk(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        for (String ext : JUNK_EXT) {
            if (lower.endsWith(ext)) return true;
        }
        return false;
    }
}
