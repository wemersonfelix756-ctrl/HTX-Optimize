package com.htx.optimize.fragments;

import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.htx.optimize.R;
import com.htx.optimize.ui.UiAnim;

public class AboutFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_about, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TextView version = view.findViewById(R.id.tv_about_version);
        if (version != null) {
            String name = "?";
            try {
                PackageInfo info = requireContext().getPackageManager()
                        .getPackageInfo(requireContext().getPackageName(), 0);
                if (info.versionName != null) name = info.versionName;
            } catch (Exception ignored) {
                // mantém "?"
            }
            version.setText("Versão " + name + " • Pacote: " + requireContext().getPackageName());
        }
        TextView dev = view.findViewById(R.id.tv_about_dev);
        if (dev != null) dev.setText("Desenvolvedor: " + getString(R.string.dev_name)
                + "\nEspecialidade: " + getString(R.string.dev_specialty));
        UiAnim.revealChildren(view);
    }
}
