package com.htx.optimize.files;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Preferências do gerenciador: ordenação, ocultos, favoritos e última pasta. */
public final class FmPrefs {

    private FmPrefs() { }

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("htx_fm", Context.MODE_PRIVATE);
    }

    public static FileOps.SortKey sortKey(Context c) {
        try {
            return FileOps.SortKey.valueOf(p(c).getString("sort_key", "NAME"));
        } catch (IllegalArgumentException exception) {
            return FileOps.SortKey.NAME;
        }
    }

    public static boolean sortAscending(Context c) { return p(c).getBoolean("sort_asc", true); }

    public static void setSort(Context c, FileOps.SortKey key, boolean ascending) {
        p(c).edit().putString("sort_key", key.name()).putBoolean("sort_asc", ascending).apply();
    }

    public static boolean showHidden(Context c) { return p(c).getBoolean("show_hidden", false); }

    public static void setShowHidden(Context c, boolean value) { p(c).edit().putBoolean("show_hidden", value).apply(); }

    public static String lastDir(Context c) { return p(c).getString("last_dir", null); }

    public static void setLastDir(Context c, String path) { p(c).edit().putString("last_dir", path).apply(); }

    public static List<String> favorites(Context c) {
        List<String> list = new ArrayList<>(p(c).getStringSet("favorites", Collections.<String>emptySet()));
        Collections.sort(list);
        return list;
    }

    public static void setFavorite(Context c, String path, boolean favorite) {
        Set<String> set = new HashSet<>(p(c).getStringSet("favorites", Collections.<String>emptySet()));
        if (favorite) set.add(path); else set.remove(path);
        p(c).edit().putStringSet("favorites", set).apply();
    }

    public static boolean isFavorite(Context c, String path) {
        return p(c).getStringSet("favorites", Collections.<String>emptySet()).contains(path);
    }
}
