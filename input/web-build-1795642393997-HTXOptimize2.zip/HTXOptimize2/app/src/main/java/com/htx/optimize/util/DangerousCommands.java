package com.htx.optimize.util;

import java.util.regex.Pattern;

/** Detecta comandos que podem apagar/danificar dados para pedir confirmação antes de rodar. */
public final class DangerousCommands {

    private static final Pattern[] PATTERNS = {
            Pattern.compile("\\brm\\s+(-[a-zA-Z]*\\s+)*-[a-zA-Z]*[rR][a-zA-Z]*\\s+(\\S+\\s+)*(/|/\\*|/sdcard/?\\*?|/storage(/\\S*)?|/data(/\\S*)?|/system(/\\S*)?|\\*|~)(\\s|$)"),
            Pattern.compile("\\bmkfs(\\.\\w+)?\\b"),
            Pattern.compile("\\bdd\\s+[^|;]*\\bof=/dev/"),
            Pattern.compile(">\\s*/dev/(block|sd|mmcblk|nvme)"),
            Pattern.compile("\\bwipe\\b"),
            Pattern.compile("\\bformat\\s+(data|/data|userdata)\\b"),
            Pattern.compile("\\bpm\\s+(clear|uninstall)\\s+(-\\S+\\s+)*(com\\.android\\.systemui|android|com\\.android\\.phone)\\b"),
            Pattern.compile("\\bsetprop\\s+persist\\."),
            Pattern.compile("\\bmv\\s+\\S+\\s+/dev/null\\b"),
    };

    private DangerousCommands() { }

    public static boolean isDangerous(String command) {
        if (command == null) return false;
        String c = command.trim();
        for (Pattern pattern : PATTERNS) {
            if (pattern.matcher(c).find()) return true;
        }
        return false;
    }
}
