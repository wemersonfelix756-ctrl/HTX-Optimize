package com.htx.optimize.optimizer;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.Settings;
import android.provider.Telephony;
import android.telecom.TelecomManager;
import com.htx.optimize.shizuku.ShizukuBridge;
import com.htx.optimize.util.ProtectedApps;
import com.htx.optimize.monitor.SystemMonitor;
import com.htx.optimize.util.Shell;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Otimização real de RAM: pede ao Android para encerrar os processos em segundo plano
 * dos aplicativos instalados (KILL_BACKGROUND_PROCESSES), preservando launcher, teclado
 * e serviços essenciais. Apps com serviço em primeiro plano não são afetados.
 */
public final class RamOptimizer {

    public static final class Result {
        public final int requested, skipped, deepStopped;
        public final long beforeAvail, afterAvail, cacheFreed;

        Result(int requested, int skipped, int deepStopped, long beforeAvail, long afterAvail, long cacheFreed) {
            this.deepStopped = deepStopped;
            this.requested = requested;
            this.skipped = skipped;
            this.beforeAvail = beforeAvail;
            this.afterAvail = afterAvail;
            this.cacheFreed = cacheFreed;
        }

        public long deltaBytes() { return afterAvail - beforeAvail; }
    }

    private static final String[] PROTECTED_PREFIXES = {
            "com.android.systemui", "com.google.android.gms", "com.google.android.gsf",
            "com.android.phone", "com.android.providers.", "com.android.bluetooth",
            "com.android.server.telecom", "com.android.settings", "com.android.inputmethod",
            "com.android.nfc", "com.android.shell", "com.android.vending"};

    private RamOptimizer() { }

    public static Result run(Context context) {
        return run(context, null);
    }

    /**
     * Bloqueante (~2 s): chamar fora da thread principal.
     * Com um Shell privilegiado (Shizuku), também faz "am force-stop" nos apps (modo profundo).
     */
    public static Result run(Context context, Shell deepShell) {
        Context app = context.getApplicationContext();
        SystemMonitor.RamSnapshot before = SystemMonitor.readRam(app);
        int requested = 0;
        int skipped = 0;
        int deepStopped = 0;
        List<String> targets = new ArrayList<>();

        ActivityManager manager = (ActivityManager) app.getSystemService(Context.ACTIVITY_SERVICE);
        PackageManager pm = app.getPackageManager();
        Set<String> protectedPackages = buildProtectedSet(app, pm);

        List<ApplicationInfo> apps;
        try {
            apps = pm.getInstalledApplications(0);
        } catch (RuntimeException exception) {
            apps = Collections.emptyList();
        }

        if (manager != null) {
            for (ApplicationInfo info : apps) {
                String pkg = info.packageName;
                if (pkg == null || isProtected(pkg, protectedPackages) || isCoreSystemApp(info)
                        || (info.flags & ApplicationInfo.FLAG_STOPPED) != 0) {
                    skipped++;
                    continue;
                }
                try {
                    manager.killBackgroundProcesses(pkg);
                    requested++;
                    targets.add(pkg);
                } catch (RuntimeException exception) {
                    skipped++;
                }
            }
        }

        if (deepShell != null) {
            for (int from = 0; from < targets.size(); from += 40) {
                List<String> chunk = targets.subList(from, Math.min(targets.size(), from + 40));
                StringBuilder cmd = new StringBuilder("for p in");
                for (String pkg : chunk) cmd.append(' ').append(pkg);
                cmd.append("; do am force-stop \"$p\"; done");
                try {
                    deepShell.run(cmd.toString());
                    deepStopped += chunk.size();
                } catch (Exception ignored) {
                    // segue com o que foi possível
                }
            }
        }

        long cache = clearOwnCache(app);
        System.gc();
        try {
            Thread.sleep(1500L);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
        }
        SystemMonitor.RamSnapshot after = SystemMonitor.readRam(app);
        return new Result(requested, skipped, deepStopped, before.availBytes, after.availBytes, cache);
    }

    private static boolean isCoreSystemApp(ApplicationInfo info) {
        boolean system = (info.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
        boolean updated = (info.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
        return system && !updated;
    }

    private static boolean isProtected(String pkg, Set<String> exact) {
        if (exact.contains(pkg)) return true;
        for (String prefix : PROTECTED_PREFIXES) {
            if (pkg.startsWith(prefix)) return true;
        }
        return false;
    }

    private static Set<String> buildProtectedSet(Context app, PackageManager pm) {
        Set<String> set = new HashSet<>();
        set.add(app.getPackageName());
        set.add("android");
        set.add(ShizukuBridge.SHIZUKU_PACKAGE);
        set.addAll(ProtectedApps.get(app));
        try {
            String sms = Telephony.Sms.getDefaultSmsPackage(app);
            if (sms != null) set.add(sms);
        } catch (RuntimeException ignored) {
            // sem app de SMS padrão
        }
        try {
            TelecomManager telecom = (TelecomManager) app.getSystemService(Context.TELECOM_SERVICE);
            String dialer = telecom == null ? null : telecom.getDefaultDialerPackage();
            if (dialer != null) set.add(dialer);
        } catch (RuntimeException ignored) {
            // sem discador padrão
        }
        try {
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            List<ResolveInfo> launchers = pm.queryIntentActivities(home, 0);
            for (ResolveInfo resolve : launchers) {
                if (resolve.activityInfo != null) set.add(resolve.activityInfo.packageName);
            }
        } catch (RuntimeException ignored) {
            // segue sem a lista de launchers
        }
        try {
            String ime = Settings.Secure.getString(app.getContentResolver(),
                    Settings.Secure.DEFAULT_INPUT_METHOD);
            ComponentName component = ime == null ? null : ComponentName.unflattenFromString(ime);
            if (component != null) set.add(component.getPackageName());
        } catch (RuntimeException ignored) {
            // segue sem o teclado
        }
        return set;
    }

    private static long clearOwnCache(Context app) {
        long freed = deleteContents(app.getCacheDir());
        File external = app.getExternalCacheDir();
        if (external != null) freed += deleteContents(external);
        return freed;
    }

    private static long deleteContents(File dir) {
        if (dir == null || !dir.isDirectory()) return 0L;
        long freed = 0L;
        File[] children = dir.listFiles();
        if (children == null) return 0L;
        for (File child : children) {
            if (child.isDirectory()) freed += deleteContents(child);
            long size = child.length();
            if (child.delete()) freed += size;
        }
        return freed;
    }
}
