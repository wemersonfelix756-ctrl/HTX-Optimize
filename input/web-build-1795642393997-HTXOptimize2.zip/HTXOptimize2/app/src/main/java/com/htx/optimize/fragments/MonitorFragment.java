package com.htx.optimize.fragments;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.htx.optimize.MainActivity;
import com.htx.optimize.R;
import com.htx.optimize.monitor.FpsSampler;
import com.htx.optimize.monitor.FpsStats;
import com.htx.optimize.overlay.OverlayService;
import com.htx.optimize.shizuku.ShizukuBridge;
import com.htx.optimize.ui.UiAnim;
import com.htx.optimize.util.AppPrefs;
import com.htx.optimize.util.FormatUtils;
import com.htx.optimize.util.PermissionHelper;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rikka.shizuku.Shizuku;

/** Monitor: janelinha flutuante, Shizuku (FPS real), aparência e medição. */
public class MonitorFragment extends Fragment {

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private TextView tvOverlayTitle, tvOverlayPerm, tvShizuku, tvOpacity, tvOutput;
    private Button btnToggle, btnShizuku;

    private final Shizuku.OnBinderReceivedListener binderListener = () -> main.post(this::updateShizukuUi);
    private final Shizuku.OnBinderDeadListener deadListener = () -> main.post(this::updateShizukuUi);
    private final Shizuku.OnRequestPermissionResultListener permissionListener =
            (requestCode, grantResult) -> main.post(this::updateShizukuUi);

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        return inflater.inflate(R.layout.fragment_monitor, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        super.onViewCreated(view, state);
        final Context ctx = requireContext();
        tvOverlayTitle = view.findViewById(R.id.tv_overlay_title);
        tvOverlayPerm = view.findViewById(R.id.tv_overlay_perm);
        tvShizuku = view.findViewById(R.id.tv_shizuku_status);
        tvOpacity = view.findViewById(R.id.tv_opacity_label);
        tvOutput = view.findViewById(R.id.tv_measure_output);
        btnToggle = view.findViewById(R.id.btn_overlay_toggle);
        btnShizuku = view.findViewById(R.id.btn_shizuku_action);

        btnToggle.setOnClickListener(v -> toggleOverlay());
        btnShizuku.setOnClickListener(v -> onShizukuAction());

        try {
            Shizuku.addBinderReceivedListener(binderListener);
            Shizuku.addBinderDeadListener(deadListener);
            Shizuku.addRequestPermissionResultListener(permissionListener);
        } catch (RuntimeException ignored) {
            // Shizuku indisponível: a tela funciona em modo básico
        }

        SwitchCompat real = view.findViewById(R.id.sw_real_fps);
        real.setChecked(AppPrefs.realFps(ctx));
        real.setOnCheckedChangeListener((b, checked) -> AppPrefs.setRealFps(ctx, checked));
        SwitchCompat big = view.findViewById(R.id.sw_big);
        big.setChecked(AppPrefs.overlayBig(ctx));
        big.setOnCheckedChangeListener((b, checked) -> AppPrefs.setOverlayBig(ctx, checked));
        SwitchCompat graph = view.findViewById(R.id.sw_graph);
        graph.setChecked(AppPrefs.overlayGraph(ctx));
        graph.setOnCheckedChangeListener((b, checked) -> AppPrefs.setOverlayGraph(ctx, checked));

        SeekBar seek = view.findViewById(R.id.seek_opacity);
        seek.setProgress(AppPrefs.overlayOpacity(ctx) - 30);
        updateOpacityLabel(AppPrefs.overlayOpacity(ctx));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (!isAdded()) return;
                AppPrefs.setOverlayOpacity(ctx, progress + 30);
                updateOpacityLabel(progress + 30);
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });

        view.findViewById(R.id.btn_fps_stats).setOnClickListener(v -> showStats());
        view.findViewById(R.id.btn_fps_diag).setOnClickListener(v -> runDiagnostic());
        UiAnim.revealChildren(view);
    }

    @Override public void onResume() {
        super.onResume();
        updateOverlayUi();
        updateShizukuUi();
    }

    @Override public void onDestroyView() {
        try {
            Shizuku.removeBinderReceivedListener(binderListener);
            Shizuku.removeBinderDeadListener(deadListener);
            Shizuku.removeRequestPermissionResultListener(permissionListener);
        } catch (RuntimeException ignored) {
            // já removidos
        }
        main.removeCallbacksAndMessages(null);
        tvOverlayTitle = null; tvOverlayPerm = null; tvShizuku = null; tvOpacity = null; tvOutput = null;
        btnToggle = null; btnShizuku = null;
        super.onDestroyView();
    }

    @Override public void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ janelinha

    private void toggleOverlay() {
        if (!isAdded()) return;
        Context ctx = requireContext();
        if (OverlayService.isRunning()) {
            ctx.startService(new Intent(ctx, OverlayService.class).setAction(OverlayService.ACTION_STOP));
        } else if (!PermissionHelper.hasOverlay(ctx)) {
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).startPermissionFlow();
            return;
        } else {
            ContextCompat.startForegroundService(ctx,
                    new Intent(ctx, OverlayService.class).setAction(OverlayService.ACTION_START));
        }
        main.postDelayed(this::updateOverlayUi, 500L);
    }

    private void updateOverlayUi() {
        if (!isAdded() || tvOverlayTitle == null) return;
        Context ctx = requireContext();
        boolean on = OverlayService.isRunning();
        tvOverlayTitle.setText(on ? "Ativa" : "Desativada");
        tvOverlayTitle.setTextColor(ContextCompat.getColor(ctx, on ? R.color.htx_ok : R.color.htx_text));
        btnToggle.setText(on ? "Desativar janelinha" : "Ativar janelinha");
        boolean overlayOk = PermissionHelper.hasOverlay(ctx);
        tvOverlayPerm.setVisibility(overlayOk ? View.GONE : View.VISIBLE);
        tvOverlayPerm.setText("Falta a permissão “Sobrepor outros apps”. Toque em ativar para concedê-la.");
    }

    private void updateOpacityLabel(int opacity) {
        if (tvOpacity != null) tvOpacity.setText("Opacidade: " + opacity + "%");
    }

    // ------------------------------------------------------------------ Shizuku

    private void onShizukuAction() {
        if (!isAdded()) return;
        Context ctx = requireContext();
        ShizukuBridge.State state = ShizukuBridge.state(ctx);
        if (state == ShizukuBridge.State.NOT_INSTALLED) {
            FormatUtils.safeStartActivity(ctx, new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")));
        } else if (state == ShizukuBridge.State.NOT_RUNNING) {
            Intent launch = ShizukuBridge.launchIntent(ctx);
            if (launch != null) FormatUtils.safeStartActivity(ctx, launch);
        } else if (state == ShizukuBridge.State.NO_PERMISSION) {
            ShizukuBridge.requestPermission();
        } else {
            Toast.makeText(ctx, "O Shizuku já está autorizado.", Toast.LENGTH_SHORT).show();
        }
        main.postDelayed(this::updateShizukuUi, 800L);
    }

    private void updateShizukuUi() {
        if (!isAdded() || tvShizuku == null || btnShizuku == null) return;
        switch (ShizukuBridge.state(requireContext())) {
            case NOT_INSTALLED:
                tvShizuku.setText("O Shizuku não está instalado. Com ele você mede o FPS real dos jogos, usa o terminal como usuário shell e ativa o modo profundo.");
                btnShizuku.setText("Baixar o Shizuku");
                break;
            case NOT_RUNNING:
                tvShizuku.setText("O Shizuku está instalado, mas parado. Abra-o e inicie o serviço (depuração sem fio ou ADB). Isso precisa ser refeito após reiniciar o celular.");
                btnShizuku.setText("Abrir o Shizuku");
                break;
            case NO_PERMISSION:
                tvShizuku.setText("O Shizuku está rodando. Falta autorizar o HTX Optimize.");
                btnShizuku.setText("Autorizar o HTX Optimize");
                break;
            default:
                tvShizuku.setText("Shizuku autorizado. A janelinha mostra o FPS real do app em foco.");
                btnShizuku.setText("Shizuku conectado");
                break;
        }
    }

    // ------------------------------------------------------------------ medição

    private void showOutput(String text) {
        if (tvOutput == null) return;
        tvOutput.setText(text);
        tvOutput.setVisibility(View.VISIBLE);
    }

    private void showStats() {
        FpsStats.Summary summary = FpsStats.GLOBAL.summary();
        showOutput(summary == null
                ? "Ainda não há medições. Ligue a janelinha com o Shizuku autorizado, abra um jogo, jogue alguns segundos e volte aqui."
                : summary.toText());
    }

    /** Espera 10 s (para você abrir o jogo) e mostra, passo a passo, o que o Shizuku consegue ler. */
    private void runDiagnostic() {
        if (!isAdded() || worker.isShutdown()) return;
        final Context app = requireContext().getApplicationContext();
        showOutput("Diagnóstico iniciado.\nAbra agora o jogo ou app que quer medir e deixe-o na tela.\n"
                + "Em 10 segundos o resultado aparece aqui — depois volte ao HTX Optimize.");
        worker.execute(() -> {
            try {
                Thread.sleep(10_000L);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                return;
            }
            StringBuilder sb = new StringBuilder("Diagnóstico do FPS real\n");
            ShizukuBridge.State state = ShizukuBridge.state(app);
            sb.append("Shizuku: ").append(state).append('\n');
            if (state == ShizukuBridge.State.READY) {
                boolean connected = ShizukuBridge.awaitConnected(app, 5000L);
                sb.append("Serviço do app: ").append(connected ? "conectado" : "NÃO conectou").append('\n');
                if (connected) {
                    try {
                        sb.append("Usuário: ").append(ShizukuBridge.exec("id").trim()).append('\n');
                        FpsSampler sampler = new FpsSampler(ShizukuBridge::exec);
                        sampler.sample(System.currentTimeMillis());
                        Thread.sleep(1200L);
                        FpsSampler.Sample result = sampler.sample(System.currentTimeMillis());
                        sb.append('\n').append(sampler.debugReport());
                        sb.append("\nResultado: ").append(Float.isNaN(result.fps)
                                ? "FPS indisponível (" + result.status + ")"
                                : String.format(Locale.US, "%.1f FPS via %s", result.fps, result.source));
                    } catch (Exception exception) {
                        sb.append("Erro: ").append(exception.getMessage());
                    }
                }
            } else {
                sb.append("Autorize o HTX Optimize no card do Shizuku antes de testar.");
            }
            final String text = sb.toString();
            main.post(() -> { if (isAdded()) showOutput(text); });
        });
    }
}
