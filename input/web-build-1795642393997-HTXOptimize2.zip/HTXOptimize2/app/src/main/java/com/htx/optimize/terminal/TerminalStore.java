package com.htx.optimize.terminal;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;

/** Histórico e comandos salvos do terminal. */
public final class TerminalStore {

    private static final int MAX_HISTORY = 100;

    private TerminalStore() { }

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("htx_terminal", Context.MODE_PRIVATE);
    }

    private static List<String> read(SharedPreferences prefs, String key) {
        String raw = prefs.getString(key, "");
        List<String> list = new ArrayList<>();
        if (raw == null || raw.isEmpty()) return list;
        for (String line : raw.split("\n")) if (!line.trim().isEmpty()) list.add(line);
        return list;
    }

    private static void write(SharedPreferences prefs, String key, List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (String line : list) sb.append(line).append('\n');
        prefs.edit().putString(key, sb.toString()).apply();
    }

    /** Mais antigo primeiro. */
    public static List<String> history(Context c) { return read(p(c), "history"); }

    public static void addHistory(Context c, String command) {
        List<String> list = history(c);
        if (!list.isEmpty() && list.get(list.size() - 1).equals(command)) return;
        list.add(command);
        while (list.size() > MAX_HISTORY) list.remove(0);
        write(p(c), "history", list);
    }

    public static List<String> saved(Context c) { return read(p(c), "saved"); }

    public static boolean addSaved(Context c, String command) {
        List<String> list = saved(c);
        if (list.contains(command)) return false;
        list.add(command);
        write(p(c), "saved", list);
        return true;
    }

    public static void removeSaved(Context c, String command) {
        List<String> list = saved(c);
        list.remove(command);
        write(p(c), "saved", list);
    }
}
