package com.htx.optimize.monitor;

/** Pontuação de saúde do aparelho (0–100) a partir de RAM, armazenamento, temperatura e bateria. */
public final class HealthScore {

    public static final class Result {
        public final int score;
        public final String label;
        public final String hint;

        Result(int score, String label, String hint) {
            this.score = score;
            this.label = label;
            this.hint = hint;
        }
    }

    private HealthScore() { }

    /**
     * @param ramUsedPercent     0..100
     * @param storageUsedPercent 0..100
     * @param tempCelsius        NaN quando indisponível
     * @param batteryPercent     -1 quando indisponível
     */
    public static Result compute(int ramUsedPercent, int storageUsedPercent, float tempCelsius,
                                 int batteryPercent, boolean lowMemory) {
        double ramPenalty = Math.min(32.0, Math.max(0.0, (ramUsedPercent - 60) * 0.8)) + (lowMemory ? 8.0 : 0.0);
        double storagePenalty = Math.min(22.0, Math.max(0.0, (storageUsedPercent - 75) * 0.9));
        double tempPenalty = Float.isNaN(tempCelsius) ? 0.0 : Math.min(30.0, Math.max(0.0, (tempCelsius - 40f) * 1.5));
        double batteryPenalty = batteryPercent < 0 ? 0.0 : Math.min(10.0, Math.max(0.0, (20 - batteryPercent) * 0.5));

        int score = (int) Math.round(Math.max(0.0, Math.min(100.0,
                100.0 - ramPenalty - storagePenalty - tempPenalty - batteryPenalty)));

        String hint = "Tudo em ordem. Use o Modo Jogo antes de jogar.";
        double worst = 0.0;
        if (ramPenalty > worst) { worst = ramPenalty; hint = "Memória sob pressão: use o RAM Booster."; }
        if (storagePenalty > worst) { worst = storagePenalty; hint = "Armazenamento quase cheio: veja os maiores arquivos."; }
        if (tempPenalty > worst) { worst = tempPenalty; hint = "Aparelho quente: deixe esfriar ou feche apps pesados."; }
        if (batteryPenalty > worst) { hint = "Bateria baixa: conecte o carregador."; }

        String label = score >= 85 ? "EXCELENTE" : score >= 65 ? "BOM" : score >= 40 ? "ATENÇÃO" : "CRÍTICO";
        return new Result(score, label, hint);
    }
}
