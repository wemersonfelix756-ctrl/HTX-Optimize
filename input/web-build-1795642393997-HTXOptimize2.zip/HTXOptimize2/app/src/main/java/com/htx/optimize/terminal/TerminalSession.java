package com.htx.optimize.terminal;

import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import com.htx.optimize.util.ShellRunner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Estado do terminal que sobrevive à troca de abas (saída, pasta atual, modo, execução). */
public final class TerminalSession {

    public static final int CMD = 0xFF22E5FF;
    public static final int OUT = 0xFFD7ECFF;
    public static final int ERR = 0xFFF87171;
    public static final int DIM = 0xFF6B90AD;
    public static final int WARN = 0xFFFBBF24;
    public static final int OK = 0xFF34D399;

    public static final long[] TIMEOUTS_MS = {15_000L, 60_000L, 300_000L, 0L};
    public static final String[] TIMEOUT_LABELS = {"15 s", "60 s", "5 min", "sem limite"};

    public static final SpannableStringBuilder BUFFER = new SpannableStringBuilder();
    public static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    public static String cwd;
    public static boolean useShizuku = true;
    public static int timeoutIndex = 1;
    public static String pendingCommand;
    public static volatile boolean running;
    public static volatile ShellRunner appRunner;
    public static Runnable listener; // atualiza a tela quando algo muda (thread principal)

    private static final int MAX_CHARS = 150_000;

    private TerminalSession() { }

    public static void append(CharSequence text, int color) {
        if (text == null || text.length() == 0) return;
        SpannableString span = new SpannableString(text);
        span.setSpan(new ForegroundColorSpan(color), 0, span.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        BUFFER.append(span);
        if (BUFFER.length() > MAX_CHARS) BUFFER.delete(0, BUFFER.length() - MAX_CHARS / 2);
        notifyListener();
    }

    public static void clear() {
        BUFFER.clear();
        notifyListener();
    }

    public static void notifyListener() {
        Runnable l = listener;
        if (l != null) l.run();
    }
}
