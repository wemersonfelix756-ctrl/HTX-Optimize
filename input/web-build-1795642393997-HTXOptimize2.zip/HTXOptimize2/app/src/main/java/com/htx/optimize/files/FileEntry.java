package com.htx.optimize.files;

import java.io.File;

/** Item da lista: arquivo real, ou entrada virtual dentro de um arquivo compactado. */
public final class FileEntry {
    public final File file;          // null quando virtual (dentro de arquivo compactado)
    public final String virtualPath; // caminho dentro do arquivo compactado
    public final String name;
    public final boolean dir;
    public final long size;
    public final long modified;
    public final int childCount;     // -1 = desconhecido
    public final String subtitle;    // texto extra (ex.: pasta, nos resultados de busca)
    public boolean selected;

    public FileEntry(File file, int childCount, String subtitle) {
        this.file = file;
        this.virtualPath = null;
        this.name = file.getName();
        this.dir = file.isDirectory();
        this.size = dir ? 0L : file.length();
        this.modified = file.lastModified();
        this.childCount = childCount;
        this.subtitle = subtitle;
    }

    public FileEntry(String virtualPath, String name, boolean dir, long size, long modified) {
        this.file = null;
        this.virtualPath = virtualPath;
        this.name = name;
        this.dir = dir;
        this.size = size;
        this.modified = modified;
        this.childCount = -1;
        this.subtitle = null;
    }

    public boolean isVirtual() { return file == null; }

    public FileKind kind() { return FileKind.of(name, dir); }
}
