package com.htx.optimize.shizuku;

import com.htx.optimize.util.ShellRunner;

/** Roda no processo shell do Shizuku (uid 2000): executa comandos pedidos pelo app. */
public class ShizukuUserService extends IUserService.Stub {

    private static final long EXEC_TIMEOUT_MS = 20_000L;

    private volatile ShellRunner terminalRunner;

    public ShizukuUserService() { }

    @Override public void destroy() {
        System.exit(0);
    }

    @Override public String exec(String command) {
        return new ShellRunner().run(command, null, EXEC_TIMEOUT_MS).output;
    }

    @Override public String execWithTimeout(String command, String cwd, long timeoutMs) {
        ShellRunner runner = new ShellRunner();
        terminalRunner = runner;
        try {
            return ShellRunner.encode(runner.run(command, cwd, timeoutMs));
        } finally {
            if (terminalRunner == runner) terminalRunner = null;
        }
    }

    @Override public void cancel() {
        ShellRunner runner = terminalRunner;
        if (runner != null) runner.cancel();
    }
}
