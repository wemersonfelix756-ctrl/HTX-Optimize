package com.htx.optimize.fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.htx.optimize.MainActivity;
import com.htx.optimize.R;
import com.htx.optimize.files.ArchiveUtils;
import com.htx.optimize.files.FileClipboard;
import com.htx.optimize.files.FileEntry;
import com.htx.optimize.files.FileKind;
import com.htx.optimize.files.FileListAdapter;
import com.htx.optimize.files.FileOpener;
import com.htx.optimize.files.FileOps;
import com.htx.optimize.files.FmPrefs;
import com.htx.optimize.ui.UiAnim;
import com.htx.optimize.util.FormatUtils;
import com.htx.optimize.util.PermissionHelper;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/** Gerenciador de arquivos no estilo do ZArchiver: navegar, selecionar, copiar/mover, compactar, extrair. */
public class FileManagerFragment extends Fragment implements FileListAdapter.Listener {

    private interface Task {
        String run(FileOps.Progress progress, FileOps.Control control) throws Exception;
    }

    private interface TextAction {
        void accept(String text);
    }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService lister = Executors.newSingleThreadExecutor();
    private final ExecutorService ops = Executors.newSingleThreadExecutor();
    private final AtomicInteger generation = new AtomicInteger();

    private RecyclerView rv;
    private FileListAdapter adapter;
    private TextView tvInfo, tvEmpty, tvClip, tvSelCount;
    private View cardPermission, barPaste, barSelect, btnNew;
    private LinearLayout llPath, llPlaces;
    private View scrollPath;
    private EditText etSearch;
    private Button btnSelExtract, btnSelCopy, btnSelCut, btnSelDelete, btnSelCompress, btnSelRename, btnSelShare, btnSelInfo;

    private File currentDir;
    private boolean showHidden, sortAscending;
    private FileOps.SortKey sortKey;
    private File archiveFile;
    private List<ArchiveUtils.Entry> archiveEntries;
    private String archivePrefix = "";
    private boolean searchResultsMode;
    private String searchTitle = "";
    private boolean selectionMode;
    private String filterText = "";
    private List<FileEntry> baseItems = new ArrayList<>();

    private final OnBackPressedCallback backCallback = new OnBackPressedCallback(false) {
        @Override public void handleOnBackPressed() { handleBack(); }
    };

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        return inflater.inflate(R.layout.fragment_files, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        super.onViewCreated(view, state);
        Context ctx = requireContext();
        showHidden = FmPrefs.showHidden(ctx);
        sortKey = FmPrefs.sortKey(ctx);
        sortAscending = FmPrefs.sortAscending(ctx);

        rv = view.findViewById(R.id.rv_fm);
        rv.setLayoutManager(new LinearLayoutManager(ctx));
        adapter = new FileListAdapter(this);
        rv.setAdapter(adapter);
        tvInfo = view.findViewById(R.id.tv_fm_info);
        tvEmpty = view.findViewById(R.id.tv_fm_empty);
        tvClip = view.findViewById(R.id.tv_fm_clip);
        tvSelCount = view.findViewById(R.id.tv_sel_count);
        cardPermission = view.findViewById(R.id.card_fm_permission);
        barPaste = view.findViewById(R.id.bar_fm_paste);
        barSelect = view.findViewById(R.id.bar_fm_select);
        btnNew = view.findViewById(R.id.btn_fm_new);
        llPath = view.findViewById(R.id.ll_fm_path);
        llPlaces = view.findViewById(R.id.ll_fm_places);
        scrollPath = view.findViewById(R.id.scroll_fm_path);
        etSearch = view.findViewById(R.id.et_fm_search);
        btnSelExtract = view.findViewById(R.id.btn_sel_extract);
        btnSelCopy = view.findViewById(R.id.btn_sel_copy);
        btnSelCut = view.findViewById(R.id.btn_sel_cut);
        btnSelDelete = view.findViewById(R.id.btn_sel_delete);
        btnSelCompress = view.findViewById(R.id.btn_sel_compress);
        btnSelRename = view.findViewById(R.id.btn_sel_rename);
        btnSelShare = view.findViewById(R.id.btn_sel_share);
        btnSelInfo = view.findViewById(R.id.btn_sel_info);

        view.findViewById(R.id.btn_fm_up).setOnClickListener(v -> goUp());
        view.findViewById(R.id.btn_fm_menu).setOnClickListener(this::showMainMenu);
        btnNew.setOnClickListener(this::showNewMenu);
        view.findViewById(R.id.btn_fm_grant).setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).startPermissionFlow();
        });
        view.findViewById(R.id.btn_fm_paste).setOnClickListener(v -> paste());
        view.findViewById(R.id.btn_fm_clip_cancel).setOnClickListener(v -> {
            FileClipboard.clear();
            updatePasteBar();
        });
        view.findViewById(R.id.btn_sel_all).setOnClickListener(v -> {
            boolean allSelected = adapter.getSelected().size() == adapter.getItems().size();
            adapter.selectAll(!allSelected);
            updateSelectionUi();
        });
        view.findViewById(R.id.btn_sel_close).setOnClickListener(v -> exitSelection());
        btnSelCopy.setOnClickListener(v -> clipSelected(false));
        btnSelCut.setOnClickListener(v -> clipSelected(true));
        btnSelDelete.setOnClickListener(v -> confirmDelete());
        btnSelCompress.setOnClickListener(v -> showCompressDialog());
        btnSelExtract.setOnClickListener(v -> extractSelected());
        btnSelRename.setOnClickListener(v -> showRenameDialog());
        btnSelShare.setOnClickListener(v -> FileOpener.share(requireContext(), selectedFiles()));
        btnSelInfo.setOnClickListener(v -> showProperties(selectedFiles()));
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                filterText = s.toString().trim().toLowerCase(Locale.ROOT);
                applyFilter();
            }
        });

        requireActivity().getOnBackPressedDispatcher().addCallback(getViewLifecycleOwner(), backCallback);
        FileOps.deleteQuietly(new File(ctx.getCacheDir(), "fm_open")); // arquivos temporários de aberturas anteriores
        UiAnim.revealChildren(view);

        File start = null;
        String last = FmPrefs.lastDir(ctx);
        if (last != null && new File(last).isDirectory()) start = new File(last);
        if (start == null) start = Environment.getExternalStorageDirectory();
        currentDir = start;
        buildPlaces();
        if (ensureAccess()) loadDirectory(currentDir);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getView() == null) return;
        boolean access = ensureAccess();
        if (access && baseItems.isEmpty() && archiveFile == null && !searchResultsMode) loadDirectory(currentDir);
        buildPlaces();
        updatePasteBar();
    }

    @Override
    public void onDestroyView() {
        rv = null; adapter = null; tvInfo = null; tvEmpty = null; tvClip = null; tvSelCount = null;
        cardPermission = null; barPaste = null; barSelect = null; btnNew = null;
        llPath = null; llPlaces = null; scrollPath = null; etSearch = null;
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        main.removeCallbacksAndMessages(null);
        lister.shutdownNow();
        ops.shutdownNow();
        super.onDestroy();
    }

    // ================================================================ acesso e navegação

    private boolean ensureAccess() {
        boolean granted = PermissionHelper.hasStorage(requireContext());
        if (cardPermission != null) cardPermission.setVisibility(granted ? View.GONE : View.VISIBLE);
        if (rv != null) rv.setVisibility(granted ? View.VISIBLE : View.GONE);
        if (btnNew != null && !granted) btnNew.setVisibility(View.GONE);
        return granted;
    }

    private List<File> storageRoots() {
        List<File> roots = new ArrayList<>();
        File primary = Environment.getExternalStorageDirectory();
        if (primary != null) roots.add(primary);
        try {
            File[] dirs = requireContext().getExternalFilesDirs(null);
            if (dirs != null) {
                for (File dir : dirs) {
                    if (dir == null) continue;
                    String path = dir.getAbsolutePath();
                    int idx = path.indexOf("/Android/data");
                    if (idx > 0) {
                        File root = new File(path.substring(0, idx));
                        if (!roots.contains(root)) roots.add(root);
                    }
                }
            }
        } catch (RuntimeException ignored) {
            // sem volumes extras
        }
        return roots;
    }

    private String rootLabel(File root, int index) {
        return index == 0 ? "Interno" : "SD " + root.getName();
    }

    private boolean isStorageRoot(File dir) {
        for (File root : storageRoots()) if (root.equals(dir)) return true;
        return dir.getParentFile() == null;
    }

    private void buildPlaces() {
        if (llPlaces == null || !isAdded()) return;
        llPlaces.removeAllViews();
        List<File> roots = storageRoots();
        for (int i = 0; i < roots.size(); i++) addPlace(rootLabel(roots.get(i), i), roots.get(i));
        File primary = Environment.getExternalStorageDirectory();
        String[][] standard = {{"Download", Environment.DIRECTORY_DOWNLOADS}, {"DCIM", Environment.DIRECTORY_DCIM},
                {"Imagens", Environment.DIRECTORY_PICTURES}, {"Música", Environment.DIRECTORY_MUSIC},
                {"Vídeos", Environment.DIRECTORY_MOVIES}, {"Documentos", Environment.DIRECTORY_DOCUMENTS}};
        for (String[] item : standard) {
            File dir = new File(primary, item[1]);
            if (dir.isDirectory()) addPlace(item[0], dir);
        }
        for (String fav : FmPrefs.favorites(requireContext())) {
            File dir = new File(fav);
            if (dir.isDirectory()) addPlace("★ " + dir.getName(), dir);
        }
    }

    private void addPlace(String label, final File dir) {
        Button chip = new Button(requireContext());
        chip.setText(label);
        chip.setAllCaps(false);
        chip.setTextSize(13f);
        chip.setTextColor(0xFFEDF3FF);
        chip.setBackgroundResource(R.drawable.bg_chip);
        chip.setStateListAnimator(null);
        chip.setMinWidth(0);
        chip.setMinimumWidth(0);
        chip.setPadding(dp(14), 0, dp(14), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38));
        lp.setMarginEnd(dp(6));
        chip.setLayoutParams(lp);
        chip.setOnClickListener(v -> {
            if (ensureAccess()) {
                exitSelection();
                loadDirectory(dir);
            }
        });
        llPlaces.addView(chip);
    }

    private void loadDirectory(final File dir) {
        archiveFile = null;
        archiveEntries = null;
        archivePrefix = "";
        searchResultsMode = false;
        exitSelection();
        currentDir = dir;
        FmPrefs.setLastDir(requireContext(), dir.getAbsolutePath());
        renderPath();
        updateBackCallback();
        updatePasteBar();
        updateNewButton();
        if (tvInfo != null) tvInfo.setText("Carregando…");
        final int gen = generation.incrementAndGet();
        final boolean hidden = showHidden;
        final FileOps.SortKey key = sortKey;
        final boolean asc = sortAscending;
        lister.execute(() -> {
            List<File> files = FileOps.listSorted(dir, hidden, key, asc);
            final boolean unreadable = dir.listFiles() == null;
            final List<FileEntry> entries = new ArrayList<>();
            int folders = 0;
            for (File f : files) {
                boolean isDir = f.isDirectory();
                if (isDir) folders++;
                entries.add(new FileEntry(f, isDir ? FileOps.childCount(f) : -1, null));
            }
            final int folderCount = folders;
            final int fileCount = files.size() - folders;
            final long free = dir.getFreeSpace();
            main.post(() -> {
                if (gen != generation.get() || !isAdded() || getView() == null) return;
                baseItems = entries;
                applyFilter();
                if (tvInfo != null) {
                    tvInfo.setText(unreadable ? "Sem permissão para ler esta pasta"
                            : folderCount + " pastas • " + fileCount + " arquivos • livre " + FormatUtils.formatBytes(free));
                }
                if (tvEmpty != null) tvEmpty.setText(unreadable ? "Sem permissão para ler esta pasta" : "Pasta vazia");
            });
        });
    }

    private void reloadCurrent() {
        if (!isAdded() || getView() == null) return;
        if (archiveFile != null) showArchiveLevel();
        else if (!searchResultsMode && currentDir != null) loadDirectory(currentDir);
    }

    private void applyFilter() {
        if (adapter == null) return;
        List<FileEntry> shown;
        if (filterText.isEmpty()) {
            shown = baseItems;
        } else {
            shown = new ArrayList<>();
            for (FileEntry entry : baseItems) {
                if (entry.name.toLowerCase(Locale.ROOT).contains(filterText)) shown.add(entry);
            }
        }
        adapter.setItems(shown);
        if (tvEmpty != null) tvEmpty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
        updateSelectionUi();
    }

    private void goUp() {
        if (!ensureAccess()) return;
        if (archiveFile != null) {
            if (!archivePrefix.isEmpty()) {
                int slash = archivePrefix.lastIndexOf('/');
                archivePrefix = slash < 0 ? "" : archivePrefix.substring(0, slash);
                exitSelection();
                showArchiveLevel();
            } else {
                File parent = archiveFile.getParentFile();
                loadDirectory(parent != null ? parent : currentDir);
            }
            return;
        }
        if (searchResultsMode) {
            loadDirectory(currentDir);
            return;
        }
        File parent = currentDir.getParentFile();
        if (parent != null && parent.canRead()) loadDirectory(parent);
        else Toast.makeText(requireContext(), "Você já está na raiz.", Toast.LENGTH_SHORT).show();
    }

    private void handleBack() {
        if (selectionMode) { exitSelection(); return; }
        if (etSearch != null && etSearch.getVisibility() == View.VISIBLE) { closeFilter(); return; }
        goUp();
    }

    private void updateBackCallback() {
        boolean filterOpen = etSearch != null && etSearch.getVisibility() == View.VISIBLE;
        boolean inFolder = currentDir != null && !isStorageRoot(currentDir);
        backCallback.setEnabled(selectionMode || filterOpen || archiveFile != null || searchResultsMode || inFolder);
    }

    private void renderPath() {
        if (llPath == null || !isAdded()) return;
        llPath.removeAllViews();
        if (archiveFile != null) {
            addCrumb(archiveFile.getName(), v -> { archivePrefix = ""; exitSelection(); showArchiveLevel(); }, true);
            if (!archivePrefix.isEmpty()) {
                String acc = "";
                for (String part : archivePrefix.split("/")) {
                    acc = acc.isEmpty() ? part : acc + "/" + part;
                    final String target = acc;
                    addCrumb(part, v -> { archivePrefix = target; exitSelection(); showArchiveLevel(); }, false);
                }
            }
        } else if (searchResultsMode) {
            addCrumb(searchTitle, null, true);
        } else {
            File base = null;
            String baseLabel = "/";
            List<File> roots = storageRoots();
            for (int i = 0; i < roots.size(); i++) {
                if (FileOps.isInside(roots.get(i), currentDir)) {
                    base = roots.get(i);
                    baseLabel = rootLabel(roots.get(i), i);
                    break;
                }
            }
            if (base == null) base = new File("/");
            final File baseDir = base;
            addCrumb(baseLabel, v -> { if (ensureAccess()) loadDirectory(baseDir); }, true);
            String rel = currentDir.getAbsolutePath().substring(Math.min(currentDir.getAbsolutePath().length(), base.getAbsolutePath().length()));
            File walk = base;
            for (String part : rel.split("/")) {
                if (part.isEmpty()) continue;
                walk = new File(walk, part);
                final File target = walk;
                addCrumb(part, v -> { if (ensureAccess()) loadDirectory(target); }, false);
            }
        }
        if (scrollPath != null) scrollPath.post(() -> { if (scrollPath != null) ((android.widget.HorizontalScrollView) scrollPath).fullScroll(View.FOCUS_RIGHT); });
    }

    private void addCrumb(String text, View.OnClickListener click, boolean first) {
        if (!first) {
            TextView sep = new TextView(requireContext());
            sep.setText(" › ");
            sep.setTextColor(0xFF6A809F);
            llPath.addView(sep);
        }
        TextView crumb = new TextView(requireContext());
        crumb.setText(text);
        crumb.setTextSize(14f);
        crumb.setSingleLine(true);
        crumb.setTextColor(0xFF3CD7F6);
        crumb.setPadding(dp(4), dp(8), dp(4), dp(8));
        if (click != null) crumb.setOnClickListener(click);
        llPath.addView(crumb);
    }

    // ================================================================ cliques / seleção

    @Override
    public void onClick(FileEntry entry, int position) {
        if (selectionMode) {
            adapter.toggle(position);
            if (adapter.getSelected().isEmpty()) exitSelection(); else updateSelectionUi();
            return;
        }
        if (entry.isVirtual()) {
            if (entry.dir) {
                archivePrefix = entry.virtualPath;
                showArchiveLevel();
            } else {
                extractAndOpen(entry);
            }
            return;
        }
        File file = entry.file;
        if (entry.dir) {
            loadDirectory(file);
            return;
        }
        switch (entry.kind()) {
            case ARCHIVE: showArchiveDialog(file); break;
            case APK: showApkDialog(file); break;
            case SCRIPT: showScriptDialog(file); break;
            default: FileOpener.open(requireContext(), file);
        }
    }

    @Override
    public void onLongClick(FileEntry entry, int position) {
        if (!selectionMode) {
            selectionMode = true;
            adapter.setSelectionMode(true);
            adapter.select(position, true);
            updateSelectionUi();
        } else {
            adapter.toggle(position);
            updateSelectionUi();
        }
    }

    private void exitSelection() {
        if (!selectionMode && (adapter == null || adapter.getSelected().isEmpty())) {
            updateSelectionUi();
            return;
        }
        selectionMode = false;
        if (adapter != null) {
            adapter.selectAll(false);
            adapter.setSelectionMode(false);
        }
        updateSelectionUi();
    }

    private void updateSelectionUi() {
        if (barSelect == null || adapter == null) return;
        List<FileEntry> selected = adapter.getSelected();
        barSelect.setVisibility(selectionMode ? View.VISIBLE : View.GONE);
        tvSelCount.setText(selected.size() + " selecionado(s)");
        boolean virtual = archiveFile != null;
        boolean allArchives = !selected.isEmpty();
        for (FileEntry e : selected) if (e.isVirtual() || e.kind() != FileKind.ARCHIVE) allArchives = false;
        btnSelExtract.setVisibility(virtual || allArchives ? View.VISIBLE : View.GONE);
        int fsOnly = virtual ? View.GONE : View.VISIBLE;
        btnSelCopy.setVisibility(fsOnly);
        btnSelCut.setVisibility(fsOnly);
        btnSelDelete.setVisibility(fsOnly);
        btnSelCompress.setVisibility(fsOnly);
        btnSelShare.setVisibility(fsOnly);
        btnSelInfo.setVisibility(fsOnly);
        btnSelRename.setVisibility(!virtual && selected.size() == 1 ? View.VISIBLE : View.GONE);
        updateBackCallback();
        updateNewButton();
    }

    private void updateNewButton() {
        if (btnNew == null) return;
        boolean can = archiveFile == null && !searchResultsMode && !selectionMode && PermissionHelper.hasStorage(requireContext());
        btnNew.setVisibility(can ? View.VISIBLE : View.GONE);
    }

    private List<File> selectedFiles() {
        List<File> files = new ArrayList<>();
        if (adapter == null) return files;
        for (FileEntry e : adapter.getSelected()) if (e.file != null) files.add(e.file);
        return files;
    }

    // ================================================================ menus

    private void showMainMenu(View anchor) {
        PopupMenu menu = new PopupMenu(requireContext(), anchor);
        boolean fs = archiveFile == null && !searchResultsMode;
        if (fs) {
            menu.getMenu().add(Menu.NONE, 1, 1, "Nova pasta");
            menu.getMenu().add(Menu.NONE, 2, 2, "Novo arquivo de texto");
        }
        menu.getMenu().add(Menu.NONE, 3, 3, "Ordenar por…");
        menu.getMenu().add(Menu.NONE, 4, 4, "Mostrar arquivos ocultos").setCheckable(true).setChecked(showHidden);
        menu.getMenu().add(Menu.NONE, 5, 5, "Filtrar nesta pasta");
        if (fs) {
            menu.getMenu().add(Menu.NONE, 6, 6, "Buscar em subpastas…");
            boolean fav = FmPrefs.isFavorite(requireContext(), currentDir.getAbsolutePath());
            menu.getMenu().add(Menu.NONE, 7, 7, fav ? "Remover dos favoritos" : "Adicionar aos favoritos");
        }
        menu.getMenu().add(Menu.NONE, 8, 8, "Maiores arquivos");
        menu.getMenu().add(Menu.NONE, 9, 9, "Atualizar");
        menu.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1: promptNewFolder(); break;
                case 2: promptNewFile(); break;
                case 3: showSortDialog(); break;
                case 4:
                    showHidden = !showHidden;
                    FmPrefs.setShowHidden(requireContext(), showHidden);
                    reloadCurrent();
                    break;
                case 5: openFilter(); break;
                case 6: promptDeepSearch(); break;
                case 7: toggleFavorite(); break;
                case 8: scanLargest(); break;
                case 9: reloadCurrent(); break;
                default: return false;
            }
            return true;
        });
        menu.show();
    }

    private void showNewMenu(View anchor) {
        PopupMenu menu = new PopupMenu(requireContext(), anchor);
        menu.getMenu().add(Menu.NONE, 1, 1, "Nova pasta");
        menu.getMenu().add(Menu.NONE, 2, 2, "Novo arquivo de texto");
        menu.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == 1) promptNewFolder(); else promptNewFile();
            return true;
        });
        menu.show();
    }

    private void showSortDialog() {
        final String[] labels = {"Nome (A–Z)", "Nome (Z–A)", "Tamanho (maior primeiro)", "Tamanho (menor primeiro)",
                "Data (mais recentes)", "Data (mais antigos)", "Tipo"};
        final FileOps.SortKey[] keys = {FileOps.SortKey.NAME, FileOps.SortKey.NAME, FileOps.SortKey.SIZE,
                FileOps.SortKey.SIZE, FileOps.SortKey.DATE, FileOps.SortKey.DATE, FileOps.SortKey.TYPE};
        final boolean[] asc = {true, false, false, true, false, true, true};
        int current = 0;
        for (int i = 0; i < keys.length; i++) if (keys[i] == sortKey && asc[i] == sortAscending) current = i;
        new AlertDialog.Builder(requireContext())
                .setTitle("Ordenar por")
                .setSingleChoiceItems(labels, current, (dialog, which) -> {
                    sortKey = keys[which];
                    sortAscending = asc[which];
                    FmPrefs.setSort(requireContext(), sortKey, sortAscending);
                    dialog.dismiss();
                    reloadCurrent();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void toggleFavorite() {
        String path = currentDir.getAbsolutePath();
        boolean now = !FmPrefs.isFavorite(requireContext(), path);
        FmPrefs.setFavorite(requireContext(), path, now);
        Toast.makeText(requireContext(), now ? "Adicionado aos favoritos." : "Removido dos favoritos.", Toast.LENGTH_SHORT).show();
        buildPlaces();
    }

    private void openFilter() {
        if (etSearch == null) return;
        etSearch.setVisibility(View.VISIBLE);
        etSearch.requestFocus();
        InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(etSearch, InputMethodManager.SHOW_IMPLICIT);
        updateBackCallback();
    }

    private void closeFilter() {
        if (etSearch == null) return;
        etSearch.setText("");
        etSearch.setVisibility(View.GONE);
        filterText = "";
        InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(etSearch.getWindowToken(), 0);
        applyFilter();
        updateBackCallback();
    }

    // ================================================================ criar / renomear / excluir

    private void prompt(String title, String hint, String initial, String positive, final TextAction action) {
        final EditText input = new EditText(requireContext());
        input.setSingleLine(true);
        input.setHint(hint);
        input.setText(initial);
        input.setSelection(0, initial == null ? 0 : initial.length());
        FrameWrap wrap = new FrameWrap(requireContext(), input);
        new AlertDialog.Builder(requireContext())
                .setTitle(title)
                .setView(wrap.view)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton(positive, (d, w) -> action.accept(input.getText().toString()))
                .show();
    }

    /** Dá margem lateral ao campo de texto dentro do diálogo. */
    private final class FrameWrap {
        final LinearLayout view;

        FrameWrap(Context ctx, View child) {
            view = new LinearLayout(ctx);
            view.setPadding(dp(20), dp(8), dp(20), 0);
            view.addView(child, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
    }

    private void promptNewFolder() {
        prompt("Nova pasta", "Nome da pasta", "", "Criar", name -> {
            try {
                FileOps.createFolder(currentDir, name);
                reloadCurrent();
            } catch (Exception e) {
                toast(e.getMessage());
            }
        });
    }

    private void promptNewFile() {
        prompt("Novo arquivo de texto", "Nome do arquivo", "novo.txt", "Criar", name -> {
            try {
                FileOps.createFile(currentDir, name);
                reloadCurrent();
            } catch (Exception e) {
                toast(e.getMessage());
            }
        });
    }

    private void showRenameDialog() {
        List<File> files = selectedFiles();
        if (files.size() != 1) return;
        final File file = files.get(0);
        prompt("Renomear", "Novo nome", file.getName(), "Renomear", name -> {
            try {
                FileOps.rename(file, name);
                exitSelection();
                reloadCurrent();
            } catch (Exception e) {
                toast(e.getMessage());
            }
        });
    }

    private void confirmDelete() {
        final List<File> files = selectedFiles();
        if (files.isEmpty()) return;
        new AlertDialog.Builder(requireContext())
                .setTitle("Excluir " + files.size() + " item(ns)?")
                .setMessage("Esta ação não pode ser desfeita. Pastas serão excluídas com todo o conteúdo.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (d, w) -> {
                    exitSelection();
                    runOperation("Excluindo…", (p, c) -> {
                        int done = 0;
                        for (File f : files) {
                            c.check();
                            p.onProgress(f.getName(), done, files.size());
                            FileOps.delete(f, c);
                            done++;
                        }
                        return done + " item(ns) excluído(s).";
                    });
                })
                .show();
    }

    // ================================================================ copiar / mover / colar

    private void clipSelected(boolean move) {
        List<File> files = selectedFiles();
        if (files.isEmpty()) return;
        FileClipboard.set(files, move);
        exitSelection();
        updatePasteBar();
        toast((move ? "Mover: " : "Copiar: ") + files.size() + " item(ns). Abra a pasta de destino e toque em Colar.");
    }

    private void updatePasteBar() {
        if (barPaste == null) return;
        boolean show = FileClipboard.hasItems() && archiveFile == null && !searchResultsMode && !selectionMode;
        barPaste.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) tvClip.setText((FileClipboard.isCut() ? "Mover " : "Copiar ") + FileClipboard.files().size() + " item(ns)");
    }

    private void paste() {
        if (archiveFile != null || searchResultsMode || currentDir == null) return;
        final File dest = currentDir;
        final List<File> files = FileClipboard.files();
        final boolean cut = FileClipboard.isCut();
        runOperation(cut ? "Movendo…" : "Copiando…", (p, c) -> {
            int done = 0;
            for (File f : files) {
                c.check();
                if (cut) FileOps.move(f, dest, p, c); else FileOps.copy(f, dest, p, c);
                done++;
            }
            if (cut) FileClipboard.clear();
            return done + " item(ns) " + (cut ? "movido(s)." : "copiado(s).");
        });
    }

    // ================================================================ compactar / extrair

    private void showCompressDialog() {
        final List<File> files = selectedFiles();
        if (files.isEmpty()) return;
        final Context ctx = requireContext();
        final ArchiveUtils.Format[] formats = {ArchiveUtils.Format.ZIP, ArchiveUtils.Format.SEVEN_Z,
                ArchiveUtils.Format.TAR_GZ, ArchiveUtils.Format.TAR, ArchiveUtils.Format.GZ};
        String[] formatLabels = {"ZIP", "7Z", "TAR.GZ", "TAR", "GZ (um arquivo)"};
        final int[] levels = {0, 1, 6, 9};
        String[] levelLabels = {"Sem compressão", "Rápida", "Normal", "Máxima"};

        LinearLayout box = new LinearLayout(ctx);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText name = new EditText(ctx);
        name.setSingleLine(true);
        name.setText(files.size() == 1 ? ArchiveUtils.baseName(files.get(0).getName()) : currentDir.getName());
        name.setSelection(name.getText().length());
        final Spinner format = new Spinner(ctx);
        format.setAdapter(new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_dropdown_item, formatLabels));
        final Spinner level = new Spinner(ctx);
        level.setAdapter(new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_dropdown_item, levelLabels));
        level.setSelection(2);
        box.addView(label("Nome do arquivo"));
        box.addView(name);
        box.addView(label("Formato"));
        box.addView(format);
        box.addView(label("Nível de compressão"));
        box.addView(level);

        new AlertDialog.Builder(ctx)
                .setTitle("Compactar " + files.size() + " item(ns)")
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Compactar", (d, w) -> {
                    ArchiveUtils.Format fmt = formats[format.getSelectedItemPosition()];
                    int lvl = levels[level.getSelectedItemPosition()];
                    String base = name.getText().toString().trim();
                    String error = FileOps.validateName(base);
                    if (error != null) { toast(error); return; }
                    if (fmt == ArchiveUtils.Format.GZ && (files.size() != 1 || files.get(0).isDirectory())) {
                        toast("GZ comprime só um arquivo. Escolha TAR.GZ para pastas ou vários itens.");
                        return;
                    }
                    String fileName = base.toLowerCase(Locale.ROOT).endsWith(fmt.extension) ? base : base + fmt.extension;
                    if (fmt == ArchiveUtils.Format.GZ) fileName = files.get(0).getName() + ".gz";
                    final File out = FileOps.uniqueName(currentDir, fileName);
                    exitSelection();
                    runOperation("Compactando…", (p, c) -> {
                        ArchiveUtils.compress(files, out, fmt, lvl, p, c);
                        return "Criado: " + out.getName() + " (" + FormatUtils.formatBytes(out.length()) + ")";
                    });
                })
                .show();
    }

    private TextView label(String text) {
        TextView tv = new TextView(requireContext());
        tv.setText(text);
        tv.setTextSize(12f);
        tv.setPadding(0, dp(10), 0, dp(2));
        return tv;
    }

    private void showArchiveDialog(final File file) {
        final String base = ArchiveUtils.baseName(file.getName());
        final String[] options = {"Abrir (explorar o conteúdo)", "Extrair aqui", "Extrair em pasta “" + base + "”",
                "Extrair em…", "Informações"};
        new AlertDialog.Builder(requireContext())
                .setTitle(file.getName())
                .setItems(options, (d, which) -> {
                    switch (which) {
                        case 0: openArchive(file); break;
                        case 1: extractArchive(file, file.getParentFile(), null, false); break;
                        case 2: extractArchive(file, FileOps.uniqueName(file.getParentFile(), base), null, true); break;
                        case 3: promptExtractTo(file, null); break;
                        default: showProperties(Collections.singletonList(file));
                    }
                })
                .show();
    }

    private void showApkDialog(final File file) {
        final String[] options = {"Instalar", "Explorar como ZIP", "Informações"};
        new AlertDialog.Builder(requireContext())
                .setTitle(file.getName())
                .setItems(options, (d, which) -> {
                    if (which == 0) FileOpener.open(requireContext(), file);
                    else if (which == 1) openArchive(file);
                    else showProperties(Collections.singletonList(file));
                })
                .show();
    }

    private void showScriptDialog(final File file) {
        final String[] options = {"Preparar no Terminal", "Abrir com…"};
        new AlertDialog.Builder(requireContext())
                .setTitle(file.getName())
                .setItems(options, (d, which) -> {
                    if (which == 0 && getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).openTerminalWith("sh " + com.htx.optimize.monitor.FpsParser.quote(file.getAbsolutePath()));
                    } else {
                        FileOpener.open(requireContext(), file);
                    }
                })
                .show();
    }

    private void promptExtractTo(final File archive, @Nullable final Set<String> only) {
        File parent = archive.getParentFile();
        prompt("Extrair em…", "Caminho da pasta de destino", parent == null ? "/sdcard" : parent.getAbsolutePath(), "Extrair", path -> {
            File dest = new File(path.trim());
            if (path.trim().isEmpty() || (dest.exists() && !dest.isDirectory())) {
                toast("Destino inválido.");
                return;
            }
            extractArchive(archive, dest, only, true);
        });
    }

    private void extractSelected() {
        List<FileEntry> selected = adapter.getSelected();
        if (selected.isEmpty()) return;
        if (archiveFile != null) {
            final Set<String> only = new HashSet<>();
            for (FileEntry e : selected) if (e.virtualPath != null) only.add(e.virtualPath);
            final File archive = archiveFile;
            final String base = ArchiveUtils.baseName(archive.getName());
            String[] options = {"Aqui (pasta do arquivo)", "Em pasta “" + base + "”", "Em…"};
            new AlertDialog.Builder(requireContext())
                    .setTitle("Extrair " + only.size() + " item(ns)")
                    .setItems(options, (d, which) -> {
                        exitSelection();
                        if (which == 0) extractArchive(archive, archive.getParentFile(), only, false);
                        else if (which == 1) extractArchive(archive, FileOps.uniqueName(archive.getParentFile(), base), only, true);
                        else promptExtractTo(archive, only);
                    })
                    .show();
        } else {
            final List<File> files = selectedFiles();
            exitSelection();
            for (File f : files) {
                String base = ArchiveUtils.baseName(f.getName());
                extractArchive(f, FileOps.uniqueName(f.getParentFile(), base), null, true);
            }
        }
    }

    private void extractArchive(final File archive, final File dest, @Nullable final Set<String> only, final boolean createDest) {
        if (dest == null) return;
        runOperation("Extraindo " + archive.getName() + "…", (p, c) -> {
            if (createDest && !dest.isDirectory() && !dest.mkdirs()) throw new java.io.IOException("Não foi possível criar a pasta de destino.");
            ArchiveUtils.extract(archive, dest, only, p, c);
            return "Extraído em: " + dest.getAbsolutePath();
        });
    }

    private void openArchive(final File file) {
        if (tvInfo != null) tvInfo.setText("Lendo " + file.getName() + "…");
        ops.execute(() -> {
            try {
                final List<ArchiveUtils.Entry> entries = ArchiveUtils.list(file);
                main.post(() -> {
                    if (!isAdded() || getView() == null) return;
                    exitSelection();
                    archiveFile = file;
                    archiveEntries = entries;
                    archivePrefix = "";
                    searchResultsMode = false;
                    renderPath();
                    showArchiveLevel();
                    updatePasteBar();
                });
            } catch (final Exception e) {
                main.post(() -> {
                    if (isAdded()) {
                        toast("Não foi possível abrir: " + e.getMessage());
                        if (tvInfo != null) tvInfo.setText("");
                    }
                });
            }
        });
    }

    private void showArchiveLevel() {
        if (archiveFile == null || archiveEntries == null) return;
        Map<String, FileEntry> children = new LinkedHashMap<>();
        for (ArchiveUtils.Entry e : archiveEntries) {
            String rest;
            if (archivePrefix.isEmpty()) {
                rest = e.path;
            } else if (e.path.startsWith(archivePrefix + "/")) {
                rest = e.path.substring(archivePrefix.length() + 1);
            } else {
                continue;
            }
            if (rest.isEmpty()) continue;
            int slash = rest.indexOf('/');
            String name = slash < 0 ? rest : rest.substring(0, slash);
            boolean isDir = slash >= 0 || e.dir;
            String childPath = archivePrefix.isEmpty() ? name : archivePrefix + "/" + name;
            FileEntry existing = children.get(name);
            if (existing == null || (isDir && !existing.dir)) {
                children.put(name, new FileEntry(childPath, name, isDir, isDir ? 0L : e.size, e.modified));
            }
        }
        List<FileEntry> list = new ArrayList<>(children.values());
        Collections.sort(list, (a, b) -> {
            if (a.dir != b.dir) return a.dir ? -1 : 1;
            return a.name.toLowerCase(Locale.ROOT).compareTo(b.name.toLowerCase(Locale.ROOT));
        });
        baseItems = list;
        renderPath();
        applyFilter();
        updateBackCallback();
        updateNewButton();
        updatePasteBar();
        if (tvInfo != null) tvInfo.setText("Dentro do arquivo • " + list.size() + " item(ns) • segure para selecionar e extrair");
        if (tvEmpty != null) tvEmpty.setText("Vazio");
    }

    private void extractAndOpen(final FileEntry entry) {
        if (archiveFile == null) return;
        final File archive = archiveFile;
        final File temp = new File(requireContext().getCacheDir(), "fm_open/" + System.nanoTime());
        final Set<String> only = Collections.singleton(entry.virtualPath);
        runOperation("Extraindo " + entry.name + "…", (p, c) -> {
            ArchiveUtils.extract(archive, temp, only, p, c);
            final File extracted = new File(temp, entry.virtualPath);
            main.post(() -> { if (isAdded() && extracted.isFile()) FileOpener.open(requireContext(), extracted); });
            return "Abrindo " + entry.name;
        });
    }

    // ================================================================ busca / propriedades

    private void promptDeepSearch() {
        prompt("Buscar em subpastas", "Parte do nome", "", "Buscar", query -> {
            if (query.trim().isEmpty()) return;
            final File base = currentDir;
            final boolean hidden = showHidden;
            final String q = query.trim();
            if (tvInfo != null) tvInfo.setText("Buscando “" + q + "”…");
            final int gen = generation.incrementAndGet();
            lister.execute(() -> {
                List<File> hits = FileOps.search(base, q, 500, hidden, null);
                final List<FileEntry> entries = new ArrayList<>();
                String basePath = base.getAbsolutePath();
                for (File f : hits) {
                    String parent = f.getParent() == null ? "" : f.getParent();
                    String rel = parent.startsWith(basePath) ? parent.substring(basePath.length()) : parent;
                    entries.add(new FileEntry(f, f.isDirectory() ? FileOps.childCount(f) : -1, rel.isEmpty() ? "(esta pasta)" : rel));
                }
                main.post(() -> {
                    if (gen != generation.get() || !isAdded() || getView() == null) return;
                    exitSelection();
                    searchResultsMode = true;
                    searchTitle = q;
                    baseItems = entries;
                    renderPath();
                    applyFilter();
                    updateBackCallback();
                    updateNewButton();
                    updatePasteBar();
                    if (tvInfo != null) tvInfo.setText(entries.size() + " resultado(s)" + (entries.size() >= 500 ? " (limite)" : ""));
                    if (tvEmpty != null) tvEmpty.setText("Nada encontrado");
                });
            });
        });
    }

    /** Lista os maiores arquivos do armazenamento interno (substitui o antigo analisador de espaço). */
    private void scanLargest() {
        if (!ensureAccess()) return;
        exitSelection();
        if (tvInfo != null) tvInfo.setText("Procurando os maiores arquivos…");
        final int gen = generation.incrementAndGet();
        final File root = Environment.getExternalStorageDirectory();
        lister.execute(() -> {
            List<File> hits = FileOps.largestFiles(root, 200, 1024L * 1024L, null);
            final List<FileEntry> entries = new ArrayList<>();
            String basePath = root.getAbsolutePath();
            long total = 0L;
            for (File f : hits) {
                String parent = f.getParent() == null ? "" : f.getParent();
                String rel = parent.startsWith(basePath) ? parent.substring(basePath.length()) : parent;
                entries.add(new FileEntry(f, -1, rel.isEmpty() ? "/" : rel));
                total += f.length();
            }
            final long sum = total;
            main.post(() -> {
                if (gen != generation.get() || !isAdded() || getView() == null) return;
                searchResultsMode = true;
                searchTitle = "Maiores arquivos";
                baseItems = entries;
                renderPath();
                applyFilter();
                updateBackCallback();
                updateNewButton();
                updatePasteBar();
                if (tvInfo != null) tvInfo.setText(entries.size() + " arquivo(s) • " + FormatUtils.formatBytes(sum)
                        + " no total • segure para selecionar e excluir");
                if (tvEmpty != null) tvEmpty.setText("Nenhum arquivo grande encontrado");
            });
        });
    }

    private void showProperties(final List<File> files) {
        if (files.isEmpty()) return;
        final AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle(files.size() == 1 ? files.get(0).getName() : files.size() + " itens")
                .setMessage("Calculando…")
                .setPositiveButton("Fechar", null)
                .create();
        if (files.size() == 1 && files.get(0).isFile()) {
            dialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Checksums", (d, w) -> showChecksums(files.get(0)));
        }
        dialog.show();
        final Context app = requireContext().getApplicationContext();
        ops.execute(() -> {
            long folders = 0, count = 0, bytes = 0;
            for (File f : files) {
                long[] s = FileOps.summarize(f, null);
                folders += s[0];
                count += s[1];
                bytes += s[2];
            }
            StringBuilder sb = new StringBuilder();
            if (files.size() == 1) {
                File f = files.get(0);
                sb.append("Caminho: ").append(f.getAbsolutePath()).append('\n');
                sb.append("Tipo: ").append(f.isDirectory() ? "Pasta" : FileOpener.mimeOf(f)).append('\n');
                sb.append("Modificado: ").append(DateFormat.getMediumDateFormat(app).format(new Date(f.lastModified())))
                        .append(' ').append(DateFormat.getTimeFormat(app).format(new Date(f.lastModified()))).append('\n');
                sb.append("Permissões: ").append(f.canRead() ? "leitura " : "").append(f.canWrite() ? "escrita " : "")
                        .append(f.canExecute() ? "execução" : "").append('\n');
            }
            sb.append("Tamanho: ").append(FormatUtils.formatBytes(bytes)).append(" (").append(bytes).append(" bytes)\n");
            if (folders > 0 || files.size() > 1 || files.get(0).isDirectory()) {
                sb.append("Conteúdo: ").append(folders).append(" pasta(s), ").append(count).append(" arquivo(s)");
            }
            final String text = sb.toString();
            main.post(() -> { if (dialog.isShowing()) dialog.setMessage(text); });
        });
    }

    private void showChecksums(final File file) {
        final AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle("Checksums")
                .setMessage("Calculando…")
                .setPositiveButton("Fechar", null)
                .create();
        dialog.show();
        ops.execute(() -> {
            String text;
            try {
                text = "MD5:\n" + FileOps.hash(file, "MD5", null) + "\n\nSHA-1:\n" + FileOps.hash(file, "SHA-1", null)
                        + "\n\nSHA-256:\n" + FileOps.hash(file, "SHA-256", null);
            } catch (Exception e) {
                text = "Erro: " + e.getMessage();
            }
            final String result = text;
            main.post(() -> { if (dialog.isShowing()) dialog.setMessage(result); });
        });
    }

    // ================================================================ execução com progresso

    private void runOperation(String title, final Task task) {
        if (!isAdded()) return;
        final Context ctx = requireContext();
        final FileOps.Control control = new FileOps.Control();

        LinearLayout box = new LinearLayout(ctx);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(10), dp(22), 0);
        final TextView line = new TextView(ctx);
        line.setSingleLine(true);
        line.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        line.setText("Preparando…");
        final ProgressBar bar = new ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        bar.setMax(1000);
        box.addView(line);
        box.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final AlertDialog dialog = new AlertDialog.Builder(ctx)
                .setTitle(title)
                .setView(box)
                .setCancelable(false)
                .setNegativeButton("Cancelar", null)
                .create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
            control.cancel();
            line.setText("Cancelando…");
            v.setEnabled(false);
        });

        final long[] last = {0L};
        final FileOps.Progress progress = (name, done, total) -> {
            long now = SystemClock.uptimeMillis();
            if (now - last[0] < 120L && (total <= 0 || done < total)) return;
            last[0] = now;
            main.post(() -> {
                if (!dialog.isShowing()) return;
                line.setText(name);
                if (total > 0) {
                    bar.setIndeterminate(false);
                    bar.setProgress((int) Math.min(1000L, done * 1000L / total));
                }
            });
        };

        ops.execute(() -> {
            String message;
            try {
                message = task.run(progress, control);
            } catch (FileOps.CancelledException cancelled) {
                message = "Operação cancelada.";
            } catch (Exception e) {
                message = "Erro: " + (e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName());
            }
            final String result = message;
            main.post(() -> {
                try {
                    dialog.dismiss();
                } catch (RuntimeException ignored) {
                    // tela já destruída
                }
                Toast.makeText(ctx.getApplicationContext(), result, Toast.LENGTH_LONG).show();
                if (isAdded() && getView() != null) {
                    reloadCurrent();
                    updatePasteBar();
                }
            });
        });
    }

    // ================================================================ utilidades

    private void toast(String message) {
        if (isAdded()) Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show();
    }

    private int dp(int value) {
        return Math.round(value * requireContext().getResources().getDisplayMetrics().density);
    }
}
