package com.htx.optimize.files;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Compactar, extrair e listar arquivos. ZIP, TAR, TAR.GZ e GZ são feitos só com o JDK;
 * 7Z e RAR usam bibliotecas opcionais (ver {@link ExternalArchives}).
 */
public final class ArchiveUtils {

    public enum Format {
        ZIP(".zip"), SEVEN_Z(".7z"), TAR(".tar"), TAR_GZ(".tar.gz"), GZ(".gz"), RAR(".rar"), NONE("");

        public final String extension;

        Format(String extension) { this.extension = extension; }

        public boolean canCreate() { return this != RAR && this != NONE; }
    }

    public static final class Entry {
        public final String path;   // sem "/" no início/fim
        public final boolean dir;
        public final long size;     // -1 = desconhecido
        public final long modified; // 0 = desconhecido

        public Entry(String path, boolean dir, long size, long modified) {
            this.path = path;
            this.dir = dir;
            this.size = size;
            this.modified = modified;
        }
    }

    private static final int BUFFER = 64 * 1024;

    private ArchiveUtils() { }

    public static Format detect(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".tar.gz") || n.endsWith(".tgz")) return Format.TAR_GZ;
        if (n.endsWith(".zip") || n.endsWith(".jar") || n.endsWith(".apk") || n.endsWith(".cbz")) return Format.ZIP;
        if (n.endsWith(".7z")) return Format.SEVEN_Z;
        if (n.endsWith(".rar")) return Format.RAR;
        if (n.endsWith(".tar")) return Format.TAR;
        if (n.endsWith(".gz")) return Format.GZ;
        return Format.NONE;
    }

    /** Nome sem a extensão de arquivo compactado (para criar a pasta de extração). */
    public static String baseName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        String[] exts = {".tar.gz", ".tgz", ".zip", ".jar", ".apk", ".cbz", ".7z", ".rar", ".tar", ".gz"};
        for (String ext : exts) {
            if (n.endsWith(ext) && name.length() > ext.length()) return name.substring(0, name.length() - ext.length());
        }
        return name;
    }

    // ------------------------------------------------------------------ API pública

    public static List<Entry> list(File archive) throws IOException {
        switch (detect(archive.getName())) {
            case ZIP: return listZip(archive);
            case TAR: return listTar(archive, false);
            case TAR_GZ: return listTar(archive, true);
            case GZ: {
                List<Entry> single = new ArrayList<>();
                single.add(new Entry(gzOutputName(archive), false, -1L, archive.lastModified()));
                return single;
            }
            case SEVEN_Z: return ExternalArchives.list7z(archive);
            case RAR: return ExternalArchives.listRar(archive);
            default: throw new IOException("Formato não suportado.");
        }
    }

    /** @param only caminhos a extrair (null = tudo); pastas incluem o conteúdo. */
    public static void extract(File archive, File destDir, Set<String> only,
                               FileOps.Progress p, FileOps.Control c) throws IOException {
        FileOps.Control ctl = FileOps.control(c);
        if (!destDir.isDirectory() && !destDir.mkdirs()) throw new IOException("Não foi possível criar a pasta de destino.");
        switch (detect(archive.getName())) {
            case ZIP: extractZip(archive, destDir, only, p, ctl); break;
            case TAR: extractTar(archive, false, destDir, only, p, ctl); break;
            case TAR_GZ: extractTar(archive, true, destDir, only, p, ctl); break;
            case GZ: extractGz(archive, destDir, p, ctl); break;
            case SEVEN_Z: ExternalArchives.extract7z(archive, destDir, only, p, ctl); break;
            case RAR: ExternalArchives.extractRar(archive, destDir, only, p, ctl); break;
            default: throw new IOException("Formato não suportado.");
        }
    }

    /** @param level 0 (sem compressão) a 9 (máxima). */
    public static void compress(List<File> sources, File out, Format format, int level,
                                FileOps.Progress p, FileOps.Control c) throws IOException {
        FileOps.Control ctl = FileOps.control(c);
        if (!format.canCreate()) throw new IOException("Não é possível criar arquivos " + format.extension);
        long total = 0L;
        for (File source : sources) total += FileOps.totalSize(source, ctl);
        Progress counter = new Progress(total, p);
        try {
            switch (format) {
                case ZIP: compressZip(sources, out, level, counter, ctl); break;
                case TAR: compressTar(sources, out, false, level, counter, ctl); break;
                case TAR_GZ: compressTar(sources, out, true, level, counter, ctl); break;
                case GZ:
                    if (sources.size() != 1 || sources.get(0).isDirectory()) {
                        throw new IOException("GZ comprime um único arquivo. Use TAR.GZ para várias coisas.");
                    }
                    compressGz(sources.get(0), out, level, counter, ctl);
                    break;
                case SEVEN_Z: ExternalArchives.compress7z(sources, out, counter.total, p, ctl); break;
                default: throw new IOException("Formato não suportado.");
            }
        } catch (IOException | RuntimeException exception) {
            //noinspection ResultOfMethodCallIgnored
            out.delete();
            throw exception;
        }
    }

    // ------------------------------------------------------------------ utilidades

    static final class Progress {
        final long total;
        long done;
        private final FileOps.Progress listener;

        Progress(long total, FileOps.Progress listener) {
            this.total = total;
            this.listener = listener;
        }

        void add(String name, int bytes) {
            done += bytes;
            if (listener != null) listener.onProgress(name, done, total);
        }
    }

    static String normalize(String name) {
        String clean = name.replace('\\', '/');
        while (clean.startsWith("/")) clean = clean.substring(1);
        while (clean.endsWith("/")) clean = clean.substring(0, clean.length() - 1);
        return clean;
    }

    static boolean included(String path, Set<String> only) {
        if (only == null) return true;
        for (String selected : only) {
            if (path.equals(selected) || path.startsWith(selected + "/")) return true;
        }
        return false;
    }

    /** Resolve o destino impedindo "zip slip" (../ fora da pasta). */
    static File safeResolve(File dest, String entryName) throws IOException {
        File out = new File(dest, normalize(entryName));
        String destPath = dest.getCanonicalPath();
        String outPath = out.getCanonicalPath();
        if (!outPath.equals(destPath) && !outPath.startsWith(destPath + File.separator)) {
            throw new IOException("Entrada insegura no arquivo: " + entryName);
        }
        return out;
    }

    static void ensureParent(File file) throws IOException {
        File parent = file.getParentFile();
        if (parent != null && !parent.isDirectory() && !parent.mkdirs()) {
            throw new IOException("Não foi possível criar a pasta: " + parent.getName());
        }
    }

    private static String gzOutputName(File gz) {
        String name = gz.getName();
        return name.toLowerCase(Locale.ROOT).endsWith(".gz") && name.length() > 3
                ? name.substring(0, name.length() - 3) : name + ".out";
    }

    // ------------------------------------------------------------------ ZIP

    private static ZipFile openZip(File file) throws IOException {
        try {
            return new ZipFile(file, StandardCharsets.UTF_8);
        } catch (IOException | IllegalArgumentException exception) {
            return new ZipFile(file, StandardCharsets.ISO_8859_1); // nomes antigos (CP437/Latin-1)
        }
    }

    private static List<Entry> listZip(File file) throws IOException {
        List<Entry> result = new ArrayList<>();
        try (ZipFile zip = openZip(file)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry e = entries.nextElement();
                String path = normalize(e.getName());
                if (!path.isEmpty()) result.add(new Entry(path, e.isDirectory(), e.getSize(), e.getTime()));
            }
        }
        return result;
    }

    private static void extractZip(File file, File dest, Set<String> only, FileOps.Progress p,
                                   FileOps.Control c) throws IOException {
        try (ZipFile zip = openZip(file)) {
            long total = 0L;
            Enumeration<? extends ZipEntry> scan = zip.entries();
            while (scan.hasMoreElements()) {
                ZipEntry e = scan.nextElement();
                if (!e.isDirectory() && included(normalize(e.getName()), only) && e.getSize() > 0) total += e.getSize();
            }
            Progress counter = new Progress(total, p);
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                c.check();
                ZipEntry e = entries.nextElement();
                String path = normalize(e.getName());
                if (path.isEmpty() || !included(path, only)) continue;
                File out = safeResolve(dest, path);
                if (e.isDirectory()) {
                    //noinspection ResultOfMethodCallIgnored
                    out.mkdirs();
                    continue;
                }
                ensureParent(out);
                try (InputStream in = zip.getInputStream(e);
                     OutputStream os = new BufferedOutputStream(new FileOutputStream(out), BUFFER)) {
                    copyStream(in, os, path, counter, c);
                }
                if (e.getTime() > 0) {
                    //noinspection ResultOfMethodCallIgnored
                    out.setLastModified(e.getTime());
                }
            }
        }
    }

    private static void compressZip(List<File> sources, File out, int level, Progress counter,
                                    FileOps.Control c) throws IOException {
        try (ZipOutputStream zos = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out), BUFFER))) {
            zos.setLevel(Math.max(0, Math.min(9, level)));
            for (File source : sources) addToZip(zos, source, source.getName(), out, counter, c);
        }
    }

    private static void addToZip(ZipOutputStream zos, File file, String name, File out, Progress counter,
                                 FileOps.Control c) throws IOException {
        c.check();
        if (file.equals(out) || FileOps.isSymlink(file)) return;
        if (file.isDirectory()) {
            ZipEntry dir = new ZipEntry(name + "/");
            dir.setTime(file.lastModified());
            zos.putNextEntry(dir);
            zos.closeEntry();
            File[] children = file.listFiles();
            if (children != null) for (File child : children) addToZip(zos, child, name + "/" + child.getName(), out, counter, c);
        } else {
            ZipEntry entry = new ZipEntry(name);
            entry.setTime(file.lastModified());
            zos.putNextEntry(entry);
            try (InputStream in = new BufferedInputStream(new FileInputStream(file), BUFFER)) {
                copyStream(in, zos, name, counter, c);
            }
            zos.closeEntry();
        }
    }

    // ------------------------------------------------------------------ GZ

    private static void compressGz(File file, File out, int level, Progress counter, FileOps.Control c) throws IOException {
        final int lvl = Math.max(0, Math.min(9, level));
        try (InputStream in = new BufferedInputStream(new FileInputStream(file), BUFFER);
             OutputStream os = new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(out), BUFFER)) {
                 { def.setLevel(lvl); }
             }) {
            copyStream(in, os, file.getName(), counter, c);
        }
    }

    private static void extractGz(File file, File dest, FileOps.Progress p, FileOps.Control c) throws IOException {
        File out = FileOps.uniqueName(dest, gzOutputName(file));
        try (InputStream in = new GZIPInputStream(new BufferedInputStream(new FileInputStream(file), BUFFER));
             OutputStream os = new BufferedOutputStream(new FileOutputStream(out), BUFFER)) {
            copyStream(in, os, out.getName(), new Progress(0L, p), c);
        } catch (IOException | RuntimeException exception) {
            //noinspection ResultOfMethodCallIgnored
            out.delete();
            throw exception;
        }
    }

    // ------------------------------------------------------------------ TAR (ustar + GNU longname + PAX path)

    private static final int BLOCK = 512;

    private static final class TarHeader {
        String name;
        long size;
        long mtime;
        char type;
        boolean dir() { return type == '5' || (name != null && name.endsWith("/")); }
        boolean regular() { return type == '0' || type == '\0' || type == '7'; }
    }

    private static InputStream openTar(File file, boolean gzip) throws IOException {
        InputStream in = new BufferedInputStream(new FileInputStream(file), BUFFER);
        return gzip ? new GZIPInputStream(in, BUFFER) : in;
    }

    private static int readFully(InputStream in, byte[] buffer) throws IOException {
        int total = 0;
        while (total < buffer.length) {
            int n = in.read(buffer, total, buffer.length - total);
            if (n < 0) break;
            total += n;
        }
        return total;
    }

    private static void skipFully(InputStream in, long count) throws IOException {
        long remaining = count;
        byte[] sink = null;
        while (remaining > 0) {
            long skipped = in.skip(remaining);
            if (skipped > 0) {
                remaining -= skipped;
            } else {
                if (sink == null) sink = new byte[8192];
                int n = in.read(sink, 0, (int) Math.min(sink.length, remaining));
                if (n < 0) throw new IOException("Arquivo TAR truncado.");
                remaining -= n;
            }
        }
    }

    private static String cString(byte[] buf, int off, int len) {
        int end = off;
        while (end < off + len && buf[end] != 0) end++;
        return new String(buf, off, end - off, StandardCharsets.UTF_8);
    }

    private static long parseNumber(byte[] buf, int off, int len) {
        if ((buf[off] & 0x80) != 0) { // base-256 (arquivos grandes)
            long value = buf[off] & 0x7F;
            for (int i = 1; i < len; i++) value = (value << 8) | (buf[off + i] & 0xFF);
            return value;
        }
        long value = 0L;
        int i = off;
        while (i < off + len && buf[i] == ' ') i++; // espaços à esquerda
        for (; i < off + len; i++) {
            byte b = buf[i];
            if (b < '0' || b > '7') break; // NUL/espaço encerram o número
            value = value * 8 + (b - '0');
        }
        return value;
    }

    /** Lê o próximo cabeçalho útil (resolvendo nomes longos GNU/PAX). null = fim do arquivo. */
    private static TarHeader nextHeader(InputStream in) throws IOException {
        String longName = null;
        long paxSize = -1L;
        byte[] block = new byte[BLOCK];
        while (true) {
            int n = readFully(in, block);
            if (n < BLOCK) return null;
            boolean zero = true;
            for (byte b : block) { if (b != 0) { zero = false; break; } }
            if (zero) return null;

            TarHeader h = new TarHeader();
            h.name = cString(block, 0, 100);
            h.size = parseNumber(block, 124, 12);
            h.mtime = parseNumber(block, 136, 12) * 1000L;
            h.type = (char) (block[156] & 0xFF);
            String magic = cString(block, 257, 6);
            if (magic.startsWith("ustar")) {
                String prefix = cString(block, 345, 155);
                if (!prefix.isEmpty()) h.name = prefix + "/" + h.name;
            }
            long padded = ((h.size + BLOCK - 1) / BLOCK) * BLOCK;

            if (h.type == 'L') { // GNU: nome longo
                byte[] data = new byte[(int) Math.min(h.size, 1 << 20)];
                if (readFully(in, data) < data.length) throw new IOException("Arquivo TAR truncado.");
                skipFully(in, padded - data.length);
                longName = cString(data, 0, data.length);
                continue;
            }
            if (h.type == 'x') { // PAX: path / size
                byte[] data = new byte[(int) Math.min(h.size, 1 << 20)];
                if (readFully(in, data) < data.length) throw new IOException("Arquivo TAR truncado.");
                skipFully(in, padded - data.length);
                String text = new String(data, StandardCharsets.UTF_8);
                for (String line : text.split("\n")) {
                    int space = line.indexOf(' ');
                    int eq = line.indexOf('=');
                    if (space < 0 || eq < space) continue;
                    String key = line.substring(space + 1, eq);
                    String value = line.substring(eq + 1);
                    if (key.equals("path")) longName = value;
                    else if (key.equals("size")) {
                        try { paxSize = Long.parseLong(value.trim()); } catch (NumberFormatException ignored) { /* mantém */ }
                    }
                }
                continue;
            }
            if (h.type == 'g' || h.type == 'K') { // cabeçalhos globais / link longo: ignorar
                skipFully(in, padded);
                continue;
            }
            if (longName != null) h.name = longName;
            if (paxSize >= 0) h.size = paxSize;
            return h;
        }
    }

    private static List<Entry> listTar(File file, boolean gzip) throws IOException {
        List<Entry> result = new ArrayList<>();
        try (InputStream in = openTar(file, gzip)) {
            TarHeader h;
            while ((h = nextHeader(in)) != null) {
                String path = normalize(h.name);
                if ((h.dir() || h.regular()) && !path.isEmpty()) {
                    result.add(new Entry(path, h.dir(), h.dir() ? 0L : h.size, h.mtime));
                }
                skipFully(in, ((h.size + BLOCK - 1) / BLOCK) * BLOCK);
            }
        }
        return result;
    }

    private static void extractTar(File file, boolean gzip, File dest, Set<String> only,
                                   FileOps.Progress p, FileOps.Control c) throws IOException {
        Progress counter = new Progress(0L, p);
        try (InputStream in = openTar(file, gzip)) {
            TarHeader h;
            while ((h = nextHeader(in)) != null) {
                c.check();
                String path = normalize(h.name);
                long padded = ((h.size + BLOCK - 1) / BLOCK) * BLOCK;
                boolean wanted = !path.isEmpty() && included(path, only);
                if (wanted && h.dir()) {
                    File dir = safeResolve(dest, path);
                    //noinspection ResultOfMethodCallIgnored
                    dir.mkdirs();
                    skipFully(in, padded);
                } else if (wanted && h.regular()) {
                    File out = safeResolve(dest, path);
                    ensureParent(out);
                    try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out), BUFFER)) {
                        long remaining = h.size;
                        byte[] buffer = new byte[BUFFER];
                        while (remaining > 0) {
                            c.check();
                            int n = in.read(buffer, 0, (int) Math.min(buffer.length, remaining));
                            if (n < 0) throw new IOException("Arquivo TAR truncado.");
                            os.write(buffer, 0, n);
                            remaining -= n;
                            counter.add(path, n);
                        }
                    }
                    if (h.mtime > 0) {
                        //noinspection ResultOfMethodCallIgnored
                        out.setLastModified(h.mtime);
                    }
                    skipFully(in, padded - h.size);
                } else {
                    skipFully(in, padded);
                }
            }
        }
    }

    private static void compressTar(List<File> sources, File out, boolean gzip, int level, Progress counter,
                                    FileOps.Control c) throws IOException {
        final int lvl = Math.max(0, Math.min(9, level));
        OutputStream raw = new BufferedOutputStream(new FileOutputStream(out), BUFFER);
        OutputStream os = gzip ? new GZIPOutputStream(raw) { { def.setLevel(lvl); } } : raw;
        try {
            for (File source : sources) addToTar(os, source, source.getName(), out, counter, c);
            os.write(new byte[BLOCK * 2]); // fim do arquivo
            os.flush();
        } finally {
            os.close();
        }
    }

    private static void addToTar(OutputStream os, File file, String name, File out, Progress counter,
                                 FileOps.Control c) throws IOException {
        c.check();
        if (file.equals(out) || FileOps.isSymlink(file)) return;
        if (file.isDirectory()) {
            writeTarHeader(os, name + "/", 0L, file.lastModified(), '5');
            File[] children = file.listFiles();
            if (children != null) for (File child : children) addToTar(os, child, name + "/" + child.getName(), out, counter, c);
        } else {
            long size = file.length();
            writeTarHeader(os, name, size, file.lastModified(), '0');
            long written = 0L;
            try (InputStream in = new BufferedInputStream(new FileInputStream(file), BUFFER)) {
                byte[] buffer = new byte[BUFFER];
                int n;
                while (written < size && (n = in.read(buffer, 0, (int) Math.min(buffer.length, size - written))) > 0) {
                    c.check();
                    os.write(buffer, 0, n);
                    written += n;
                    counter.add(name, n);
                }
            }
            if (written != size) throw new IOException("O arquivo mudou durante a compactação: " + name);
            int pad = (int) ((BLOCK - (size % BLOCK)) % BLOCK);
            if (pad > 0) os.write(new byte[pad]);
        }
    }

    private static void writeTarHeader(OutputStream os, String name, long size, long mtimeMs, char type) throws IOException {
        byte[] nameBytes = name.getBytes(StandardCharsets.UTF_8);
        String prefix = "";
        String shortName = name;
        if (nameBytes.length > 100) {
            int split = -1;
            for (int i = name.length() - 1; i > 0; i--) {
                if (name.charAt(i) == '/') {
                    String left = name.substring(0, i);
                    String right = name.substring(i + 1);
                    if (left.getBytes(StandardCharsets.UTF_8).length <= 155
                            && right.getBytes(StandardCharsets.UTF_8).length <= 100 && !right.isEmpty()) {
                        split = i;
                        break;
                    }
                }
            }
            if (split > 0) {
                prefix = name.substring(0, split);
                shortName = name.substring(split + 1);
            } else { // nome longo GNU
                byte[] data = new byte[nameBytes.length + 1];
                System.arraycopy(nameBytes, 0, data, 0, nameBytes.length);
                os.write(buildTarHeader("././@LongLink", "", data.length, 0L, 'L'));
                os.write(data);
                int pad = (BLOCK - (data.length % BLOCK)) % BLOCK;
                if (pad > 0) os.write(new byte[pad]);
                shortName = name.substring(0, Math.min(name.length(), 90));
            }
        }
        os.write(buildTarHeader(shortName, prefix, size, mtimeMs / 1000L, type));
    }

    private static byte[] buildTarHeader(String name, String prefix, long size, long mtimeSec, char type) throws IOException {
        if (size > 077777777777L) throw new IOException("Arquivo grande demais para TAR (máx. 8 GB): " + name);
        byte[] h = new byte[BLOCK];
        putString(h, 0, 100, name);
        putOctal(h, 100, 8, type == '5' ? 0755 : 0644);
        putOctal(h, 108, 8, 0);
        putOctal(h, 116, 8, 0);
        putOctal(h, 124, 12, size);
        putOctal(h, 136, 12, Math.max(0L, mtimeSec));
        for (int i = 148; i < 156; i++) h[i] = ' ';
        h[156] = (byte) type;
        putString(h, 257, 6, "ustar");
        h[262] = 0;
        h[263] = '0';
        h[264] = '0';
        putOctal(h, 329, 8, 0);
        putOctal(h, 337, 8, 0);
        putString(h, 345, 155, prefix);
        long sum = 0L;
        for (byte b : h) sum += (b & 0xFF);
        String chk = Long.toOctalString(sum);
        while (chk.length() < 6) chk = "0" + chk;
        byte[] chkBytes = chk.getBytes(StandardCharsets.US_ASCII);
        System.arraycopy(chkBytes, 0, h, 148, 6);
        h[154] = 0;
        h[155] = ' ';
        return h;
    }

    private static void putString(byte[] buf, int off, int len, String value) {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        System.arraycopy(bytes, 0, buf, off, Math.min(len, bytes.length));
    }

    private static void putOctal(byte[] buf, int off, int len, long value) throws IOException {
        String s = Long.toOctalString(value);
        if (s.length() > len - 1) throw new IOException("Valor grande demais para o cabeçalho TAR.");
        while (s.length() < len - 1) s = "0" + s;
        byte[] bytes = s.getBytes(StandardCharsets.US_ASCII);
        System.arraycopy(bytes, 0, buf, off, bytes.length);
        buf[off + len - 1] = 0;
    }

    // ------------------------------------------------------------------ cópia com progresso

    static void copyStream(InputStream in, OutputStream out, String name, Progress counter,
                           FileOps.Control c) throws IOException {
        byte[] buffer = new byte[BUFFER];
        int n;
        while ((n = in.read(buffer)) > 0) {
            c.check();
            out.write(buffer, 0, n);
            counter.add(name, n);
        }
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = in.read(buffer)) > 0) bos.write(buffer, 0, n);
        return bos.toByteArray();
    }
}
