package com.htx.optimize.util;

import android.content.Context;
import android.content.SharedPreferences;

public final class AppPrefs {
    private static final String FILE = "htx_prefs";

    private AppPrefs() { }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static boolean realFps(Context c) { return prefs(c).getBoolean("real_fps", true); }
    public static void setRealFps(Context c, boolean v) { prefs(c).edit().putBoolean("real_fps", v).apply(); }

    public static boolean deepBoost(Context c) { return prefs(c).getBoolean("deep_boost", false); }
    public static void setDeepBoost(Context c, boolean v) { prefs(c).edit().putBoolean("deep_boost", v).apply(); }

    /** 30..100 */
    public static int overlayOpacity(Context c) {
        return Math.max(30, Math.min(100, prefs(c).getInt("overlay_opacity", 92)));
    }
    public static void setOverlayOpacity(Context c, int v) {
        prefs(c).edit().putInt("overlay_opacity", Math.max(30, Math.min(100, v))).apply();
    }

    public static boolean overlayBig(Context c) { return prefs(c).getBoolean("overlay_big", false); }
    public static void setOverlayBig(Context c, boolean v) { prefs(c).edit().putBoolean("overlay_big", v).apply(); }

    public static boolean overlayGraph(Context c) { return prefs(c).getBoolean("overlay_graph", true); }
    public static void setOverlayGraph(Context c, boolean v) { prefs(c).edit().putBoolean("overlay_graph", v).apply(); }

    public static boolean overlayCompact(Context c) { return prefs(c).getBoolean("overlay_compact", false); }
    public static void setOverlayCompact(Context c, boolean v) { prefs(c).edit().putBoolean("overlay_compact", v).apply(); }

    public static boolean introShown(Context c) { return prefs(c).getBoolean("intro_shown", false); }
    public static void setIntroShown(Context c) { prefs(c).edit().putBoolean("intro_shown", true).apply(); }
}
