package com.htx.optimize.files;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Área de transferência do gerenciador (copiar/mover), mantida entre telas. */
public final class FileClipboard {
    private static final List<File> FILES = new ArrayList<>();
    private static boolean cut;

    private FileClipboard() { }

    public static synchronized void set(List<File> files, boolean move) {
        FILES.clear();
        FILES.addAll(files);
        cut = move;
    }

    public static synchronized List<File> files() { return new ArrayList<>(FILES); }

    public static synchronized boolean isCut() { return cut; }

    public static synchronized boolean hasItems() { return !FILES.isEmpty(); }

    public static synchronized void clear() { FILES.clear(); }
}
