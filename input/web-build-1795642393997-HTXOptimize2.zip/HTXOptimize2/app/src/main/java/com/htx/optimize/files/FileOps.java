package com.htx.optimize.files;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.PriorityQueue;

/** Operações de arquivo sem dependências do Android (copiar, mover, excluir, buscar...). */
public final class FileOps {

    public interface Progress {
        void onProgress(String current, long done, long total);
    }

    public static final class CancelledException extends IOException {
        public CancelledException() { super("Cancelado"); }
    }

    /** Permite cancelar operações longas de outra thread. */
    public static final class Control {
        private volatile boolean cancelled;

        public void cancel() { cancelled = true; }

        public boolean isCancelled() { return cancelled; }

        public void check() throws IOException {
            if (cancelled) throw new CancelledException();
        }
    }

    public enum SortKey { NAME, SIZE, DATE, TYPE }

    private static final class Counter {
        long done;
        final long total;

        Counter(long total) { this.total = total; }
    }

    private static final int BUFFER = 64 * 1024;

    private FileOps() { }

    public static Control control(Control c) { return c != null ? c : new Control(); }

    // ---------------------------------------------------------------- listagem

    public static List<File> listSorted(File dir, boolean showHidden, SortKey key, boolean ascending) {
        File[] children = dir.listFiles();
        List<File> result = new ArrayList<>();
        if (children == null) return result;

        final class Row {
            final File file;
            final boolean directory;
            final long size, modified;
            final String lowerName, ext;

            Row(File f) {
                file = f;
                directory = f.isDirectory();
                size = directory ? 0L : f.length();
                modified = f.lastModified();
                lowerName = f.getName().toLowerCase(Locale.ROOT);
                int dot = lowerName.lastIndexOf('.');
                ext = dot > 0 ? lowerName.substring(dot + 1) : "";
            }
        }
        List<Row> rows = new ArrayList<>();
        for (File child : children) {
            if (!showHidden && child.getName().startsWith(".")) continue;
            rows.add(new Row(child));
        }
        final int sign = ascending ? 1 : -1;
        final SortKey k = key == null ? SortKey.NAME : key;
        Collections.sort(rows, new Comparator<Row>() {
            @Override public int compare(Row a, Row b) {
                if (a.directory != b.directory) return a.directory ? -1 : 1; // pastas primeiro
                int r;
                switch (k) {
                    case SIZE: r = a.directory ? a.lowerName.compareTo(b.lowerName) : Long.compare(a.size, b.size); break;
                    case DATE: r = Long.compare(a.modified, b.modified); break;
                    case TYPE: r = a.directory ? a.lowerName.compareTo(b.lowerName)
                            : (a.ext.equals(b.ext) ? a.lowerName.compareTo(b.lowerName) : a.ext.compareTo(b.ext)); break;
                    default: r = a.lowerName.compareTo(b.lowerName);
                }
                if (r == 0) r = a.lowerName.compareTo(b.lowerName);
                return r * sign;
            }
        });
        for (Row row : rows) result.add(row.file);
        return result;
    }

    public static int childCount(File dir) {
        String[] names = dir.list();
        return names == null ? -1 : names.length;
    }

    // ---------------------------------------------------------------- utilidades

    public static boolean isSymlink(File file) {
        try {
            File parent = file.getParentFile();
            File canon = parent == null ? file : new File(parent.getCanonicalFile(), file.getName());
            return !canon.getCanonicalFile().equals(canon.getAbsoluteFile());
        } catch (IOException exception) {
            return true;
        }
    }

    /** true se {@code child} é o próprio {@code parent} ou está dentro dele. */
    public static boolean isInside(File parent, File child) {
        try {
            String p = parent.getCanonicalPath();
            String c = child.getCanonicalPath();
            return c.equals(p) || c.startsWith(p.endsWith(File.separator) ? p : p + File.separator);
        } catch (IOException exception) {
            return false;
        }
    }

    public static long totalSize(File file, Control c) {
        Control ctl = control(c);
        if (ctl.isCancelled()) return 0L;
        if (!file.isDirectory()) return file.length();
        if (isSymlink(file)) return 0L;
        long total = 0L;
        File[] children = file.listFiles();
        if (children == null) return 0L;
        for (File child : children) {
            if (ctl.isCancelled()) return total;
            total += totalSize(child, ctl);
        }
        return total;
    }

    public static File uniqueName(File dir, String name) {
        File candidate = new File(dir, name);
        if (!candidate.exists()) return candidate;
        String lower = name.toLowerCase(Locale.ROOT);
        String base = name;
        String ext = "";
        String[] doubles = {".tar.gz", ".tar.bz2", ".tar.xz"};
        boolean matched = false;
        for (String d : doubles) {
            if (lower.endsWith(d)) {
                base = name.substring(0, name.length() - d.length());
                ext = name.substring(name.length() - d.length());
                matched = true;
                break;
            }
        }
        if (!matched) {
            int dot = name.lastIndexOf('.');
            if (dot > 0) {
                base = name.substring(0, dot);
                ext = name.substring(dot);
            }
        }
        for (int i = 1; i < 10000; i++) {
            candidate = new File(dir, base + " (" + i + ")" + ext);
            if (!candidate.exists()) return candidate;
        }
        return new File(dir, base + "_" + System.currentTimeMillis() + ext);
    }

    public static String validateName(String name) {
        if (name == null || name.trim().isEmpty()) return "O nome não pode ficar vazio.";
        if (name.contains("/") || name.contains("\0")) return "O nome não pode conter \"/\".";
        if (name.equals(".") || name.equals("..")) return "Nome inválido.";
        if (name.length() > 255) return "Nome muito longo (máx. 255).";
        return null;
    }

    // ---------------------------------------------------------------- criar / renomear

    public static File createFolder(File parent, String name) throws IOException {
        String error = validateName(name);
        if (error != null) throw new IOException(error);
        File folder = new File(parent, name.trim());
        if (folder.exists()) throw new IOException("Já existe um item com esse nome.");
        if (!folder.mkdirs()) throw new IOException("Não foi possível criar a pasta.");
        return folder;
    }

    public static File createFile(File parent, String name) throws IOException {
        String error = validateName(name);
        if (error != null) throw new IOException(error);
        File file = new File(parent, name.trim());
        if (file.exists()) throw new IOException("Já existe um item com esse nome.");
        if (!file.createNewFile()) throw new IOException("Não foi possível criar o arquivo.");
        return file;
    }

    public static File rename(File file, String newName) throws IOException {
        String error = validateName(newName);
        if (error != null) throw new IOException(error);
        File target = new File(file.getParentFile(), newName.trim());
        if (target.equals(file)) return file;
        if (target.exists()) throw new IOException("Já existe um item com esse nome.");
        if (!file.renameTo(target)) throw new IOException("Não foi possível renomear (permissão negada?).");
        return target;
    }

    // ---------------------------------------------------------------- copiar / mover / excluir

    public static File copy(File src, File destDir, Progress p, Control c) throws IOException {
        Control ctl = control(c);
        if (!src.exists()) throw new IOException("A origem não existe: " + src.getName());
        if (src.isDirectory() && isInside(src, destDir)) {
            throw new IOException("Não é possível copiar uma pasta para dentro dela mesma.");
        }
        Counter counter = new Counter(totalSize(src, ctl));
        File target = uniqueName(destDir, src.getName());
        try {
            copyInto(src, target, counter, p, ctl);
        } catch (IOException | RuntimeException exception) {
            deleteQuietly(target);
            throw exception;
        }
        return target;
    }

    private static void copyInto(File src, File target, Counter counter, Progress p, Control c) throws IOException {
        c.check();
        if (src.isDirectory()) {
            if (!target.mkdirs() && !target.isDirectory()) throw new IOException("Não foi possível criar: " + target.getName());
            File[] children = src.listFiles();
            if (children != null) {
                for (File child : children) {
                    if (isSymlink(child)) continue;
                    copyInto(child, new File(target, child.getName()), counter, p, c);
                }
            }
            //noinspection ResultOfMethodCallIgnored
            target.setLastModified(src.lastModified());
        } else {
            copyFile(src, target, counter, p, c);
        }
    }

    private static void copyFile(File src, File target, Counter counter, Progress p, Control c) throws IOException {
        try (InputStream in = new BufferedInputStream(new FileInputStream(src), BUFFER);
             OutputStream out = new BufferedOutputStream(new FileOutputStream(target), BUFFER)) {
            byte[] buffer = new byte[BUFFER];
            int read;
            while ((read = in.read(buffer)) > 0) {
                c.check();
                out.write(buffer, 0, read);
                counter.done += read;
                if (p != null) p.onProgress(src.getName(), counter.done, counter.total);
            }
        }
        //noinspection ResultOfMethodCallIgnored
        target.setLastModified(src.lastModified());
    }

    public static File move(File src, File destDir, Progress p, Control c) throws IOException {
        Control ctl = control(c);
        File parent = src.getParentFile();
        if (parent != null && parent.equals(destDir)) return src; // mesma pasta: nada a fazer
        if (src.isDirectory() && isInside(src, destDir)) {
            throw new IOException("Não é possível mover uma pasta para dentro dela mesma.");
        }
        File target = uniqueName(destDir, src.getName());
        if (src.renameTo(target)) return target;
        File copied = copy(src, destDir, p, ctl);
        delete(src, ctl);
        return copied;
    }

    public static void delete(File file, Control c) throws IOException {
        Control ctl = control(c);
        ctl.check();
        if (file.isDirectory() && !isSymlink(file)) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) delete(child, ctl);
        }
        if (!file.delete() && file.exists()) throw new IOException("Não foi possível excluir: " + file.getName());
    }

    public static void deleteQuietly(File file) {
        try {
            delete(file, null);
        } catch (IOException | RuntimeException ignored) {
            // melhor esforço
        }
    }

    // ---------------------------------------------------------------- busca / hash

    public static List<File> search(File root, String query, int limit, boolean showHidden, Control c) {
        List<File> found = new ArrayList<>();
        if (query == null || query.trim().isEmpty()) return found;
        searchWalk(root, query.trim().toLowerCase(Locale.ROOT), limit, showHidden, control(c), found, new int[1], 0);
        return found;
    }

    private static void searchWalk(File dir, String q, int limit, boolean hidden, Control c,
                                   List<File> out, int[] visited, int depth) {
        if (depth > 24 || visited[0] > 300_000 || out.size() >= limit || c.isCancelled()) return;
        File[] children = dir.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (out.size() >= limit || c.isCancelled()) return;
            visited[0]++;
            String name = child.getName();
            if (!hidden && name.startsWith(".")) continue;
            if (name.toLowerCase(Locale.ROOT).contains(q)) out.add(child);
            if (child.isDirectory() && !isSymlink(child)) searchWalk(child, q, limit, hidden, c, out, visited, depth + 1);
        }
    }

    private static final class SizedFile {
        final File file;
        final long size;

        SizedFile(File file, long size) {
            this.file = file;
            this.size = size;
        }
    }

    /** Os maiores arquivos (>= minBytes) sob root, do maior para o menor. Ignora Android/ e links. */
    public static List<File> largestFiles(File root, int limit, long minBytes, Control c) {
        PriorityQueue<SizedFile> heap = new PriorityQueue<>(limit + 1, new Comparator<SizedFile>() {
            @Override public int compare(SizedFile a, SizedFile b) { return Long.compare(a.size, b.size); }
        });
        largestWalk(root, 0, limit, minBytes, control(c), new int[1], heap);
        List<SizedFile> rows = new ArrayList<>(heap);
        Collections.sort(rows, new Comparator<SizedFile>() {
            @Override public int compare(SizedFile a, SizedFile b) { return Long.compare(b.size, a.size); }
        });
        List<File> result = new ArrayList<>();
        for (SizedFile row : rows) result.add(row.file);
        return result;
    }

    private static void largestWalk(File dir, int depth, int limit, long minBytes, Control c, int[] visited,
                                    PriorityQueue<SizedFile> heap) {
        if (depth > 24 || visited[0] > 400_000 || c.isCancelled()) return;
        File[] children = dir.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (c.isCancelled() || visited[0] > 400_000) return;
            visited[0]++;
            if (child.isDirectory()) {
                if (depth == 0 && child.getName().equals("Android")) continue;
                if (!isSymlink(child)) largestWalk(child, depth + 1, limit, minBytes, c, visited, heap);
            } else if (child.isFile()) {
                long length = child.length();
                if (length < minBytes) continue;
                if (heap.size() < limit) {
                    heap.add(new SizedFile(child, length));
                } else if (heap.peek() != null && length > heap.peek().size) {
                    heap.poll();
                    heap.add(new SizedFile(child, length));
                }
            }
        }
    }

    public static String hash(File file, String algorithm, Control c) throws Exception {
        Control ctl = control(c);
        MessageDigest digest = MessageDigest.getInstance(algorithm);
        try (InputStream in = new BufferedInputStream(new FileInputStream(file), BUFFER)) {
            byte[] buffer = new byte[BUFFER];
            int read;
            while ((read = in.read(buffer)) > 0) {
                ctl.check();
                digest.update(buffer, 0, read);
            }
        }
        StringBuilder hex = new StringBuilder();
        for (byte b : digest.digest()) hex.append(String.format(Locale.US, "%02x", b));
        return hex.toString();
    }

    /** Conta pastas e arquivos de forma recursiva: {pastas, arquivos, bytes}. */
    public static long[] summarize(File file, Control c) {
        long[] result = new long[3];
        summarizeInto(file, control(c), result, 0);
        return result;
    }

    private static void summarizeInto(File file, Control c, long[] acc, int depth) {
        if (c.isCancelled() || depth > 64) return;
        if (file.isDirectory()) {
            if (depth > 0) acc[0]++;
            if (isSymlink(file)) return;
            File[] children = file.listFiles();
            if (children != null) for (File child : children) summarizeInto(child, c, acc, depth + 1);
        } else {
            acc[1]++;
            acc[2] += file.length();
        }
    }
}
