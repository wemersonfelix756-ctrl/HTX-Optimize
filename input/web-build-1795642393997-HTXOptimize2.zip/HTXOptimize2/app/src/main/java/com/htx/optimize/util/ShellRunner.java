package com.htx.optimize.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Executa "sh -c" com tempo limite e cancelamento (sem APIs novas do Android). */
public final class ShellRunner {

    public static final class Result {
        public final String output;
        public final int exitCode;
        public final boolean timedOut;
        public final boolean cancelled;

        public Result(String output, int exitCode, boolean timedOut, boolean cancelled) {
            this.output = output;
            this.exitCode = exitCode;
            this.timedOut = timedOut;
            this.cancelled = cancelled;
        }
    }

    private static final int MAX_OUTPUT_BYTES = 1024 * 1024;
    private static final String MARK = "\u001E@@HTX_EXIT=";

    private volatile Process current;
    private volatile boolean cancelled;

    /** @param timeoutMs 0 = sem limite */
    public Result run(String command, String cwd, long timeoutMs) {
        cancelled = false;
        final Process process;
        try {
            ProcessBuilder builder = new ProcessBuilder("sh", "-c", command);
            if (cwd != null && !cwd.isEmpty()) {
                File dir = new File(cwd);
                if (dir.isDirectory()) builder.directory(dir);
            }
            builder.redirectErrorStream(true);
            process = builder.start();
        } catch (IOException exception) {
            return new Result("Erro ao iniciar o comando: " + exception.getMessage() + "\n", 127, false, false);
        }
        current = process;
        try {
            process.getOutputStream().close(); // comandos que leem a entrada (cat) não ficam presos
        } catch (IOException ignored) {
            // sem stdin
        }

        final ByteArrayOutputStream collected = new ByteArrayOutputStream();
        Thread reader = new Thread(new Runnable() {
            @Override public void run() {
                try (InputStream in = process.getInputStream()) {
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = in.read(buffer)) > 0) {
                        synchronized (collected) {
                            if (collected.size() < MAX_OUTPUT_BYTES) collected.write(buffer, 0, n);
                        }
                    }
                } catch (IOException ignored) {
                    // processo encerrado
                }
            }
        });
        reader.setDaemon(true);
        reader.start();

        long deadline = timeoutMs > 0 ? System.currentTimeMillis() + timeoutMs : Long.MAX_VALUE;
        boolean timedOut = false;
        Integer exit = null;
        while (true) {
            try {
                exit = process.exitValue();
                break;
            } catch (IllegalThreadStateException stillRunning) {
                // continua esperando
            }
            if (cancelled) { process.destroy(); break; }
            if (System.currentTimeMillis() > deadline) { timedOut = true; process.destroy(); break; }
            try {
                Thread.sleep(25L);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                cancelled = true;
                process.destroy();
                break;
            }
        }
        try {
            reader.join(600L);
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
        }
        current = null;
        int code;
        if (exit != null) {
            code = exit;
        } else {
            try {
                code = process.exitValue();
            } catch (IllegalThreadStateException stillRunning) {
                code = timedOut ? 124 : 143;
            }
        }
        String text;
        synchronized (collected) {
            text = new String(collected.toByteArray(), StandardCharsets.UTF_8);
        }
        return new Result(text, code, timedOut, cancelled);
    }

    public void cancel() {
        cancelled = true;
        Process p = current;
        if (p != null) p.destroy();
    }

    // ---- transporte pelo AIDL (uma String só) ----

    public static String encode(Result r) {
        return r.output + MARK + r.exitCode + ";" + (r.timedOut ? 1 : 0) + ";" + (r.cancelled ? 1 : 0);
    }

    public static Result decode(String raw) {
        if (raw == null) return new Result("", 1, false, false);
        int idx = raw.lastIndexOf(MARK);
        if (idx < 0) return new Result(raw, 0, false, false);
        String[] parts = raw.substring(idx + MARK.length()).split(";");
        try {
            return new Result(raw.substring(0, idx), Integer.parseInt(parts[0]),
                    parts.length > 1 && parts[1].equals("1"), parts.length > 2 && parts[2].equals("1"));
        } catch (RuntimeException exception) {
            return new Result(raw.substring(0, idx), 1, false, false);
        }
    }
}
