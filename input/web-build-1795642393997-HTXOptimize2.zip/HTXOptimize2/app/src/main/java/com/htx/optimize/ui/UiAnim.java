package com.htx.optimize.ui;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;

/** Animação de entrada em cascata dos cards (fade + subida suave). */
public final class UiAnim {

    private UiAnim() { }

    public static void revealChildren(View root) {
        ViewGroup content = null;
        if (root instanceof ScrollView && ((ScrollView) root).getChildCount() > 0
                && ((ScrollView) root).getChildAt(0) instanceof ViewGroup) {
            content = (ViewGroup) ((ScrollView) root).getChildAt(0);
        } else if (root instanceof ViewGroup) {
            content = (ViewGroup) root;
        }
        if (content == null) return;
        float distance = 22f * root.getResources().getDisplayMetrics().density;
        int count = content.getChildCount();
        for (int i = 0; i < count && i < 12; i++) {
            View child = content.getChildAt(i);
            child.setAlpha(0f);
            child.setTranslationY(distance);
            child.animate().alpha(1f).translationY(0f)
                    .setStartDelay(i * 55L).setDuration(380L).start();
        }
    }
}
