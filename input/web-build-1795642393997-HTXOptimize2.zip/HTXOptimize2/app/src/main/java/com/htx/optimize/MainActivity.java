package com.htx.optimize;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.IdRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.htx.optimize.fragments.AboutFragment;
import com.htx.optimize.fragments.FileManagerFragment;
import com.htx.optimize.fragments.HomeFragment;
import com.htx.optimize.fragments.MonitorFragment;
import com.htx.optimize.fragments.TerminalFragment;
import com.htx.optimize.shizuku.ShizukuBridge;
import com.htx.optimize.terminal.TerminalSession;
import com.htx.optimize.util.AppPrefs;
import com.htx.optimize.util.FormatUtils;
import com.htx.optimize.util.PermissionHelper;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private static final String STATE_SELECTED_TAB = "htx.selected_tab";

    private BottomNavigationView bottomNavigation;
    private TextView tvTopStatus;
    private int selectedTabId = R.id.nav_home;

    private boolean chainActive;
    private boolean waitingRuntime;
    private final boolean[] asked = new boolean[3];

    private final ActivityResultLauncher<String[]> runtimeLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                waitingRuntime = false;
                if (chainActive) requestNext();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View root = findViewById(R.id.root_layout);
        final int left = root.getPaddingLeft();
        final int top = root.getPaddingTop();
        final int right = root.getPaddingRight();
        final int bottom = root.getPaddingBottom();
        ViewCompat.setOnApplyWindowInsetsListener(root, (view, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(left + bars.left, top + bars.top, right + bars.right, bottom + bars.bottom);
            return insets;
        });

        tvTopStatus = findViewById(R.id.tv_top_status);
        tvTopStatus.setOnClickListener(v -> selectTab(R.id.nav_monitor));
        findViewById(R.id.btn_top_about).setOnClickListener(v -> openSecondary(new AboutFragment()));

        bottomNavigation = findViewById(R.id.bottom_navigation);
        if (savedInstanceState != null) {
            selectedTabId = savedInstanceState.getInt(STATE_SELECTED_TAB, R.id.nav_home);
        }
        bottomNavigation.setOnItemReselectedListener(item -> { /* mantém a tela atual */ });
        bottomNavigation.setOnItemSelectedListener(item -> {
            selectedTabId = item.getItemId();
            return showTab(selectedTabId);
        });
        bottomNavigation.setSelectedItemId(savedInstanceState == null ? R.id.nav_home : selectedTabId);

        if (savedInstanceState == null && !PermissionHelper.allGranted(this) && !AppPrefs.introShown(this)) {
            AppPrefs.setIntroShown(this);
            new AlertDialog.Builder(this)
                    .setTitle("Permissões")
                    .setMessage("Para liberar todos os recursos, o HTX Optimize pede:\n\n"
                            + "• Acesso aos arquivos (gerenciador e limpeza)\n"
                            + "• Sobrepor outros apps (janelinha de FPS)\n"
                            + "• Notificações (serviço da janelinha)\n\n"
                            + "Você pode conceder depois pela tela Início.")
                    .setNegativeButton("Agora não", null)
                    .setPositiveButton("Continuar", (d, w) -> startPermissionFlow())
                    .show();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        updateTopStatus();
        if (chainActive && !waitingRuntime) requestNext();
    }

    private void updateTopStatus() {
        String version = "";
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            if (info.versionName != null) version = " • v" + info.versionName;
        } catch (Exception ignored) {
            // sem versão
        }
        String shizuku;
        switch (ShizukuBridge.state(this)) {
            case READY: shizuku = "Shizuku ativo"; break;
            case NO_PERMISSION: shizuku = "Shizuku sem autorização"; break;
            case NOT_RUNNING: shizuku = "Shizuku parado"; break;
            default: shizuku = "Shizuku não instalado";
        }
        tvTopStatus.setText(shizuku + version);
    }

    /** Pede, em sequência, notificações, armazenamento e sobreposição de apps. */
    public void startPermissionFlow() {
        Arrays.fill(asked, false);
        chainActive = true;
        requestNext();
    }

    private void requestNext() {
        if (isFinishing() || isDestroyed()) return;
        if (!PermissionHelper.hasNotifications(this) && !asked[0]) {
            asked[0] = true;
            waitingRuntime = true;
            runtimeLauncher.launch(new String[]{Manifest.permission.POST_NOTIFICATIONS});
            return;
        }
        if (!PermissionHelper.hasStorage(this) && !asked[1]) {
            asked[1] = true;
            if (Build.VERSION.SDK_INT >= 30) {
                launchSettings(PermissionHelper.allFilesIntent(this));
            } else {
                waitingRuntime = true;
                runtimeLauncher.launch(new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE});
            }
            return;
        }
        if (!PermissionHelper.hasOverlay(this) && !asked[2]) {
            asked[2] = true;
            launchSettings(PermissionHelper.overlayIntent(this));
            return;
        }
        chainActive = false;
    }

    private void launchSettings(Intent intent) {
        if (!FormatUtils.safeStartActivity(this, intent)) requestNext();
    }

    /** Abre uma tela por cima da aba atual; o botão voltar retorna. */
    public void openSecondary(Fragment fragment) {
        FragmentManager manager = getSupportFragmentManager();
        if (isFinishing() || isDestroyed() || manager.isStateSaved()) return;
        manager.beginTransaction()
                .setReorderingAllowed(true)
                .replace(R.id.fragment_container, fragment)
                .addToBackStack("secondary")
                .commit();
    }

    /** Vai para a aba Terminal com um comando já digitado (sem executar). */
    public void openTerminalWith(String command) {
        TerminalSession.pendingCommand = command;
        selectTab(R.id.nav_terminal);
    }

    public void selectTab(@IdRes int menuItemId) {
        if (bottomNavigation != null && !isFinishing() && !isDestroyed()) {
            bottomNavigation.setSelectedItemId(menuItemId);
        }
    }

    private boolean showTab(@IdRes int id) {
        Fragment target;
        if (id == R.id.nav_monitor) {
            target = new MonitorFragment();
        } else if (id == R.id.nav_files) {
            target = new FileManagerFragment();
        } else if (id == R.id.nav_terminal) {
            target = new TerminalFragment();
        } else {
            target = new HomeFragment();
            selectedTabId = R.id.nav_home;
        }
        FragmentManager manager = getSupportFragmentManager();
        if (isFinishing() || isDestroyed() || manager.isStateSaved()) return false;
        manager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        manager.beginTransaction()
                .setReorderingAllowed(true)
                .replace(R.id.fragment_container, target)
                .commit();
        return true;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putInt(STATE_SELECTED_TAB, selectedTabId);
        super.onSaveInstanceState(outState);
    }
}
