package com.htx.optimize.files;

import java.util.Locale;

/** Categoria do arquivo (define ícone/cor e a ação ao tocar). */
public enum FileKind {
    FOLDER, ARCHIVE, IMAGE, VIDEO, AUDIO, APK, TEXT, SCRIPT, PDF, OTHER;

    private static boolean in(String ext, String... list) {
        for (String item : list) if (item.equals(ext)) return true;
        return false;
    }

    public static String extensionOf(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        int dot = lower.lastIndexOf('.');
        return dot > 0 && dot < lower.length() - 1 ? lower.substring(dot + 1) : "";
    }

    public static FileKind of(String name, boolean directory) {
        if (directory) return FOLDER;
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".tar.gz")) return ARCHIVE;
        String ext = extensionOf(name);
        if (ext.equals("apk")) return APK;
        if (in(ext, "zip", "7z", "rar", "tar", "gz", "tgz", "jar", "cbz")) return ARCHIVE;
        if (in(ext, "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg")) return IMAGE;
        if (in(ext, "mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "m4v", "ts")) return VIDEO;
        if (in(ext, "mp3", "wav", "flac", "ogg", "m4a", "aac", "opus", "wma", "amr")) return AUDIO;
        if (in(ext, "sh", "bash")) return SCRIPT;
        if (in(ext, "txt", "log", "md", "json", "xml", "csv", "ini", "conf", "cfg", "prop", "properties",
                "html", "htm", "css", "js", "java", "kt", "py", "yml", "yaml")) return TEXT;
        if (ext.equals("pdf")) return PDF;
        return OTHER;
    }
}
