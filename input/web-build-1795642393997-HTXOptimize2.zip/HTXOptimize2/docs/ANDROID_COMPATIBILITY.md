# Android compatibility reference

## Supported baseline

The module declares Android API 24 (Android 7.0) as its minimum SDK and compiles against API
35. Runtime behavior must therefore be guarded when newer platform APIs are
used. Prefer AndroidX compatibility helpers where they preserve behavior without
raising the minimum SDK.

## Permissions

Use the least-privilege approach. For user-selected files, prefer the Storage
Access Framework rather than broad storage permissions. If a feature requires
a runtime permission, check it at the point of use and handle denial and
permanent denial. Never assume a permission remains granted indefinitely.

## Background work

Short UI-bound refreshes may use lifecycle-aware callbacks. Deferrable work that
must survive process death should use WorkManager, with constraints and a clear
user-visible explanation. Do not create an always-running service solely to
claim that memory is being boosted.

## Notifications and foreground services

If a future release adds foreground work, declare only the service types that
match the actual operation and comply with the Android version's notification
and foreground-service requirements. Do not use a foreground service to evade
background execution limits.

## Filesystem

Scoped storage means arbitrary absolute paths are not a reliable abstraction.
Persist URI permissions only when the provider grants them. Treat provider
metadata as nullable and potentially stale. A failed delete must be surfaced
as a failure, not reported as success.

## Build reproducibility

Pin plugin and dependency versions. Use the Gradle wrapper in source control.
Avoid downloading unpinned build tools during a release. Keep debug and release
signing configurations separate. Store release credentials in CI secrets.


## Recursos que dependem da versão do Android

| Recurso | Comportamento |
|---|---|
| Janelinha flutuante | Exige "Sobrepor outros apps"; usa `TYPE_APPLICATION_OVERLAY` (API 26+) e `TYPE_PHONE` abaixo disso |
| Serviço em primeiro plano | Android 14+ exige tipo `specialUse` e a permissão `FOREGROUND_SERVICE_SPECIAL_USE` (declarados) |
| Notificações | Android 13+ pede `POST_NOTIFICATIONS` em tempo de execução |
| Arquivos | Android 11+ usa "Acesso a todos os arquivos"; Android 7–10 usa permissão de armazenamento comum |
| Temperatura da CPU | Lida de `/sys/class/thermal`; se o fabricante bloquear, usa a temperatura da bateria (marcada com "b") |
| FPS real | Exige Shizuku em execução e autorizado; sem ele a janelinha mostra a taxa da tela ("TELA") |
| Arquivos (7Z/RAR) | Usam bibliotecas que podem exigir Android 8+ em alguns recursos; se falhar, o app mostra o motivo |
| Instalar APK | Android 8+ pede a permissão "instalar apps desconhecidos" para o HTX Optimize |
| Terminal (modo Shizuku) | Exige Shizuku em execução e autorizado; o modo App funciona sempre |
