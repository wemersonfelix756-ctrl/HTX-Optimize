# Testes manuais (no aparelho)

Marque cada item depois de testar. Os módulos de lógica (compactação, operações de arquivo, terminal, FPS, saúde) têm testes automáticos; o que está abaixo depende do Android real.

| Área | Passo | Resultado esperado |
|---|---|---|
| Permissões | Primeira abertura | Aviso explicativo aparece uma vez; depois só o aviso "Faltam permissões" na Início |
| Início | Abrir a aba | Nota de saúde, 4 medidores e dica; valores atualizam sozinhos |
| Início | Otimizar RAM (com e sem modo profundo) | Relatório com RAM liberada e apps encerrados; apps protegidos continuam abertos |
| Início | Modo Jogo | Otimiza e liga a janelinha (se a permissão existir) |
| Início | Limpar temporários | Lista contagem/tamanho, pede confirmação, libera espaço |
| Início | Apps protegidos | Marcação salva e respeitada na otimização |
| Monitor | Ativar/desativar janelinha (aba e notificação) | Aparece sobre outros apps; arrastar move; toque alterna compacto |
| Monitor | Shizuku parado / sem autorização / autorizado | Texto e botão mudam conforme o estado |
| Monitor | Jogo aberto com Shizuku autorizado | Rótulo "FPS", app e fonte (SF/TS/GFX) na linha pequena |
| Monitor | Estatísticas e Diagnosticar (10 s) | Média, 1% low e detalhes por etapa |
| Monitor | Opacidade, janelinha grande, mini gráfico | Mudanças aplicadas na janelinha em até 1 s |
| Arquivos | Abrir a aba sem permissão | Cartão pedindo acesso; ao conceder, lista a pasta |
| Arquivos | Navegar (toque, ↑, caminho, voltar) | Entra/sobe pastas; voltar sobe uma pasta |
| Arquivos | Copiar/Mover → outra pasta → Colar | Item aparece no destino com progresso |
| Arquivos | Excluir, renomear, nova pasta/arquivo | Lista atualiza; nomes repetidos viram "nome (1)" |
| Arquivos | Compactar (ZIP/7Z/TAR.GZ) e extrair de volta | Conteúdo idêntico |
| Arquivos | Tocar em .zip/.7z/.rar → Abrir → marcar → Extrair | Só o marcado é extraído |
| Arquivos | .apk → Instalar | Pede "apps desconhecidos" e abre o instalador |
| Arquivos | Menu ⋮ → Maiores arquivos | Lista dos maiores arquivos com pasta e tamanho |
| Arquivos | Menu ⋮ → Buscar, Ordenar, Ocultos, Favoritos | Resultados, ordem e atalhos corretos |
| Arquivos | Info e checksums | Tamanho, permissões, MD5/SHA-1/SHA-256 |
| Terminal | Modo Shizuku: `id` | uid=2000(shell) |
| Terminal | `cd /sdcard/Download` e `ls` | Prompt muda; ls lista a pasta |
| Terminal | `sleep 30` com limite 15 s / botão parar | Mostra "tempo esgotado" / "cancelado" |
| Terminal | `rm -rf /sdcard/*` | Pede confirmação antes |
| Terminal | Atalhos, Salvos, Histórico, Copiar, Salvar saída | Funcionam como descrito |
| Terminal | .sh no gerenciador → Preparar no Terminal | Terminal abre com o comando digitado |
| Topo | Botão (i) | Abre a tela Sobre com a versão correta |

## Registro

| Data | Aparelho / Android | Itens testados | Observações |
|---|---|---|---|
|  |  |  |  |
