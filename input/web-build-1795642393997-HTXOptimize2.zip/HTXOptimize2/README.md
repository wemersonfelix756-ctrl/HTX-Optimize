# HTX Optimize

Otimizador, monitor de FPS, gerenciador de arquivos e terminal para Android (minSdk 24).

## Estrutura do app (4 abas)

| Aba | O que faz |
|---|---|
| **Início** | Saúde do aparelho (nota 0–100), medidores de RAM, armazenamento, bateria e temperatura, e toda a otimização: Otimizar RAM, Modo Jogo, limpar temporários, apps protegidos e modo profundo (Shizuku). |
| **Monitor** | Janelinha flutuante de FPS/CPU/RAM, status e autorização do Shizuku (FPS real), aparência da janelinha, estatísticas de FPS (média, 1% low) e diagnóstico. |
| **Arquivos** | Gerenciador estilo ZArchiver: navegar, seleção múltipla, copiar/mover/excluir/renomear, compactar e extrair (ZIP, TAR, TAR.GZ, GZ, 7Z, RAR), explorar arquivos compactados, busca, favoritos, maiores arquivos, propriedades e checksums. |
| **Terminal** | Comandos `sh` pelo Shizuku (usuário shell) ou no modo App, com `cd`, tempo limite, cancelar, histórico, comandos salvos e atalhos. |

O botão (i) no topo abre a tela Sobre.

## Desenvolvimento

- `python3 scripts/verify_project.py` valida recursos, IDs e referências.
- Testes unitários: `gradle testDebugUnitTest` (rodam também no GitHub Actions).
- O workflow gera `app-debug.apk` e `app-release.apk` (assinado com a chave de debug, instalável).

## Histórico

- **v3.0** — Reestruturação: 4 abas sem funções duplicadas, novo visual (cartões, tipografia, ícones vetoriais), analisador de espaço integrado ao gerenciador, monitor de RAM e ferramentas redundantes removidos.
- **v2.9** — Gerenciador de arquivos e terminal.
- **v2.8** — Auditoria: correções de limpeza, permissões e CI.
- **v2.7 e anteriores** — FPS real via Shizuku, janelinha flutuante, otimização de RAM.
