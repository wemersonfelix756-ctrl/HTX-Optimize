package com.htx.optimize.fragments;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.htx.optimize.MainActivity;
import com.htx.optimize.R;
import com.htx.optimize.monitor.SystemMonitor;
import com.htx.optimize.optimizer.JunkCleaner;
import com.htx.optimize.optimizer.RamOptimizer;
import com.htx.optimize.util.FormatUtils;
import com.htx.optimize.util.PermissionHelper;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RamBoosterFragment extends Fragment {
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView tvStatus, tvReport;
    private ProgressBar progressBar;
    private Button btnRun, btnJunk;
    private boolean busy;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_ram_booster, container, false);
    }

    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvStatus = view.findViewById(R.id.tv_booster_status);
        tvReport = view.findViewById(R.id.tv_booster_report);
        progressBar = view.findViewById(R.id.progress_booster_scan);
        btnRun = view.findViewById(R.id.btn_run_booster);
        btnJunk = view.findViewById(R.id.btn_clean_junk);
        if (btnRun != null) btnRun.setOnClickListener(v -> runBoost());
        if (btnJunk != null) btnJunk.setOnClickListener(v -> scanJunk());
        View apps = view.findViewById(R.id.btn_booster_apps);
        if (apps != null) apps.setOnClickListener(v ->
                FormatUtils.safeStartActivity(requireContext(), new Intent(Settings.ACTION_APPLICATION_SETTINGS)));
        refreshCurrentState();
    }

    @Override public void onResume() {
        super.onResume();
        refreshCurrentState();
    }

    private void setBusy(boolean value) {
        busy = value;
        if (btnRun != null) btnRun.setEnabled(!value);
        if (btnJunk != null) btnJunk.setEnabled(!value);
        if (progressBar != null) {
            progressBar.setVisibility(value ? View.VISIBLE : View.GONE);
            progressBar.setIndeterminate(value);
        }
    }

    private void refreshCurrentState() {
        if (!isAdded() || getContext() == null || worker.isShutdown()) return;
        final android.content.Context appContext = requireContext().getApplicationContext();
        worker.execute(() -> {
            final SystemMonitor.RamSnapshot ram = SystemMonitor.readRam(appContext);
            mainHandler.post(() -> {
                if (!isAdded() || getView() == null || tvStatus == null) return;
                String diagnosis = ram.lowMemory || ram.usedPercent >= 82
                        ? "Memória baixa — recomendado otimizar agora."
                        : "Memória dentro da faixa normal.";
                tvStatus.setText(String.format(Locale.US,
                        "RAM disponível: %s de %s (%d%% usada)\n%s",
                        FormatUtils.formatBytes(ram.availBytes), FormatUtils.formatBytes(ram.totalBytes),
                        ram.usedPercent, diagnosis));
            });
        });
    }

    private void runBoost() {
        if (!isAdded() || getContext() == null || busy || worker.isShutdown()) return;
        setBusy(true);
        if (tvReport != null) tvReport.setText("Otimizando... encerrando apps em segundo plano.");
        final android.content.Context appContext = requireContext().getApplicationContext();
        worker.execute(() -> {
            final RamOptimizer.Result r = RamOptimizer.run(appContext);
            mainHandler.post(() -> {
                if (!isAdded() || getView() == null) return;
                setBusy(false);
                long delta = r.deltaBytes();
                String gain = delta > 0
                        ? "+" + FormatUtils.formatBytes(delta) + " liberados"
                        : "sem ganho mensurável agora (o Android pode ter reiniciado serviços)";
                if (tvReport != null) tvReport.setText(String.format(Locale.US,
                        "Otimização concluída:\n"
                        + "• Apps com pedido de encerramento: %d (ignorados/protegidos: %d)\n"
                        + "• RAM livre antes: %s\n• RAM livre depois: %s\n• Resultado: %s\n"
                        + "• Cache próprio limpo: %s\n\n"
                        + "Nota: apps com serviço em primeiro plano (música, navegação) e "
                        + "serviços do sistema são preservados.",
                        r.requested, r.skipped,
                        FormatUtils.formatBytes(r.beforeAvail), FormatUtils.formatBytes(r.afterAvail),
                        gain, FormatUtils.formatBytes(r.cacheFreed)));
                refreshCurrentState();
            });
        });
    }

    private void scanJunk() {
        if (!isAdded() || getContext() == null || busy || worker.isShutdown()) return;
        if (!PermissionHelper.hasStorage(requireContext())) {
            Toast.makeText(requireContext(), "Conceda a permissão de armazenamento primeiro.",
                    Toast.LENGTH_LONG).show();
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).startPermissionFlow();
            return;
        }
        setBusy(true);
        if (tvReport != null) tvReport.setText("Procurando arquivos temporários...");
        worker.execute(() -> {
            final JunkCleaner.Scan scan = JunkCleaner.scan();
            mainHandler.post(() -> {
                if (!isAdded() || getView() == null) return;
                setBusy(false);
                if (scan.files.isEmpty()) {
                    if (tvReport != null) tvReport.setText("Nenhum arquivo temporário encontrado.");
                    return;
                }
                String size = FormatUtils.formatBytes(scan.bytes);
                if (tvReport != null) tvReport.setText(scan.files.size()
                        + " arquivo(s) temporário(s) encontrado(s): " + size);
                new AlertDialog.Builder(requireContext())
                        .setTitle("Limpar temporários")
                        .setMessage("Excluir " + scan.files.size() + " arquivo(s) (.tmp, .log, "
                                + "miniaturas etc.) e liberar " + size + "?")
                        .setNegativeButton("Cancelar", null)
                        .setPositiveButton("Excluir", (d, w) -> deleteJunk(scan))
                        .show();
            });
        });
    }

    private void deleteJunk(JunkCleaner.Scan scan) {
        if (!isAdded() || worker.isShutdown()) return;
        setBusy(true);
        worker.execute(() -> {
            final long freed = JunkCleaner.delete(scan.files);
            mainHandler.post(() -> {
                if (!isAdded() || getView() == null) return;
                setBusy(false);
                if (tvReport != null) tvReport.setText("Limpeza concluída: "
                        + FormatUtils.formatBytes(freed) + " liberados.");
            });
        });
    }

    @Override public void onDestroyView() {
        tvStatus = null; tvReport = null; progressBar = null; btnRun = null; btnJunk = null;
        super.onDestroyView();
    }

    @Override public void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        worker.shutdownNow();
        super.onDestroy();
    }
}
