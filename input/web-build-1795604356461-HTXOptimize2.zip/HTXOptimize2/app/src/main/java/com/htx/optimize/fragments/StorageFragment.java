package com.htx.optimize.fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.documentfile.provider.DocumentFile;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.htx.optimize.MainActivity;
import com.htx.optimize.R;
import com.htx.optimize.storage.FileAdapter;
import com.htx.optimize.storage.FileItem;
import com.htx.optimize.util.FormatUtils;
import com.htx.optimize.util.PermissionHelper;
import java.io.File;
import java.util.PriorityQueue;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class StorageFragment extends Fragment {
    private static final String STATE_TREE_URI = "htx.tree_uri";
    private static final String STATE_SCANNED = "htx.scanned_bytes";
    private static final String STATE_FREED = "htx.freed_bytes";
    private static final String STATE_ALL_MODE = "htx.all_mode";
    private static final int TOP_FILES = 250;
    private static final long MIN_BIG_FILE = 1024L * 1024L;
    private static final int MAX_VISITED = 400_000;
    private static final int MAX_DEVICE_DEPTH = 14;
    private static final int MAX_SCAN_FILES = 5000;
    private static final int MAX_SCAN_DEPTH = 32;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicInteger operationId = new AtomicInteger(0);
    private TextView tvFolderInfo, tvReport;
    private Button btnDeleteSelected;
    private FileAdapter adapter;
    private Uri currentTreeUri;
    private long lastScannedBytes, lastFreedBytes;
    private boolean allMode;

    private final ActivityResultLauncher<Uri> folderPickerLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocumentTree(), uri -> {
                if (uri == null || !isAdded() || getContext() == null) return;
                try {
                    int flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
                    requireContext().getContentResolver().takePersistableUriPermission(uri, flags);
                } catch (RuntimeException ignored) {
                    // Some providers issue transient grants or reject persistence.
                }
                currentTreeUri = uri;
                allMode = false;
                scanFolder(uri);
            });

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_storage, container, false);
    }

    @Override public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            String uri = savedInstanceState.getString(STATE_TREE_URI);
            if (uri != null) currentTreeUri = Uri.parse(uri);
            lastScannedBytes = Math.max(0L, savedInstanceState.getLong(STATE_SCANNED, 0L));
            lastFreedBytes = Math.max(0L, savedInstanceState.getLong(STATE_FREED, 0L));
            allMode = savedInstanceState.getBoolean(STATE_ALL_MODE, false);
        }
    }

    @Override public void onSaveInstanceState(@NonNull Bundle outState) {
        if (currentTreeUri != null) outState.putString(STATE_TREE_URI, currentTreeUri.toString());
        outState.putLong(STATE_SCANNED, lastScannedBytes);
        outState.putLong(STATE_FREED, lastFreedBytes);
        outState.putBoolean(STATE_ALL_MODE, allMode);
        super.onSaveInstanceState(outState);
    }

    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvFolderInfo = view.findViewById(R.id.tv_storage_folder_info);
        tvReport = view.findViewById(R.id.tv_storage_report);
        btnDeleteSelected = view.findViewById(R.id.btn_delete_selected);
        RecyclerView recycler = view.findViewById(R.id.rv_files);

        adapter = new FileAdapter((count, bytes) -> {
            if (btnDeleteSelected != null) {
                btnDeleteSelected.setEnabled(count > 0);
                btnDeleteSelected.setText(String.format(java.util.Locale.US, "Excluir (%d)", count));
            }
        });
        recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        recycler.setHasFixedSize(false);
        recycler.setAdapter(adapter);

        View pick = view.findViewById(R.id.btn_pick_folder);
        if (pick != null) pick.setOnClickListener(v -> folderPickerLauncher.launch(currentTreeUri));
        View scanAll = view.findViewById(R.id.btn_scan_all);
        if (scanAll != null) scanAll.setOnClickListener(v -> scanDevice());
        if (btnDeleteSelected != null) btnDeleteSelected.setOnClickListener(v -> confirmDeleteSelected());
        updateReportText();
        if (allMode && PermissionHelper.hasStorage(requireContext())) scanDevice();
        else if (currentTreeUri != null) scanFolder(currentTreeUri);
    }

    private void scanFolder(Uri treeUri) {
        if (treeUri == null || !isAdded() || getContext() == null || worker.isShutdown()) return;
        final int requestId = operationId.incrementAndGet();
        final Context appContext = requireContext().getApplicationContext();
        if (tvFolderInfo != null) tvFolderInfo.setText("Analisando pasta selecionada...");
        worker.execute(() -> {
            DocumentFile root = DocumentFile.fromTreeUri(appContext, treeUri);
            List<FileItem> found = new ArrayList<>();
            String error = null;
            if (root == null) {
                error = "Não foi possível abrir a pasta selecionada.";
            } else if (!root.canRead()) {
                error = "Sem permissão de leitura para esta pasta.";
            } else {
                try {
                    collectFilesRecursive(root, found, 0);
                } catch (SecurityException | IllegalStateException exception) {
                    error = "A leitura foi interrompida. Verifique as permissões da pasta.";
                } catch (RuntimeException exception) {
                    error = "O provedor de arquivos retornou um erro durante a leitura.";
                }
            }

            long total = 0L;
            for (FileItem item : found) total = safeAdd(total, item.getSizeBytes());
            Collections.sort(found, (a, b) -> Long.compare(b.getSizeBytes(), a.getSizeBytes()));
            final long scanned = total;
            final String scanError = error;
            final String folderName = root != null && root.getName() != null
                    ? root.getName() : "Pasta selecionada";
            mainHandler.post(() -> {
                if (requestId != operationId.get() || !isAdded() || getView() == null || adapter == null) return;
                lastScannedBytes = scanned;
                String limit = found.size() >= MAX_SCAN_FILES ? " • limite de segurança atingido" : "";
                if (tvFolderInfo != null) tvFolderInfo.setText(
                        (scanError != null ? scanError + "\n" : "") + "Pasta: " + folderName
                                + " • " + found.size() + " arquivo(s)" + limit);
                updateReportText();
                adapter.setItems(found);
            });
        });
    }

    /** Varre todo o armazenamento e lista os maiores arquivos (precisa de "acesso a todos os arquivos"). */
    private void scanDevice() {
        if (!isAdded() || getContext() == null || worker.isShutdown()) return;
        if (!PermissionHelper.hasStorage(requireContext())) {
            Toast.makeText(requireContext(), "Conceda o acesso aos arquivos primeiro.", Toast.LENGTH_LONG).show();
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).startPermissionFlow();
            return;
        }
        allMode = true;
        final int requestId = operationId.incrementAndGet();
        if (tvFolderInfo != null) tvFolderInfo.setText("Analisando todo o armazenamento...");
        worker.execute(() -> {
            final PriorityQueue<FileItem> heap = new PriorityQueue<>(TOP_FILES + 1,
                    (a, b) -> Long.compare(a.getSizeBytes(), b.getSizeBytes()));
            final int[] visited = new int[1];
            File root = android.os.Environment.getExternalStorageDirectory();
            if (root != null) walkDevice(root, 0, heap, visited);
            final List<FileItem> found = new ArrayList<>(heap);
            Collections.sort(found, (a, b) -> Long.compare(b.getSizeBytes(), a.getSizeBytes()));
            long total = 0L;
            for (FileItem item : found) total = safeAdd(total, item.getSizeBytes());
            final long scanned = total;
            final boolean truncated = visited[0] >= MAX_VISITED;
            mainHandler.post(() -> {
                if (requestId != operationId.get() || !isAdded() || getView() == null || adapter == null) return;
                lastScannedBytes = scanned;
                if (tvFolderInfo != null) tvFolderInfo.setText("Todo o armazenamento • " + found.size()
                        + " maior(es) arquivo(s) (≥ 1 MB)" + (truncated ? " • varredura limitada" : ""));
                updateReportText();
                adapter.setItems(found);
            });
        });
    }

    private void walkDevice(File dir, int depth, PriorityQueue<FileItem> heap, int[] visited) {
        if (depth > MAX_DEVICE_DEPTH || visited[0] >= MAX_VISITED || Thread.currentThread().isInterrupted()) return;
        File[] children = dir.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (visited[0] >= MAX_VISITED) return;
            visited[0]++;
            if (child.isDirectory()) {
                if (depth == 0 && child.getName().equals("Android")) continue; // inacessível e de outros apps
                walkDevice(child, depth + 1, heap, visited);
            } else if (child.isFile()) {
                long length = child.length();
                if (length < MIN_BIG_FILE) continue;
                if (heap.size() < TOP_FILES) {
                    heap.add(new FileItem(child));
                } else if (heap.peek() != null && length > heap.peek().getSizeBytes()) {
                    heap.poll();
                    heap.add(new FileItem(child));
                }
            }
        }
    }

    private void collectFilesRecursive(DocumentFile directory, List<FileItem> output, int depth) {
        if (directory == null || depth >= MAX_SCAN_DEPTH || output.size() >= MAX_SCAN_FILES) return;
        DocumentFile[] children = directory.listFiles();
        if (children == null) return;
        for (DocumentFile child : children) {
            if (output.size() >= MAX_SCAN_FILES) return;
            if (child == null) continue;
            try {
                if (child.isDirectory()) {
                    collectFilesRecursive(child, output, depth + 1);
                } else if (child.isFile()) {
                    String name = child.getName();
                    String type = child.getType();
                    long length = Math.max(0L, child.length());
                    output.add(new FileItem(child.getUri(), name, type, length));
                }
            } catch (SecurityException | IllegalStateException ignored) {
                // A single inaccessible entry must not abort the rest of the scan.
            }
        }
    }

    private void confirmDeleteSelected() {
        if (adapter == null || getContext() == null) return;
        List<FileItem> selected = new ArrayList<>(adapter.getSelectedItems());
        if (selected.isEmpty()) return;
        long bytes = 0L;
        for (FileItem item : selected) bytes = safeAdd(bytes, item.getSizeBytes());
        new AlertDialog.Builder(requireContext())
                .setTitle("Confirmar exclusão")
                .setMessage(String.format(java.util.Locale.US,
                        "Deseja excluir permanentemente %d arquivo(s) selecionado(s) (%s)?",
                        selected.size(), FormatUtils.formatBytes(bytes)))
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (dialog, which) -> deleteFilesAsync(selected))
                .show();
    }

    private void deleteFilesAsync(List<FileItem> selected) {
        if (!isAdded() || getContext() == null || worker.isShutdown()) return;
        operationId.incrementAndGet();
        final Context appContext = requireContext().getApplicationContext();
        if (btnDeleteSelected != null) btnDeleteSelected.setEnabled(false);
        worker.execute(() -> {
            long freed = 0L;
            int deleted = 0;
            int failed = 0;
            for (FileItem item : selected) {
                try {
                    if (item.delete(appContext)) {
                        freed = safeAdd(freed, item.getSizeBytes());
                        deleted++;
                    } else {
                        failed++;
                    }
                } catch (RuntimeException exception) {
                    failed++;
                }
            }
            final long freedBytes = freed;
            final int deletedCount = deleted;
            final int failedCount = failed;
            mainHandler.post(() -> {
                if (!isAdded() || getView() == null) return;
                lastFreedBytes = safeAdd(lastFreedBytes, freedBytes);
                updateReportText();
                if (getContext() != null) Toast.makeText(getContext(),
                        deletedCount + " arquivo(s) excluído(s); " + failedCount + " falha(s) ("
                                + FormatUtils.formatBytes(freedBytes) + ")", Toast.LENGTH_LONG).show();
                if (allMode) scanDevice();
                else if (currentTreeUri != null) scanFolder(currentTreeUri);
            });
        });
    }

    private static long safeAdd(long a, long b) {
        if (b > 0L && a > Long.MAX_VALUE - b) return Long.MAX_VALUE;
        return Math.max(0L, a + Math.max(0L, b));
    }

    private void updateReportText() {
        if (tvReport != null) tvReport.setText(String.format(java.util.Locale.US,
                "Espaço analisado: %s • Espaço liberado: %s",
                FormatUtils.formatBytes(lastScannedBytes), FormatUtils.formatBytes(lastFreedBytes)));
    }

    @Override public void onDestroyView() {
        operationId.incrementAndGet();
        tvFolderInfo = null; tvReport = null; btnDeleteSelected = null; adapter = null;
        super.onDestroyView();
    }

    @Override public void onDestroy() {
        operationId.incrementAndGet();
        worker.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
