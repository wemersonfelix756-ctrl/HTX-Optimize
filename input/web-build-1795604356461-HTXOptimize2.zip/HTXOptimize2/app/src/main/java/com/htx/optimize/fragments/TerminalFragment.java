package com.htx.optimize.fragments;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.htx.optimize.MainActivity;
import com.htx.optimize.R;
import com.htx.optimize.shizuku.ShizukuBridge;
import com.htx.optimize.terminal.TerminalSession;
import com.htx.optimize.terminal.TerminalStore;
import com.htx.optimize.ui.UiAnim;
import com.htx.optimize.util.DangerousCommands;
import com.htx.optimize.util.PermissionHelper;
import com.htx.optimize.util.ShellRunner;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Aba de terminal: executa comandos sh via Shizuku (shell) ou no próprio app. */
public class TerminalFragment extends Fragment {

    private static final Pattern CD = Pattern.compile("^cd(?:\\s+(.*))?$");

    private static final String[][] SHORTCUTS = {
            {"Quem sou eu (id)", "id"},
            {"Modelo e Android", "getprop ro.product.model; getprop ro.build.version.release"},
            {"Apps de terceiros", "pm list packages -3"},
            {"Apps em execução (top)", "top -b -n 1 | head -25"},
            {"Processos", "ps -A | head -40"},
            {"Memória (meminfo)", "head -8 /proc/meminfo"},
            {"Bateria", "dumpsys battery"},
            {"Temperaturas (thermal)", "cat /sys/class/thermal/thermal_zone*/temp | head -20"},
            {"Resolução e densidade", "wm size; wm density"},
            {"Parar um app (force-stop)", "am force-stop com.exemplo.app"},
            {"Congelar um app", "pm disable-user --user 0 com.exemplo.app"},
            {"Descongelar um app", "pm enable com.exemplo.app"},
            {"Limpar cache de todos os apps", "pm trim-caches 999G"},
            {"Dados de um app", "dumpsys package com.exemplo.app | head -40"},
            {"Armazenamento (df)", "df -h"},
            {"Rede (ip)", "ip addr show wlan0"},
            {"Logs recentes", "logcat -d -t 60"},
    };

    private final Handler main = new Handler(Looper.getMainLooper());
    private TextView tvOutput, tvStatus, tvPrompt;
    private ScrollView scroll;
    private EditText etInput;
    private Button btnRun, btnCancel, btnMode, btnTimeout;
    private int historyIndex = -1;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        return inflater.inflate(R.layout.fragment_terminal, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        super.onViewCreated(view, state);
        tvOutput = view.findViewById(R.id.tv_term_output);
        tvStatus = view.findViewById(R.id.tv_term_status);
        tvPrompt = view.findViewById(R.id.tv_term_prompt);
        scroll = view.findViewById(R.id.scroll_term);
        etInput = view.findViewById(R.id.et_term_input);
        btnRun = view.findViewById(R.id.btn_term_run);
        btnCancel = view.findViewById(R.id.btn_term_cancel);
        btnMode = view.findViewById(R.id.btn_term_mode);
        btnTimeout = view.findViewById(R.id.btn_term_timeout);

        if (TerminalSession.cwd == null) {
            File sd = Environment.getExternalStorageDirectory();
            TerminalSession.cwd = sd != null && sd.isDirectory() ? sd.getAbsolutePath() : "/";
        }
        if (TerminalSession.BUFFER.length() == 0) showWelcome();

        btnRun.setOnClickListener(v -> execute(etInput.getText().toString()));
        btnCancel.setOnClickListener(v -> cancelRunning());
        btnMode.setOnClickListener(v -> {
            TerminalSession.useShizuku = !TerminalSession.useShizuku;
            if (TerminalSession.useShizuku) ShizukuBridge.ensureBound(requireContext());
            refreshUi();
        });
        btnTimeout.setOnClickListener(v -> {
            TerminalSession.timeoutIndex = (TerminalSession.timeoutIndex + 1) % TerminalSession.TIMEOUTS_MS.length;
            refreshUi();
        });
        etInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                execute(etInput.getText().toString());
                return true;
            }
            return false;
        });
        view.findViewById(R.id.btn_term_shortcuts).setOnClickListener(v -> showShortcuts());
        view.findViewById(R.id.btn_term_saved).setOnClickListener(v -> showSaved());
        view.findViewById(R.id.btn_term_save).setOnClickListener(v -> saveCurrent());
        view.findViewById(R.id.btn_term_history).setOnClickListener(v -> showHistory());
        view.findViewById(R.id.btn_term_prev).setOnClickListener(v -> cycleHistory(true));
        view.findViewById(R.id.btn_term_next).setOnClickListener(v -> cycleHistory(false));
        view.findViewById(R.id.btn_term_copy).setOnClickListener(v -> copyOutput());
        view.findViewById(R.id.btn_term_export).setOnClickListener(v -> exportOutput());
        view.findViewById(R.id.btn_term_clear).setOnClickListener(v -> TerminalSession.clear());
        UiAnim.revealChildren(view);
        if (TerminalSession.useShizuku) ShizukuBridge.ensureBound(requireContext());
    }

    @Override
    public void onResume() {
        super.onResume();
        TerminalSession.listener = this::refreshUi;
        if (TerminalSession.pendingCommand != null) {
            etInput.setText(TerminalSession.pendingCommand);
            etInput.setSelection(etInput.getText().length());
            TerminalSession.pendingCommand = null;
        }
        refreshUi();
    }

    @Override
    public void onPause() {
        if (TerminalSession.listener != null) TerminalSession.listener = null;
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        TerminalSession.listener = null;
        tvOutput = null; tvStatus = null; tvPrompt = null; scroll = null; etInput = null;
        btnRun = null; btnCancel = null; btnMode = null; btnTimeout = null;
        super.onDestroyView();
    }

    // ------------------------------------------------------------------ UI

    private void refreshUi() {
        if (tvOutput == null || !isAdded()) return;
        tvOutput.setText(TerminalSession.BUFFER);
        scroll.post(() -> { if (scroll != null) scroll.fullScroll(View.FOCUS_DOWN); });
        boolean running = TerminalSession.running;
        btnRun.setVisibility(running ? View.GONE : View.VISIBLE);
        btnCancel.setVisibility(running ? View.VISIBLE : View.GONE);
        btnMode.setText(TerminalSession.useShizuku ? "Modo: Shizuku (shell)" : "Modo: App (sem privilégios)");
        btnTimeout.setText("⏱ " + TerminalSession.TIMEOUT_LABELS[TerminalSession.timeoutIndex]);
        tvPrompt.setText((TerminalSession.useShizuku ? "shell" : "app") + ":" + shortPath(TerminalSession.cwd) + " $");
        tvStatus.setText(statusLine(running));
    }

    private String statusLine(boolean running) {
        if (running) return "⏳ Executando…  (toque em ■ para cancelar)";
        if (!TerminalSession.useShizuku) return "Rodando como o app HTX (sem acesso a dumpsys/pm de outros apps).";
        switch (ShizukuBridge.state(requireContext())) {
            case READY: return ShizukuBridge.isConnected() ? "✔ Shizuku conectado — comandos como usuário shell (uid 2000)."
                    : "Shizuku autorizado — conectando ao rodar o 1º comando.";
            case NO_PERMISSION: return "✖ Shizuku sem autorização. Autorize em Ferramentas > FPS REAL • SHIZUKU.";
            case NOT_RUNNING: return "✖ Shizuku parado. Abra o app Shizuku e inicie o serviço.";
            default: return "✖ Shizuku não instalado. Instale-o ou troque para o modo App.";
        }
    }

    private static String shortPath(String path) {
        if (path == null) return "/";
        String sd = Environment.getExternalStorageDirectory().getAbsolutePath();
        if (path.equals(sd)) return "/sdcard";
        if (path.startsWith(sd + "/")) return "/sdcard" + path.substring(sd.length());
        return path;
    }

    private void showWelcome() {
        TerminalSession.append("HTX Terminal — executa comandos sh.\n", TerminalSession.CMD);
        TerminalSession.append("Digite \"help\" para ver dicas. A saída aparece quando o comando termina.\n\n", TerminalSession.DIM);
    }

    // ------------------------------------------------------------------ execução

    private void execute(String raw) {
        final String command = raw == null ? "" : raw.trim();
        if (command.isEmpty() || TerminalSession.running) return;
        TerminalStore.addHistory(requireContext(), command);
        historyIndex = -1;
        etInput.setText("");
        TerminalSession.append(tvPrompt.getText() + " " + command + "\n", TerminalSession.CMD);

        if (command.equals("clear")) { TerminalSession.clear(); return; }
        if (command.equals("help")) { showHelp(); return; }
        if (command.equals("history")) {
            List<String> history = TerminalStore.history(requireContext());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < history.size(); i++) sb.append(String.format(Locale.US, "%3d  %s\n", i + 1, history.get(i)));
            TerminalSession.append(sb, TerminalSession.OUT);
            return;
        }
        if (DangerousCommands.isDangerous(command)) {
            new AlertDialog.Builder(requireContext())
                    .setTitle("Comando perigoso")
                    .setMessage("Este comando pode apagar dados ou danificar o sistema:\n\n" + command + "\n\nExecutar mesmo assim?")
                    .setNegativeButton("Cancelar", (d, w) -> TerminalSession.append("[cancelado pelo usuário]\n", TerminalSession.WARN))
                    .setPositiveButton("Executar", (d, w) -> run(command))
                    .show();
            return;
        }
        run(command);
    }

    private void run(final String command) {
        final Matcher cd = CD.matcher(command);
        final boolean isCd = cd.matches();
        final String toRun;
        if (isCd) {
            String arg = cd.group(1) == null ? "" : cd.group(1).trim();
            toRun = "cd " + (arg.isEmpty() ? "/sdcard" : arg) + " 2>&1 && pwd";
        } else {
            toRun = command;
        }
        final boolean shizuku = TerminalSession.useShizuku;
        final String cwd = TerminalSession.cwd;
        final long timeout = TerminalSession.TIMEOUTS_MS[TerminalSession.timeoutIndex];
        final Context app = requireContext().getApplicationContext();

        TerminalSession.running = true;
        TerminalSession.notifyListener();
        TerminalSession.EXECUTOR.execute(() -> {
            long started = System.currentTimeMillis();
            ShellRunner.Result result;
            try {
                if (shizuku) {
                    if (!ShizukuBridge.awaitConnected(app, 4000L)) {
                        result = new ShellRunner.Result("Shizuku não conectado. Abra o Shizuku, inicie o serviço e autorize o HTX (Ferramentas), ou troque para o modo App.\n", 1, false, false);
                    } else {
                        result = ShizukuBridge.execTerminal(toRun, cwd, timeout);
                    }
                } else {
                    ShellRunner runner = new ShellRunner();
                    TerminalSession.appRunner = runner;
                    result = runner.run(toRun, cwd, timeout);
                    TerminalSession.appRunner = null;
                }
            } catch (Exception e) {
                result = new ShellRunner.Result("Erro: " + e.getMessage() + "\n", 1, false, false);
            }
            final ShellRunner.Result res = result;
            final double seconds = (System.currentTimeMillis() - started) / 1000.0;
            main.post(() -> finish(res, seconds, isCd));
        });
    }

    private void finish(ShellRunner.Result res, double seconds, boolean isCd) {
        String output = res.output == null ? "" : res.output;
        if (isCd && res.exitCode == 0 && !res.timedOut && !res.cancelled) {
            String[] lines = output.trim().split("\n");
            String last = lines.length == 0 ? "" : lines[lines.length - 1].trim();
            if (last.startsWith("/")) TerminalSession.cwd = last;
        } else if (!output.isEmpty()) {
            TerminalSession.append(output.endsWith("\n") ? output : output + "\n",
                    res.exitCode == 0 ? TerminalSession.OUT : TerminalSession.ERR);
        }
        if (res.timedOut) {
            TerminalSession.append("[tempo esgotado — comando encerrado]\n", TerminalSession.WARN);
        } else if (res.cancelled) {
            TerminalSession.append("[cancelado]\n", TerminalSession.WARN);
        } else if (!isCd || res.exitCode != 0) {
            TerminalSession.append(String.format(Locale.US, "[exit %d • %.2fs]\n", res.exitCode, seconds),
                    res.exitCode == 0 ? TerminalSession.DIM : TerminalSession.ERR);
        }
        TerminalSession.running = false;
        TerminalSession.notifyListener();
    }

    private void cancelRunning() {
        if (TerminalSession.useShizuku) ShizukuBridge.cancelTerminal();
        ShellRunner runner = TerminalSession.appRunner;
        if (runner != null) runner.cancel();
    }

    private void showHelp() {
        TerminalSession.append(
                "Comandos internos: help, clear, history, cd <pasta>\n"
                        + "• Modo Shizuku: roda como usuário shell (uid 2000): pm, am, dumpsys, settings, cmd…\n"
                        + "• Modo App: roda sem privilégios, só com o que o HTX pode acessar.\n"
                        + "• Cada comando é independente; o cd muda a pasta atual do terminal.\n"
                        + "• ⏱ define o tempo limite; ■ cancela. Use Atalhos para exemplos prontos.\n"
                        + "• Comandos perigosos (rm -rf /, mkfs…) pedem confirmação.\n"
                        + "• A saída aparece quando o comando termina (não é em tempo real).\n\n",
                TerminalSession.DIM);
    }

    // ------------------------------------------------------------------ listas e ações

    private void insert(String command) {
        etInput.setText(command);
        etInput.setSelection(command.length());
        etInput.requestFocus();
    }

    private void showShortcuts() {
        final String[] labels = new String[SHORTCUTS.length];
        for (int i = 0; i < labels.length; i++) labels[i] = SHORTCUTS[i][0];
        new AlertDialog.Builder(requireContext())
                .setTitle("Atalhos (toque para inserir)")
                .setItems(labels, (d, which) -> insert(SHORTCUTS[which][1]))
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void showSaved() {
        final List<String> saved = TerminalStore.saved(requireContext());
        if (saved.isEmpty()) {
            Toast.makeText(requireContext(), "Nenhum comando salvo. Digite um e toque em ★ Salvar.", Toast.LENGTH_LONG).show();
            return;
        }
        final String[] items = saved.toArray(new String[0]);
        new AlertDialog.Builder(requireContext())
                .setTitle("Comandos salvos")
                .setItems(items, (d, which) -> insert(items[which]))
                .setNeutralButton("Apagar um…", (d, w) -> new AlertDialog.Builder(requireContext())
                        .setTitle("Apagar qual?")
                        .setItems(items, (d2, which) -> TerminalStore.removeSaved(requireContext(), items[which]))
                        .show())
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void saveCurrent() {
        String command = etInput.getText().toString().trim();
        if (command.isEmpty()) {
            Toast.makeText(requireContext(), "Digite um comando para salvar.", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean added = TerminalStore.addSaved(requireContext(), command);
        Toast.makeText(requireContext(), added ? "Comando salvo." : "Esse comando já está salvo.", Toast.LENGTH_SHORT).show();
    }

    private void showHistory() {
        final List<String> history = TerminalStore.history(requireContext());
        if (history.isEmpty()) {
            Toast.makeText(requireContext(), "Histórico vazio.", Toast.LENGTH_SHORT).show();
            return;
        }
        final String[] items = new String[history.size()];
        for (int i = 0; i < items.length; i++) items[i] = history.get(items.length - 1 - i);
        new AlertDialog.Builder(requireContext())
                .setTitle("Histórico (mais recentes primeiro)")
                .setItems(items, (d, which) -> insert(items[which]))
                .setNegativeButton("Fechar", null)
                .show();
    }

    private void cycleHistory(boolean older) {
        List<String> history = TerminalStore.history(requireContext());
        if (history.isEmpty()) return;
        if (older) {
            historyIndex = historyIndex < 0 ? history.size() - 1 : Math.max(0, historyIndex - 1);
            insert(history.get(historyIndex));
        } else if (historyIndex >= 0 && historyIndex < history.size() - 1) {
            historyIndex++;
            insert(history.get(historyIndex));
        } else {
            historyIndex = -1;
            etInput.setText("");
        }
    }

    private void copyOutput() {
        ClipboardManager clipboard = (ClipboardManager) requireContext().getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard == null) return;
        clipboard.setPrimaryClip(ClipData.newPlainText("HTX Terminal", TerminalSession.BUFFER.toString()));
        Toast.makeText(requireContext(), "Saída copiada.", Toast.LENGTH_SHORT).show();
    }

    private void exportOutput() {
        Context ctx = requireContext();
        File dir = PermissionHelper.hasStorage(ctx)
                ? Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                : ctx.getExternalFilesDir(null);
        if (dir == null) dir = ctx.getFilesDir();
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File out = new File(dir, "htx_terminal_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".txt");
        try (FileOutputStream stream = new FileOutputStream(out)) {
            stream.write(TerminalSession.BUFFER.toString().getBytes(StandardCharsets.UTF_8));
            Toast.makeText(ctx, "Saída salva em: " + out.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(ctx, "Não foi possível salvar: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
