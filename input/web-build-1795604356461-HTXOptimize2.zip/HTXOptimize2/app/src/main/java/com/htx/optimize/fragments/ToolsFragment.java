package com.htx.optimize.fragments;

import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Toast;
import androidx.appcompat.widget.SwitchCompat;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.htx.optimize.R;
import com.htx.optimize.ui.UiAnim;
import com.htx.optimize.monitor.FpsSampler;
import com.htx.optimize.monitor.FpsStats;
import com.htx.optimize.monitor.SystemMonitor;
import com.htx.optimize.monitor.ThermalReader;
import com.htx.optimize.shizuku.ShizukuBridge;
import com.htx.optimize.util.AppPrefs;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rikka.shizuku.Shizuku;
import com.htx.optimize.util.FormatUtils;
import java.util.Arrays;
import java.util.Locale;

public class ToolsFragment extends Fragment {

    private TextView tvOutput, tvShizukuStatus, tvOpacityLabel;
    private Button btnShizukuAction;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private final Shizuku.OnBinderReceivedListener binderListener =
            () -> mainHandler.post(this::updateShizukuUi);
    private final Shizuku.OnBinderDeadListener deadListener =
            () -> mainHandler.post(this::updateShizukuUi);
    private final Shizuku.OnRequestPermissionResultListener permissionListener =
            (requestCode, grantResult) -> mainHandler.post(this::updateShizukuUi);

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_tools, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvOutput = view.findViewById(R.id.tv_tool_output);
        tvShizukuStatus = view.findViewById(R.id.tv_shizuku_status);
        tvOpacityLabel = view.findViewById(R.id.tv_opacity_label);
        btnShizukuAction = view.findViewById(R.id.btn_shizuku_action);
        setupShizukuCard(view);
        setupAppearanceCard(view);
        setupAdvancedTools(view);

        view.findViewById(R.id.btn_about).setOnClickListener(v ->
                getParentFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, new AboutFragment())
                        .addToBackStack(null)
                        .commit());

        view.findViewById(R.id.btn_info_device).setOnClickListener(v -> tvOutput.setText(
                "Modelo: " + SystemMonitor.getDeviceModel() +
                        "\nMarca: " + Build.MANUFACTURER +
                        "\nHardware: " + Build.HARDWARE +
                        "\nABIs suportadas: " + Arrays.toString(Build.SUPPORTED_ABIS)));

        view.findViewById(R.id.btn_info_battery).setOnClickListener(v -> {
            SystemMonitor.BatterySnapshot b = SystemMonitor.readBattery(requireContext());
            String temp = b.temperatureCelsius != null
                    ? String.format(Locale.US, "%.1f °C", b.temperatureCelsius)
                    : "Indisponível";
            tvOutput.setText(String.format(Locale.US,
                    "Nível: %s\nTemperatura: %s\nEstado: %s\nSaúde: %s\nTensão: %s\nTecnologia: %s",
                    b.levelPercent >= 0 ? b.levelPercent + "%" : "N/D",
                    temp,
                    b.statusText,
                    b.healthText,
                    b.voltageMv > 0 ? b.voltageMv + " mV" : "N/D",
                    b.technology));
        });

        view.findViewById(R.id.btn_info_storage).setOnClickListener(v -> {
            SystemMonitor.StorageSnapshot s = SystemMonitor.readInternalStorage();
            tvOutput.setText(String.format(Locale.US,
                    "Armazenamento Interno\nTotal: %s\nUtilizado: %s (%d%%)\nLivre: %s",
                    FormatUtils.formatBytes(s.totalBytes),
                    FormatUtils.formatBytes(s.usedBytes),
                    s.usedPercent,
                    FormatUtils.formatBytes(s.freeBytes)));
        });

        view.findViewById(R.id.btn_info_memory).setOnClickListener(v -> {
            SystemMonitor.RamSnapshot r = SystemMonitor.readRam(requireContext());
            tvOutput.setText(String.format(Locale.US,
                    "Memória RAM\nTotal: %s\nUtilizada: %s (%d%%)\nDisponível: %s\nLowMemory: %s",
                    FormatUtils.formatBytes(r.totalBytes),
                    FormatUtils.formatBytes(r.usedBytes),
                    r.usedPercent,
                    FormatUtils.formatBytes(r.availBytes),
                    r.lowMemory));
        });

        view.findViewById(R.id.btn_info_android).setOnClickListener(v -> tvOutput.setText(
                SystemMonitor.getAndroidVersionSummary() +
                        "\nBuild ID: " + Build.DISPLAY +
                        "\nPatch de Segurança: " + (Build.VERSION.SECURITY_PATCH != null ? Build.VERSION.SECURITY_PATCH : "N/D")));

        view.findViewById(R.id.btn_settings_apps).setOnClickListener(v ->
                FormatUtils.safeStartActivity(requireContext(), new Intent(Settings.ACTION_APPLICATION_SETTINGS)));

        view.findViewById(R.id.btn_settings_battery).setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
            if (!FormatUtils.safeStartActivity(requireContext(), intent)) {
                FormatUtils.safeStartActivity(requireContext(), new Intent(Intent.ACTION_POWER_USAGE_SUMMARY));
            }
        });

        view.findViewById(R.id.btn_settings_storage).setOnClickListener(v ->
                FormatUtils.safeStartActivity(requireContext(), new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)));
    }

    // ---------------- Shizuku ----------------

    private void setupShizukuCard(View view) {
        try {
            Shizuku.addBinderReceivedListener(binderListener);
            Shizuku.addBinderDeadListener(deadListener);
            Shizuku.addRequestPermissionResultListener(permissionListener);
        } catch (RuntimeException ignored) {
            // Shizuku indisponível: a UI continua funcionando em modo básico
        }

        SwitchCompat real = view.findViewById(R.id.switch_real_fps);
        if (real != null) {
            real.setChecked(AppPrefs.realFps(requireContext()));
            real.setOnCheckedChangeListener((b, checked) -> AppPrefs.setRealFps(requireContext(), checked));
        }
        SwitchCompat deep = view.findViewById(R.id.switch_deep_boost);
        if (deep != null) {
            deep.setChecked(AppPrefs.deepBoost(requireContext()));
            deep.setOnCheckedChangeListener((b, checked) -> {
                AppPrefs.setDeepBoost(requireContext(), checked);
                if (checked) Toast.makeText(requireContext(),
                        "O force-stop encerra apps por completo (podem demorar a reabrir e notificações pausam).",
                        Toast.LENGTH_LONG).show();
            });
        }

        if (btnShizukuAction != null) btnShizukuAction.setOnClickListener(v -> {
            ShizukuBridge.State state = ShizukuBridge.state(requireContext());
            if (state == ShizukuBridge.State.NOT_INSTALLED) {
                FormatUtils.safeStartActivity(requireContext(), new Intent(Intent.ACTION_VIEW,
                        android.net.Uri.parse("https://shizuku.rikka.app/download/")));
            } else if (state == ShizukuBridge.State.NOT_RUNNING) {
                Intent launch = ShizukuBridge.launchIntent(requireContext());
                if (launch != null) FormatUtils.safeStartActivity(requireContext(), launch);
            } else if (state == ShizukuBridge.State.NO_PERMISSION) {
                ShizukuBridge.requestPermission();
            } else {
                Toast.makeText(requireContext(), "Shizuku já está autorizado.", Toast.LENGTH_SHORT).show();
            }
            mainHandler.postDelayed(this::updateShizukuUi, 800L);
        });
        updateShizukuUi();
    }

    private void updateShizukuUi() {
        if (!isAdded() || getContext() == null || tvShizukuStatus == null || btnShizukuAction == null) return;
        ShizukuBridge.State state = ShizukuBridge.state(requireContext());
        switch (state) {
            case NOT_INSTALLED:
                tvShizukuStatus.setText("✖ Shizuku não instalado. Instale-o para medir o FPS real de jogos e usar a otimização profunda.");
                btnShizukuAction.setText("Baixar o Shizuku");
                break;
            case NOT_RUNNING:
                tvShizukuStatus.setText("○ Shizuku instalado, mas parado. Abra o Shizuku e inicie o serviço (Depuração sem fio ou ADB).");
                btnShizukuAction.setText("Abrir o Shizuku");
                break;
            case NO_PERMISSION:
                tvShizukuStatus.setText("● Shizuku rodando. Falta autorizar o HTX Optimize.");
                btnShizukuAction.setText("Autorizar o HTX Optimize");
                break;
            default:
                tvShizukuStatus.setText("✔ Shizuku autorizado. A janelinha mostra o FPS real do app em foco.");
                btnShizukuAction.setText("Shizuku conectado");
                break;
        }
    }

    // ---------------- Aparência da janelinha ----------------

    private void setupAppearanceCard(View view) {
        SeekBar seek = view.findViewById(R.id.seek_overlay_opacity);
        if (seek != null) {
            int opacity = AppPrefs.overlayOpacity(requireContext());
            seek.setProgress(opacity - 30);
            updateOpacityLabel(opacity);
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                    if (!isAdded()) return;
                    AppPrefs.setOverlayOpacity(requireContext(), progress + 30);
                    updateOpacityLabel(progress + 30);
                }
                @Override public void onStartTrackingTouch(SeekBar bar) { }
                @Override public void onStopTrackingTouch(SeekBar bar) { }
            });
        }
        SwitchCompat graph = view.findViewById(R.id.switch_overlay_graph);
        if (graph != null) {
            graph.setChecked(AppPrefs.overlayGraph(requireContext()));
            graph.setOnCheckedChangeListener((b, checked) -> AppPrefs.setOverlayGraph(requireContext(), checked));
        }
        SwitchCompat big = view.findViewById(R.id.switch_overlay_big);
        if (big != null) {
            big.setChecked(AppPrefs.overlayBig(requireContext()));
            big.setOnCheckedChangeListener((b, checked) -> AppPrefs.setOverlayBig(requireContext(), checked));
        }
    }

    private void updateOpacityLabel(int opacity) {
        if (tvOpacityLabel != null) tvOpacityLabel.setText("Opacidade: " + opacity + "%");
    }

    // ---------------- Diagnósticos avançados ----------------

    private void setupAdvancedTools(View view) {
        View cpu = view.findViewById(R.id.btn_info_cpu);
        if (cpu != null) cpu.setOnClickListener(v -> showCpuInfo());
        UiAnim.revealChildren(view);
        View stats = view.findViewById(R.id.btn_fps_stats);
        if (stats != null) {
            stats.setOnClickListener(v -> showFpsStats());
            stats.setOnLongClickListener(v -> {
                FpsStats.GLOBAL.reset();
                if (tvOutput != null) tvOutput.setText("Sessão de FPS zerada.");
                return true;
            });
        }
        View diag = view.findViewById(R.id.btn_fps_diag);
        if (diag != null) diag.setOnClickListener(v -> runFpsDiagnostic());
        View bench = view.findViewById(R.id.btn_benchmark_storage);
        if (bench != null) bench.setOnClickListener(v -> runStorageBenchmark());
    }

    private void showFpsStats() {
        if (tvOutput == null) return;
        FpsStats.Summary summary = FpsStats.GLOBAL.summary();
        tvOutput.setText(summary == null
                ? "Ainda não há medições. Ligue o monitor flutuante com o Shizuku autorizado, abra um jogo, jogue alguns segundos e volte aqui."
                : summary.toText());
    }

    /** Espera 10 s (para você abrir o jogo) e mostra, passo a passo, o que o Shizuku consegue ler. */
    private void runFpsDiagnostic() {
        if (!isAdded() || getContext() == null || worker.isShutdown() || tvOutput == null) return;
        final android.content.Context app = requireContext().getApplicationContext();
        tvOutput.setText("Diagnóstico iniciado.\nAbra agora o jogo/app que quer medir e deixe-o na tela.\n"
                + "Em 10 segundos o resultado aparece aqui — depois volte ao HTX Optimize.");
        worker.execute(() -> {
            try {
                Thread.sleep(10_000L);
            } catch (InterruptedException exception) {
                Thread.currentThread().interrupt();
                return;
            }
            StringBuilder sb = new StringBuilder("Diagnóstico do FPS real\n");
            ShizukuBridge.State state = ShizukuBridge.state(app);
            sb.append("Shizuku: ").append(state).append('\n');
            if (state == ShizukuBridge.State.READY) {
                boolean connected = ShizukuBridge.awaitConnected(app, 5000L);
                sb.append("Serviço do app: ").append(connected ? "conectado" : "NÃO conectou").append('\n');
                if (connected) {
                    try {
                        sb.append("Usuário: ").append(ShizukuBridge.exec("id").trim()).append('\n');
                        FpsSampler sampler = new FpsSampler(ShizukuBridge::exec);
                        sampler.sample(System.currentTimeMillis());
                        Thread.sleep(1200L);
                        FpsSampler.Sample result = sampler.sample(System.currentTimeMillis());
                        sb.append("\n").append(sampler.debugReport());
                        sb.append("\nResultado: ")
                                .append(Float.isNaN(result.fps)
                                        ? "FPS indisponível (" + result.status + ")"
                                        : String.format(Locale.US, "%.1f FPS via %s", result.fps, result.source));
                    } catch (Exception exception) {
                        sb.append("Erro: ").append(exception.getMessage());
                    }
                }
            } else {
                sb.append("Autorize o HTX Optimize no card do Shizuku antes de testar.");
            }
            final String text = sb.toString();
            mainHandler.post(() -> {
                if (isAdded() && tvOutput != null) tvOutput.setText(text);
            });
        });
    }

    private void showCpuInfo() {
        if (tvOutput == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Processador\nHardware: ").append(Build.HARDWARE);
        if (Build.VERSION.SDK_INT >= 31) {
            sb.append("\nSoC: ").append(Build.SOC_MANUFACTURER).append(' ').append(Build.SOC_MODEL);
        }
        int cores = Runtime.getRuntime().availableProcessors();
        sb.append("\nNúcleos: ").append(cores);
        ThermalReader.Reading temp = ThermalReader.read(requireContext());
        sb.append("\nTemperatura: ").append(ThermalReader.format(temp))
                .append(temp.fromCpu ? " (sensor da CPU)" : " (bateria — sensor da CPU bloqueado)");
        for (int i = 0; i < cores; i++) {
            long cur = readLong("/sys/devices/system/cpu/cpu" + i + "/cpufreq/scaling_cur_freq");
            long max = readLong("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
            sb.append("\nCPU").append(i).append(": ")
                    .append(cur > 0 ? (cur / 1000) + " MHz" : "N/D")
                    .append(max > 0 ? " (máx " + (max / 1000) + " MHz)" : "");
        }
        sb.append("\nABIs: ").append(Arrays.toString(Build.SUPPORTED_ABIS));
        tvOutput.setText(sb.toString());
    }

    private static long readLong(String path) {
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String line = reader.readLine();
            return line == null ? -1L : Long.parseLong(line.trim());
        } catch (Exception exception) {
            return -1L;
        }
    }

    private void runStorageBenchmark() {
        if (!isAdded() || getContext() == null || worker.isShutdown() || tvOutput == null) return;
        tvOutput.setText("Testando velocidade do armazenamento (48 MB)...");
        final File dir = requireContext().getCacheDir();
        worker.execute(() -> {
            String result;
            File file = new File(dir, "htx_bench.tmp");
            try {
                byte[] block = new byte[1024 * 1024];
                new java.util.Random(7).nextBytes(block);
                int blocks = 48;

                long t0 = System.nanoTime();
                try (FileOutputStream out = new FileOutputStream(file)) {
                    for (int i = 0; i < blocks; i++) out.write(block);
                    out.flush();
                    out.getFD().sync();
                }
                double writeSec = Math.max(0.001, (System.nanoTime() - t0) / 1e9);

                long t1 = System.nanoTime();
                try (FileInputStream in = new FileInputStream(file)) {
                    while (in.read(block) > 0) { /* leitura sequencial */ }
                }
                double readSec = Math.max(0.001, (System.nanoTime() - t1) / 1e9);

                result = String.format(Locale.US,
                        "Teste de velocidade (aprox.)\nEscrita: %.0f MB/s\nLeitura: %.0f MB/s\n"
                                + "A leitura pode estar acima do real por causa do cache do sistema.",
                        blocks / writeSec, blocks / readSec);
            } catch (Exception exception) {
                result = "Não foi possível concluir o teste: " + exception.getMessage();
            } finally {
                //noinspection ResultOfMethodCallIgnored
                file.delete();
            }
            final String text = result;
            mainHandler.post(() -> {
                if (isAdded() && tvOutput != null) tvOutput.setText(text);
            });
        });
    }

    @Override
    public void onDestroyView() {
        try {
            Shizuku.removeBinderReceivedListener(binderListener);
            Shizuku.removeBinderDeadListener(deadListener);
            Shizuku.removeRequestPermissionResultListener(permissionListener);
        } catch (RuntimeException ignored) { }
        mainHandler.removeCallbacksAndMessages(null);
        tvOutput = null; tvShizukuStatus = null; tvOpacityLabel = null; btnShizukuAction = null;
        super.onDestroyView();
    }

    @Override
    public void onResume() {
        super.onResume();
        updateShizukuUi();
    }

    @Override
    public void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }
}
