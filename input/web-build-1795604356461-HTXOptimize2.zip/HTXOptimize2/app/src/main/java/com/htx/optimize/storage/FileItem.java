package com.htx.optimize.storage;

import android.content.Context;
import android.net.Uri;
import android.webkit.MimeTypeMap;
import androidx.documentfile.provider.DocumentFile;
import java.io.File;
import java.util.Locale;

public class FileItem {

    private final Uri uri;
    private final String name;
    private final String mimeType;
    private final long sizeBytes;
    private final File file;
    private boolean selected;

    public FileItem(Uri uri, String name, String mimeType, long sizeBytes) {
        this.uri = uri;
        this.name = name != null ? name : "arquivo";
        this.mimeType = mimeType != null ? mimeType : "desconhecido";
        this.sizeBytes = Math.max(0L, sizeBytes);
        this.file = null;
        this.selected = false;
    }

    /** Arquivo real do armazenamento (usa a permissão de acesso a todos os arquivos). */
    public FileItem(File file) {
        this.uri = Uri.fromFile(file);
        this.name = file.getName();
        String fileName = file.getName();
        int dot = fileName.lastIndexOf('.');
        String ext = dot >= 0 && dot < fileName.length() - 1 ? fileName.substring(dot + 1) : "";
        String mime = ext.isEmpty() ? null
                : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase(Locale.ROOT));
        this.mimeType = mime != null ? mime : "arquivo";
        this.sizeBytes = Math.max(0L, file.length());
        this.file = file;
        this.selected = false;
    }

    public boolean delete(Context context) {
        if (file != null) return file.delete();
        DocumentFile document = toDocumentFile(context);
        return document != null && document.exists() && document.delete();
    }

    public Uri getUri() {
        return uri;
    }

    public String getName() {
        return name;
    }

    public String getMimeType() {
        return mimeType;
    }

    public long getSizeBytes() {
        return sizeBytes;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public DocumentFile toDocumentFile(Context context) {
        return DocumentFile.fromSingleUri(context, uri);
    }
}
