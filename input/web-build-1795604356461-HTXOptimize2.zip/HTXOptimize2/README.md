# HTX Optimize 2.2 — Reforçado

Aplicativo Android nativo de monitoramento local e gerenciamento de arquivos selecionados pelo usuário. A interface existente foi preservada: layouts, cores, ícones, drawables e menu não foram redesenhados.

## Reforços internos
- Leituras de RAM, armazenamento e bateria executadas fora da thread principal nas telas de monitoramento.
- Atualizações interrompidas quando a tela deixa de estar ativa e callbacks protegidos contra views destruídas.
- Navegação com transações seguras, restauração da aba selecionada e sem `commitAllowingStateLoss`.
- Monitoramento de RAM com execução em segundo plano e encerramento correto dos workers no ciclo de vida dos fragments.
- Varredura SAF com limite de arquivos e profundidade, tratamento por entrada, ordenação por tamanho e proteção contra resultados obsoletos.
- Exclusão somente de arquivos explicitamente selecionados, com confirmação, contagem de sucesso/falha e atualização da lista. Pastas não são excluídas.
- Cálculos de espaço com proteção contra valores negativos e overflow.
- Leitura de bateria e memória com resultados de fallback quando o Android/provedor não fornece dados.
- `allowBackup=false` mantido para evitar backup automático dos dados locais do app.
- Versão Android atualizada para 2.2 (versionCode 22).

## Limites reais do Android
Um app comum não pode encerrar à força processos de outros aplicativos nem garantir liberação global de RAM. A função Booster faz diagnóstico e solicita GC apenas para o processo do HTX Optimize; o Android gerencia os demais processos. A exclusão de arquivos depende das permissões concedidas pelo seletor de documentos do Android.

## Gerar APK pelo GitHub Actions
1. Extraia o ZIP e envie o conteúdo da pasta `HTXOptimize2` para um repositório GitHub.
2. Abra **Actions** e execute **Build HTX Optimize 2.2 APK**.
3. Baixe o artefato **HTX-Optimize-2.2-APKs**.
4. O APK Debug serve para testes. O APK Release gerado pelo workflow é unsigned e precisa ser assinado com sua chave privada antes de distribuição.

## Verificação
Os arquivos Java/XML foram revisados estaticamente e os XMLs serão validados no pacote. Este ambiente não possui Gradle nem Android SDK configurados; portanto, não afirmamos que o APK foi compilado ou executado aqui.


## v2.5 — Shizuku, Modo Jogo e novo visual

- FPS real do app em foco via Shizuku (`dumpsys SurfaceFlinger --latency`); sem Shizuku a janelinha mostra a taxa da tela ("TELA").
- Otimização profunda opcional (`am force-stop`) via Shizuku.
- Modo Jogo (1 toque), info de CPU, teste de velocidade do armazenamento, aparência da janelinha (opacidade/tamanho).
- minSdk agora é 24 (requisito da biblioteca do Shizuku).


## v2.6 — FPS real reforçado

- Conexão com o Shizuku refeita a cada ciclo (antes só tentava ao ligar a janelinha) e reconecta sozinha.
- Leitura de FPS com várias camadas candidatas, colunas alternativas e fallback para `gfxinfo framestats`.
- Janelinha mostra o app medido e o motivo quando não consegue o FPS real; mini gráfico; toque alterna modo compacto.
- Estatísticas de sessão (média, 1% low, 0,1% low, travadas) e "Diagnóstico FPS (10s)" nas Ferramentas.


## v2.7 — FPS que ficava em 0

- Novo medidor por contador de quadros do SurfaceFlinger (`--timestats`), usado quando o `--latency` não mostra quadros novos.
- Cadeia de medição: latency -> timestats -> gfxinfo; HUD mostra a fonte (SF/TS/GFX) e "sem quadros novos" só quando realmente parado.
- Diagnóstico agora mostra o início da saída bruta de cada comando.


## v2.8 — Auditoria completa

- **Corrigido:** aviso de permissões aparecia em toda abertura (agora só na primeira vez); limpeza de temporários não apaga mais `.bak`, downloads parciais nem arquivos modificados nos últimos 10 min; tela "Sobre" mostra a versão real e o texto de privacidade atualizado; APK release agora é assinado (instalável) e o CI roda os testes unitários.
- **Novo:** pontuação de saúde do aparelho, apps protegidos da otimização (+ discador/SMS/Shizuku sempre protegidos), análise dos maiores arquivos de todo o armazenamento, animações de entrada, verificação de recursos/IDs duplicados no `verify_project.py`.


## v2.9 — Gerenciador de arquivos e Terminal

- **Aba Arquivos (estilo ZArchiver):** navegação com caminho clicável, atalhos (Interno, SD, Download, DCIM…), favoritos, seleção múltipla (segure), copiar/mover/colar com progresso e cancelamento, excluir, renomear, nova pasta/arquivo, compartilhar, propriedades e checksums (MD5/SHA-1/SHA-256), ordenar, mostrar ocultos, filtro e busca em subpastas.
- **Compactar e extrair:** ZIP, TAR, TAR.GZ e GZ (nativos), 7Z (criar/extrair) e RAR (extrair) via bibliotecas. Abre o conteúdo do arquivo como uma pasta, extrai só o que você marcar e protege contra "zip slip".
- **Aba Terminal (sh):** executa comandos pelo Shizuku (usuário shell) ou no modo App; pasta atual com `cd`, tempo limite, cancelar, histórico, comandos salvos, atalhos prontos, copiar/salvar a saída e confirmação para comandos perigosos. `.sh` do gerenciador abre direto no terminal.
- A barra de baixo agora é: Início, Booster, Arquivos, Terminal, Ferramentas. O monitor de RAM e o analisador de espaço continuam acessíveis pela Início (e o analisador também pelo menu do gerenciador).
