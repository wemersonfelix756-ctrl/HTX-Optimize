# HTX Optimize QA matrix

| Area | Scenario | Expected result |
|---|---|---|
| Startup | Cold launch | Main screen opens without InflateException |
| Navigation | Tap each bottom item | Matching fragment appears |
| Navigation | Rotate/recreate Activity | Selected destination is restored |
| Navigation | Background then return | No duplicate fragment or crash |
| RAM | Device reports zero/unknown values | UI shows safe fallback |
| RAM | Low-memory flag is set | Status is informational; no false cleanup claim |
| Storage | Storage stat unavailable | UI shows unavailable state |
| Storage | Provider returns null display name | Generic safe label is used |
| Storage | File disappears before delete | Operation reports failure and continues safely |
| Storage | Permission revoked | User receives actionable explanation |
| Battery | Battery intent unavailable | Battery fields show unavailable |
| Battery | Temperature unavailable | No fabricated temperature |
| Settings | Target screen missing on OEM build | Friendly fallback message |
| Permissions | User denies access | App remains usable where possible |
| Lifecycle | Leave screen during work | Work is cancelled or safely detached |
| Privacy | Inspect logs | No file contents or credentials logged |
| Release | Install signed APK | App launches and core flows work |
| Permissões | Primeira abertura | Aviso explicativo aparece uma única vez; depois só o card da Início |
| Permissões | Conceder uma a uma (notificações, arquivos, sobrepor) | Cada tela do sistema abre em sequência e o card mostra ✔ |
| Janelinha | Ligar/desligar pela Início e pela notificação | Aparece sobre outros apps; arrastar move; toque alterna compacto |
| Janelinha | Reiniciar o celular sem iniciar o Shizuku | Rótulo "TELA" + motivo na linha pequena |
| FPS real | Shizuku autorizado + jogo aberto | Rótulo "FPS", app e fonte (SF/TS/GFX) na linha pequena |
| FPS real | Diagnóstico FPS (10s) | Texto com app em foco, camadas e FPS lido |
| RAM Booster | Otimizar com e sem modo profundo | Relatório antes/depois; apps protegidos não são encerrados |
| Apps protegidos | Marcar apps e otimizar | Apps marcados continuam abertos |
| Armazenamento | Analisar todo o armazenamento | Lista dos maiores arquivos; excluir pede confirmação |
| Limpeza | Limpar temporários | Só .tmp/.temp/.log/.cache/miniaturas antigos; confirmação antes de apagar |
| Modo Jogo | Tocar uma vez | RAM liberada + janelinha ligada (se permitido) |
| Arquivos | Abrir a aba sem permissão | Card pedindo acesso; ao conceder, lista a pasta |
| Arquivos | Tocar em pasta / botão ↑ / caminho clicável / voltar | Navega e o botão voltar sobe uma pasta |
| Arquivos | Segurar um item → Copiar → abrir outra pasta → Colar | Item aparece no destino com progresso |
| Arquivos | Mover, renomear, excluir (confirmação), nova pasta/arquivo | Lista atualiza; nomes duplicados viram "nome (1)" |
| Arquivos | Compactar em ZIP/7Z/TAR.GZ e extrair de volta | Conteúdo idêntico; arquivo criado na pasta atual |
| Arquivos | Tocar num .zip/.7z/.rar → Abrir (explorar) → marcar itens → Extrair | Só os itens marcados são extraídos |
| Arquivos | Tocar num .apk → Instalar | Pede permissão "apps desconhecidos" e abre o instalador |
| Arquivos | Menu ⋮ → Buscar em subpastas / Ordenar / Ocultos / Favoritos | Resultados, ordem e atalhos corretos |
| Arquivos | Info e Checksums de um arquivo | Tamanho, permissões, MD5/SHA-1/SHA-256 |
| Terminal | Modo Shizuku: `id` | Mostra uid=2000(shell) |
| Terminal | `cd /sdcard/Download` e depois `ls` | Prompt muda e o ls lista a pasta |
| Terminal | `sleep 30` com tempo limite 15 s / botão ■ | Encerra e mostra "[tempo esgotado]" / "[cancelado]" |
| Terminal | `rm -rf /sdcard/*` | Pede confirmação antes de executar |
| Terminal | Atalhos, Salvos, Histórico, Copiar, Salvar saída | Inserem/copiam/salvam como descrito |
| Terminal | .sh no gerenciador → Preparar no Terminal | Terminal abre com `sh '<caminho>'` digitado |

## Manual test record

Record device model, Android version, build variant, APK version, test date,
and pass/fail notes for each row before publishing a release.
