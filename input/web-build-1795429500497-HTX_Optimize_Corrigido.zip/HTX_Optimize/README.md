# HTX Optimize

Projeto Android nativo em Java, com interface roxa futurista.

## Recursos
- Indicador de RAM disponível (estimativa fornecida pelo Android).
- Armazenamento interno livre/total.
- Nível atual da bateria.
- Atalhos para telas oficiais de armazenamento, bateria, aplicativos e detalhes do app.
- Recomendações de manutenção segura.

## Limites importantes
Este app não é um "limpador mágico". Android não permite que um app comum limpe cache de outros apps, encerre processos arbitrariamente ou aumente FPS por conta própria. O app não solicita permissões perigosas nem apaga dados.

## Compilar
Requisitos: Android Studio, Android SDK 35, JDK 17 e Android Gradle Plugin 8.7.3.

1. Extraia o ZIP.
2. Abra a pasta `HTX_Optimize` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se solicitado, instale Android SDK Platform 35 e Build Tools.
5. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar no celular
Transfira `app-debug.apk` para o Android, abra o arquivo e autorize a instalação dessa fonte quando o sistema solicitar. Instale apenas APKs que você mesmo compilou ou cuja origem confia.

## Observação
O projeto inclui o código-fonte e a configuração Gradle, não um APK já compilado. A compilação requer Android SDK/Gradle no computador ou num ambiente Android compatível.
