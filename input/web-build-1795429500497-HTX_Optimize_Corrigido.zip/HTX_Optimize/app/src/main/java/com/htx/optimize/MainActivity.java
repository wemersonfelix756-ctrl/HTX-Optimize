package com.htx.optimize;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.DecimalFormat;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(16, 9, 29);
    private final int PANEL = Color.rgb(31, 19, 51);
    private final int PURPLE = Color.rgb(182, 108, 255);
    private final int WHITE = Color.rgb(246, 239, 255);
    private final int MUTED = Color.rgb(185, 166, 207);
    private LinearLayout root;
    private TextView ramValue, storageValue, batteryValue, statusText;
    private final DecimalFormat df = new DecimalFormat("0.0");

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
        refreshStats();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(28));
        root.setBackgroundColor(BG);
        scroll.addView(root);
        setContentView(scroll);

        TextView eyebrow = text("HTX • ANDROID PERFORMANCE", 11, PURPLE, true);
        eyebrow.setLetterSpacing(.12f);
        root.addView(eyebrow);

        TextView title = text("HTX Optimize", 30, WHITE, true);
        title.setPadding(0, dp(8), 0, dp(3));
        root.addView(title);
        root.addView(text("Painel inteligente do seu dispositivo", 14, MUTED, false));

        statusText = text("●  MONITORAMENTO ATIVO", 12, PURPLE, true);
        statusText.setPadding(0, dp(20), 0, dp(12));
        root.addView(statusText);

        TextView metricsTitle = text("VISÃO GERAL", 12, MUTED, true);
        metricsTitle.setPadding(0, dp(6), 0, dp(10));
        root.addView(metricsTitle);

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.VERTICAL);
        addMetric(metrics, "MEMÓRIA RAM", ramValue = text("--", 24, WHITE, true), "Memória disponível no momento");
        addMetric(metrics, "ARMAZENAMENTO", storageValue = text("--", 24, WHITE, true), "Espaço livre no armazenamento interno");
        addMetric(metrics, "BATERIA", batteryValue = text("--", 24, WHITE, true), "Nível atual informado pelo Android");
        root.addView(metrics);

        Button refresh = button("ATUALIZAR INDICADORES");
        refresh.setOnClickListener(v -> refreshStats());

        section("FERRAMENTAS DO SISTEMA");
        addAction("Armazenamento", "Abrir configurações de armazenamento", Settings.ACTION_INTERNAL_STORAGE_SETTINGS);
        addAction("Bateria", "Ver uso e opções de economia", Settings.ACTION_BATTERY_SAVER_SETTINGS);
        addAction("Aplicativos instalados", "Gerenciar apps e permissões", Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS);
        addAction("Detalhes do HTX Optimize", "Permissões e informações deste app",
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));

        section("RECOMENDAÇÕES");
        addNote("1. Libere espaço", "Apague downloads e arquivos que você reconhece e não precisa mais.");
        addNote("2. Revise aplicativos", "Desinstale apps que não usa. Evite remover componentes do sistema.");
        addNote("3. Controle a bateria", "Confira quais aplicativos consomem mais energia nas configurações.");
        addNote("4. Reinicie quando necessário", "Uma reinicialização pode resolver lentidão temporária.");

        TextView disclaimer = text("IMPORTANTE\nO Android limita o que aplicativos comuns podem alterar. Este painel não promete aumentar FPS, não encerra processos à força e não apaga dados ou cache de outros aplicativos. Você decide o que alterar nas configurações do sistema.", 12, MUTED, false);
        disclaimer.setPadding(dp(2), dp(18), dp(2), dp(10));
        root.addView(disclaimer);

        TextView footer = text("HTX OPTIMIZE  •  V1.0", 10, PURPLE, true);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(14), 0, 0);
        root.addView(footer);
    }

    private void addMetric(LinearLayout parent, String label, TextView value, String hint) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(roundRect(PANEL, dp(16)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(10);
        parent.addView(card, lp);
        card.addView(text(label, 10, PURPLE, true));
        value.setPadding(0, dp(5), 0, dp(2));
        card.addView(value);
        card.addView(text(hint, 11, MUTED, false));
    }

    private void section(String name) {
        TextView t = text(name, 12, MUTED, true);
        t.setPadding(0, dp(22), 0, dp(10));
        root.addView(t);
    }

    private void addAction(String title, String subtitle, String action) {
        addAction(title, subtitle, action, null);
    }

    private void addAction(String title, String subtitle, String action, Uri data) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(roundRect(PANEL, dp(14)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(9);
        root.addView(card, lp);
        card.addView(text(title, 15, WHITE, true));
        TextView sub = text(subtitle, 11, MUTED, false);
        sub.setPadding(0, dp(4), 0, 0);
        card.addView(sub);
        card.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(action);
                if (data != null) intent.setData(data);
                startActivity(intent);
            } catch (Exception e) {
                statusText.setText("Não foi possível abrir esta tela neste dispositivo.");
            }
        });
        card.setClickable(true);
        card.setFocusable(true);
    }

    private void addNote(String title, String body) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(15), dp(13), dp(15), dp(13));
        card.setBackground(roundRect(PANEL, dp(14)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(8);
        root.addView(card, lp);
        card.addView(text(title, 14, WHITE, true));
        TextView b = text(body, 12, MUTED, false);
        b.setPadding(0, dp(4), 0, 0);
        card.addView(b);
    }

    private void refreshStats() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        double avail = mi.availMem / (1024.0 * 1024 * 1024);
        double total = mi.totalMem / (1024.0 * 1024 * 1024);
        ramValue.setText(df.format(avail) + " GB livres");
        StatFs stat = new StatFs(Environment.getDataDirectory().getAbsolutePath());
        double free = stat.getAvailableBytes() / (1024.0 * 1024 * 1024);
        double all = stat.getTotalBytes() / (1024.0 * 1024 * 1024);
        storageValue.setText(df.format(free) + " GB livres / " + df.format(all) + " GB");
        BatteryManager bm = (BatteryManager) getSystemService(BATTERY_SERVICE);
        int level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        batteryValue.setText(level >= 0 ? level + "%" : "Indisponível");
        statusText.setText("●  MONITORAMENTO ATIVO  •  RAM total: " + df.format(total) + " GB");
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setBackground(roundRect(Color.rgb(112, 48, 176), dp(14)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(5);
        root.addView(b, lp);
        return b;
    }

    private android.graphics.drawable.GradientDrawable roundRect(int color, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(dp(1), Color.rgb(75, 43, 105));
        return d;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + .5f);
    }
}
